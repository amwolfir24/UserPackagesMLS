import datetime

import boto3
import pytz
from boto3.dynamodb.conditions import Attr, Key
from psycopg2 import sql

from .datasets import json_to_dict
from .event_bridge import call_event_buffering_process
from .exceptions import DynamoDBException, RealtyfeedInternalException, NotFoundException, InvalidInputException, \
    DatabaseException, RealtyfeedException
from .orm import RDSHandler
from .stats import update_stats


def affiliate_view(event):
    event = json_to_dict(event)

    try:
        viewer_id = int(event['viewer_id'])
        affiliate_code = event['affiliate_code']
        target_type = event['target_object_type'].rstrip('s')
        if target_type not in ('listing', 'announcement', 'group', 'user'):
            raise InvalidInputException("`object_type` must be in ('listing', 'announcement')")
        target_id = int(event['target_object_id'])
        referer_data = event.get('referer_data')
    except LookupError:
        raise InvalidInputException("Invalid input for affiliate view")

    rds_handler = None

    try:
        rds_handler = RDSHandler(table_name="", is_cursor_dict=False)
        cursor = rds_handler.cursor


        get_share_actor_statement = sql.SQL(
            "SELECT {pkey} FROM {table_name} WHERE {affiliate_code_key} = %(affiliate_code)s;"
        ).format(
            pkey=sql.Identifier("id"), table_name=sql.Identifier("users"),
            affiliate_code_key=sql.Identifier("affiliate_code")
        )
        try:
            cursor.execute(get_share_actor_statement, {'affiliate_code': affiliate_code})
            share_actor_id = cursor.fetchone()[0]
        except Exception:
            raise DatabaseException(f"Error in fetching affiliate code related user")

        try:
            dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
            table = dynamodb.Table('shared_object_stats')
            items = table.query(
                KeyConditionExpression=Key('user_id').eq(share_actor_id),
                FilterExpression=Attr('user_affiliate_code').eq(affiliate_code) & Attr('target_type').eq(target_type) & Attr('target_id').eq(target_id)
            )['Items']
        except Exception:
            raise DynamoDBException("Failed in fetching shared objects stats for affiliate code.")

        if len(items) <= 0:
            raise NotFoundException(f'{target_type} with `id`={target_id} does not have share details')

        try:
            item = items[0]
            table.update_item(
                Key={'user_id': share_actor_id, 'creation_date': item['creation_date']},
                UpdateExpression="set visited_count=:c",
                ExpressionAttributeValues={':c': int(item['visited_count']) + 1}
            )
        except Exception:
            raise DynamoDBException("Error in updating shared object stats for share actor.")


        if target_type == "user":
            target_user_owner_id = target_id
        else:
            if target_type == "listing":
                get_owner_statement = sql.SQL(
                    "SELECT {user_pkey} FROM {table_name} WHERE {pkey}=%(object_id)s;"
                ).format(
                    pkey=sql.Identifier("id"), table_name=sql.Identifier("listings"),
                    user_pkey=sql.Identifier("user_id")
                )
            else:
                target_table_name = "announcement_and_shares" if target_type == "announcement" else "groups"
                get_owner_statement = sql.SQL(
                    "SELECT {user_pkey} FROM {table_name} WHERE {pkey}=%(object_id)s;"
                ).format(
                    pkey=sql.Identifier("id"), table_name=sql.Identifier(target_table_name),
                    user_pkey=sql.Identifier("user_id")
                )

            try:
                cursor.execute(get_owner_statement, {'object_id': target_id})
                target_owners = cursor.fetchone()
                target_user_owner_id = target_owners[0]
            except Exception:
                raise DatabaseException(f"Error in fetching affiliate target owners")


        visit_update = {target_type: target_id, 'user': share_actor_id}
        if (target_user_owner_id is not None) and (target_user_owner_id != share_actor_id):  # if you share your own 1 time counts
            visit_update['user2'] = target_user_owner_id

        for target in visit_update.keys():
            try:
                t_type = 'user' if 'user' in target else target
                stats_inputs = {
                    "source_object_type": t_type,
                    "source_object_id": visit_update[target],
                    "source_key": "external_share_count",
                    "source_operator": "plus",
                    "source_value": 1
                }
                update_stats(stats_inputs)
            except:
                raise DynamoDBException("Error in updating stats for affiliate")

        try:
            event_input_data = {
                "kinesis": {
                    'analysis-type': 'cold-only',
                    'analysis-data': {
                        'action': 'affiliate-view',
                        'referrer': referer_data,
                        'share-actor-user-id': share_actor_id,
                        'target-type': target_type,
                        'target-id': target_id,
                        'target-owner-user-id': target_user_owner_id,
                        'visitor-user-id': viewer_id,
                        'time-stamp': datetime.datetime.now().replace(tzinfo=pytz.UTC).isoformat()
                    },
                    "Message": f"user id={viewer_id} viewed {target_type} with {id} shared by user id={share_actor_id}",
                    # provided in each flow
                    "DateTime": datetime.datetime.now().replace(tzinfo=pytz.UTC).isoformat()
                }
            }
            call_event_buffering_process(event_type='Affiliate Analysis', has_events=False,
                                         event_input_data=event_input_data, has_kinesis=True,
                                         buffer_count=25, table_name="general_events_buffer")
        except:
            raise RealtyfeedInternalException("Error in handling event buffering for affiliate view process")

    except (RealtyfeedException, RealtyfeedInternalException) as e:
        if (rds_handler is not None) and (hasattr(rds_handler, 'close_connection')):
            rds_handler.close_connection()
        raise e