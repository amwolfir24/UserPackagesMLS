import json
import boto3
import json


def put_event_to_eventbridge(event_bridge_input):

    event_bridge = boto3.client("events")

    event_bridge.put_events(
        Entries=[
            {
                "Source": "appsync_service",  # Fixed
                "DetailType": "appsync_service",  # Fixed
                "Detail": json.dumps(event_bridge_input, default=0),
                "EventBusName": "realtyfeed-event-bus",  # Fixed
            },
        ]
    )


def put_user_feed_signal_event(user_id: int, number_of_feeds: int):
    """
    Description
        The method put an event to the AWS-Appsync Eventbridge service containing the Appsync mutation query, which causes
        a new feed signal to be sent to the user.
    parameter:
        -user_id: the target user RDS id
    Note: you must handle Eventbridge possible exceptions.
    """
    event_bridge_input = {
        "query": "mutation RFMutation {"
        f"sendNewFeedSignalToUser(number_of_new_feeds: {number_of_feeds}, user_id: {user_id})"
        "{ number_of_new_feeds  user_id }}"
    }

    put_event_to_eventbridge(event_bridge_input)


def put_users_refresh_token_event(user_id_list: list):
    """
    Description
        The method put an event to the AWS-Appsync Eventbridge service containing the Appsync mutation query,
        that causes a refresh-token signal to be sent to a number of users.
    parameter:
        -user_id_list: A list of the target users RDS ids.
    Note: you must handle Eventbridge possible exceptions.
    """
    event_bridge_input = {
        "query": "mutation RFMutation {"
        f"  refreshUserToken(user_id_list:{user_id_list})"
        "{id_list    notify_flag    refresh_token_flag  }}"
    }
    put_event_to_eventbridge(event_bridge_input)


def put_user_notificaion_event(user_id: int, number_of_unseen_notifs: int, message=""):
    """
    Description
        The method put an event to the AWS-Appsync Eventbridge service containing the Appsync mutation query, which causes
        a notification data to be sent to the user.
    parameter:
        -user_id: the target user RDS id
    Note: you must handle Eventbridge possible exceptions.
    """
    event_bridge_input = {
        "query": "mutation NotifyUser {"
        f'sendNotificationToUser(msg: "{message}", notification_number: {number_of_unseen_notifs}, user_id: {user_id}) '
        "{ msg  notification_number    user_id  }}"
    }
    put_event_to_eventbridge(event_bridge_input)
