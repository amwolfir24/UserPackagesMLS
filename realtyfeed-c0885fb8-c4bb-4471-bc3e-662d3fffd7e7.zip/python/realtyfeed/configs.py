from aws_secretsmanager_caching import SecretCache
from aws_secretsmanager_caching import InjectKeywordedSecretString

cache = SecretCache()


SECRET_KEY_DESCRIPTOR = "Realtyfeed Secret Key"

@InjectKeywordedSecretString(
    secret_id='development/rds/postgresql',
    cache=cache,
    db_name='dbname',
    db_pass='password',
    db_user='username',
    endpoint='host',
    port='port'
)
def get_rds_credentials(db_name, db_pass, db_user, endpoint, port):
    return db_name, db_pass, db_user, endpoint, port


@InjectKeywordedSecretString(
    secret_id='development/neptune',
    cache=cache,
    neptune_port='NEPTUNE_PORT',
    neptune_new_endpoint='NEPTUNE_NEW_ENDPOINT',
    neptune_endpoint='NEPTUNE_ENDPOINT'
)
def get_neptune_credentials(neptune_port, neptune_new_endpoint, neptune_endpoint):
    return neptune_port, neptune_new_endpoint, neptune_endpoint


@InjectKeywordedSecretString(
    secret_id='develop/stripe',
    cache=cache,
    stripe_secret_key='stripe_secret_key'
)
def get_stripe_credentials(stripe_secret_key):
    return stripe_secret_key


# ELASTICSEARCH
ELASTICSEARCH_ENDPOINT = "search-realtyfeed-dev-zsjwzxw3h5y5fs2vm7vabbi5fu.us-east-1.es.amazonaws.com"
ELASTICSEARCH_VPC_ENDPOINT = "vpc-realtyfeed-dev-new-picng3t6ocvedtgsz762pbemcq.us-east-1.es.amazonaws.com"
ELASTICSEARCH_PORT = "443"


# COGNITO
COGNITO_PUBLIC_KEYS_URL = "https://cognito-idp.us-east-1.amazonaws.com/us-east-1_2TJngZO4U/.well-known/jwks.json"
COGNITO_JWK = {
    "keys": [
        {
            "alg": "RS256",
            "e": "AQAB",
            "kid": "7dcHP8crI2Zc4P+EdQ3+OIIlKe9gankhROxOzqTbz6E=",
            "kty": "RSA",
            "n": "xjvD78Lv_bd7BT6mPuIRFq2eOGhEkjDWnaeBhAe_nW-3j4WgS9RQcXS9q_a1o01mT0dlhZMIc_XhENoIPlpThccqPgXzilmzzxtZ8710GzfwswLc_mgddnfbcj5lHQuUaJFAAE-W9X7Z_wVsOHBJnEkpFSqZBa61XZu3kows1kK_ga1S_bqeGh9_Reagxl8IUEKxAi8vhT0hdn9cqtaMdGQNOsk84sIt6L1G0YAtZTXPOFUhkFNPxmZ-lucx3beDvr8FutxxgzBkdwgD9BnRAFlrzqKH_roIUbzJuCH7FgE28EW-vtL0C9UoG_UYVwyRd5Wfj7jQV322svbO0xXYAQ",
            "use": "sig"
        },
        {
            "alg": "RS256",
            "e": "AQAB",
            "kid": "1Lvyhxk19gJvyI1jD4UuDSdzprWytlkeeKdB/x3pm7U=",
            "kty": "RSA",
            "n": "0ISog50K3OKTKEaP75totUl21NVmKt-wBN8tmScKUn-5lLGTaZ6BiMAAHYPp5W4D3IMPJ2c61IUjlvAOY8wn9aBqJKbSOxt8eyAS5KNB8MAK0mwejTp3LNWz4EQiYKYpgvyPQrDn1E6Ie86LuG3BVfMyFNDfFghNV5_46G-gJMTeKCA2vfGLh-GTsheSswrW3SPQWkPLRaoZy7idVKS9K4YYH3o0rj85UjKENojt2wwGn-nOmYxIBezBOLBaaTVrio7jhgw8ZplL6rzLmc5IOg-C-kViqwsb3u_VIVUKppUCtrhhtJKksBg-_NFCG1nVxvfCiRRV4paGi0MXIN7SOQ",
            "use": "sig"
        }
    ]
}

# STRIPE
STRIPE_API_KEY = "sk_test_51JuXQrIiTs3LeQ4Tqe4hOO59FXZJcZrSJktLM1Qam6toSQTMuzgak9tnS0wtvG9PFuFHQEn7Osbfpi6YbeXMrCgR001KT4FVmp"
OLD_STRIPE_API_KEY = "sk_test_51JuXQrIiTs3LeQ4Tqe4hOO59FXZJcZrSJktLM1Qam6toSQTMuzgak9tnS0wtvG9PFuFHQEn7Osbfpi6YbeXMrCgR001KT4FVmp"
RECURRING_PAYMENT_STRIPE_SECRET_KEY = "whsec_xlYzmCmMr2NbV4E0rFmvmsrZ9LShu0RZ"
REFUND_PAYMENT_UPDATE_STRIPE_SECRET_KEY = "whsec_DRoPITWZn6AUw7xClRWsL6aBIzbULPw0"
DISPUTE_PAYMENT_UPDATE_STRIPE_SECRET_KEY = "whsec_nlIs3ESG3tDmAXlSEWDYprpPMpGO9t3K"
TAX_ID_UPDATE_STRIPE_SECRET_KEY = 'whsec_PvRu2P4s72xn0O4R38KYTPOcM1EIqMRl'

# BUFFER
BUFFER_COUNT = 10
BUFFER_TABLE = 'general_events_buffer'

# CLOUD FRONT
CLOUDFRONT_URL = "https://dx41nk9nsacii.cloudfront.net"
