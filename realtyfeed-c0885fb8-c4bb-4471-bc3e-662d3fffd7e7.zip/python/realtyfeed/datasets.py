import json
from decimal import Decimal

from botocore.response import StreamingBody

from .exceptions import InputInvalidTokenException, InvalidInputException, RealtyfeedException, DataInvalidException
from .users import authenticate

sample_response = {
    "error": "",
    "message_code": "",
    "is_success": False,
    "result": None
}

sample_paginated_response = {
    "error": "",
    "message_code": "",
    "is_success": False,
    "last_record": {
        "partition_key": None,
        "sort_key": None
    },
    "result": None
}

is_value = lambda a: isinstance(a, (str, int, bytes, bytearray))
is_iterable = lambda a: isinstance(a, (list, set, tuple))
is_dict = lambda a: isinstance(a, dict)
is_string = lambda a: isinstance(a, str)


def json_to_dict(json_obj):
    if is_string(json_obj):
        try:
            json_obj = json.loads(json_obj)
        except (TypeError, json.JSONDecodeError):
            pass
        if not is_dict(json_obj):
            raise DataInvalidException("Input is not a valid json.")
    return json_obj


def validate_pagination_query_params(pagination_input):
    page_data_limit = None

    page_data_offset = None

    if isinstance(pagination_input, dict) and ("pagination" in pagination_input):
        pagination_input = pagination_input["pagination"]

    try:
        if "offset" in pagination_input and "limit" in pagination_input:
            try:
                try:
                    page_data_limit = int(pagination_input["limit"])
                    page_data_offset = pagination_input["offset"]
                    if isinstance(page_data_offset, str) and page_data_offset.isdigit():
                        page_data_offset = int(page_data_offset)
                except (LookupError, ValueError, TypeError):
                    page_data_limit = int(pagination_input["limit"])
                    page_data_offset = {
                        "partition_key": pagination_input['offset']["partition_key"],
                        "sort_key": pagination_input['offset']["sort_key"]
                    }  # {"partition_key": pk, "sort_key": sk"}
                    for key in page_data_offset:
                        if isinstance(page_data_offset[key], str) and page_data_offset[key].isdigit():
                            page_data_offset[key] = int(page_data_offset[key])
            except:
                raise Exception("Invalid pagination inputs")
    except:
        pass

    return page_data_offset, page_data_limit


def fetch_user_id_from_token(headers):
    try:
        token = headers["Authorization"]
        user_object = authenticate(token=token)
        return user_object['user_id']
    except RealtyfeedException as e:
        raise e
    except (AttributeError, LookupError):
        raise InputInvalidTokenException(error_message="No token present in the header")
    except Exception:
        raise InputInvalidTokenException(error_message="Input token is invalid.")


def get_valid_iterator(iterable, iterable_key=None):
    if is_dict(iterable):
        return iter(iterable.keys())
    elif is_iterable(iterable):
        return iter(iterable)
    else:
        raise InvalidInputException(
            error_message=f"Internal. Invalid {iterable_key or 'object'} type. Must be list or dict.")


def get_event_inputs(event, required_keys, optional_keys=None, has_token=True,
                     header_key="headers", query_params_key="queryString", body_key="body"):
    """
    required_keys = {
        "key1": "value1",
        "key2": None,
        "key3": ["val3", "val4", "val5"],
        "key4": {"default": 5, "expected": 10}
    }
    """
    output = {}

    event = json_to_dict(event)

    headers = event.get(header_key, {})
    query_params = event.get(query_params_key, {})
    body = event.get(body_key, {}) or event

    output["page_offset"], output["page_limit"] = validate_pagination_query_params(query_params)

    if has_token:
        output['user_id'] = fetch_user_id_from_token(headers)

    required_keys_iterator = get_valid_iterator(required_keys, "required keys")
    for required_key in required_keys_iterator:
        try:
            event_value = body[required_key]
            if is_dict(required_keys):
                validation_value = required_keys[required_key]
                event_value = validate_event_key_value(event_value, validation_value, required_key)
            output[required_key] = event_value
        except LookupError:
            raise InvalidInputException(error_message=f"`{required_key}` key is not present in input data.")

    if optional_keys:
        optional_keys_iterator = get_valid_iterator(optional_keys, "optional keys")
        for optional_key in optional_keys_iterator:
            if optional_key not in body:
                continue
            try:
                event_value = body.get(optional_key, None)
                if is_dict(optional_keys):
                    validation_value = optional_keys[optional_key]
                    try:
                        event_value = validate_event_key_value(event_value, validation_value, optional_key)
                    except:
                        continue
                output[optional_key] = event_value
            except LookupError:
                continue

    return output


def validate_event_key_value(real_value, validation_options, event_key):
    if validation_options == None:
        return real_value
    elif is_value(validation_options):
        if real_value == validation_options:
            return real_value
        else:
            error_message = f"`{event_key}` key must have value of `{validation_options}`."
    elif is_iterable(validation_options):
        if real_value in validation_options:
            return real_value
        else:
            error_message = f"`{event_key}` key must have value in `[{', '.join(validation_options)}]`."
    elif is_dict(validation_options) and ('default' in validation_options.keys()) and (
            'expected' in validation_options.keys()):
        if real_value == validation_options['expected']:
            return validation_options['expected']
        else:
            return validation_options['default']
    else:
        error_message = f"Internal. Invalid validation options for `{event_key}`. Must be " \
                        "(set, list, tuple) for containing, or (str, int) for equality or None for no validation."

    raise InvalidInputException(
        error_message=error_message,
        error_data={'real_value': real_value, 'event_key': event_key, 'validation_options': validation_options}
    )


def streaming_body_to_dict(streaming_obj) -> dict:
    if isinstance(streaming_obj, StreamingBody):
        streaming_obj = streaming_obj.read()
    if isinstance(streaming_obj, (bytes, bytearray)):
        streaming_obj = streaming_obj.decode("utf-8")
    if isinstance(streaming_obj, str):
        try:
            streaming_obj = json.loads(streaming_obj)
        except (TypeError, json.JSONDecodeError):
            pass
    return streaming_obj


def decimal_default(number):
    if isinstance(number, Decimal):
        string_number = str(number)
        if ('.' in string_number) and (string_number.replace(".", "").lstrip('-+').isdigit()):
            return float(string_number)
        elif string_number.lstrip('+-').isdigit():
            return int(string_number)
    raise TypeError


