import json


def get_dynamodb_type(key):
    if isinstance(key, str):
        if key.isdigit():
            return "N"
        try:
            key = json.loads(key)
        except (TypeError, json.JSONDecodeError):
            return "S"
        else:
            if not isinstance(key, (list, dict)):
                return "S"
    if isinstance(key, bytes):
        return "B"
    if isinstance(key, (int, float)):
        return "N"
    if isinstance(key, bool):
        return "BOOL"
    if isinstance(key, list):
        if all(isinstance(x, str) for x in key):
            if all(x.isdigit() for x in key):
                return "NS"
            return "SS"
        if all(isinstance(x, bytes) for x in key):
            return "BS"
        return "L"
    if isinstance(key, dict):
        return "M"
    if key is None:
        return "NULL"