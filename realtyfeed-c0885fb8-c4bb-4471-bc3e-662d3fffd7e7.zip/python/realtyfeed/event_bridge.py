import datetime
import json
from decimal import Decimal
import boto3
from boto3.dynamodb.conditions import Key, Attr
from pytz import UTC

from .configs import BUFFER_COUNT, BUFFER_TABLE
from .exceptions import RealtyfeedInternalException
from .datasets import decimal_default


def put_event_items(buffered_events, event_bridge, event_type, event_detail_type):
    """
    This is a helper function for call_event_buffering_process and shouldn't be called directly
    """
    entries_list = [
        {
            "Source": event_type,
            "DetailType": event_detail_type,
            "Detail": json.dumps(buffered_event['inputs'], default=decimal_default),
            "EventBusName": "realtyfeed-event-bus"
        } for buffered_event in buffered_events
    ]
    event_bridge.put_events(
        Entries=entries_list
    )


def delete_processed_items(ddb_table, buffered_events):
    """
    This is a helper function for call_event_buffering_process and shouldn't be called directly
    """
    with ddb_table.batch_writer() as batch:
        for buffered_event in buffered_events:
            batch.delete_item(
                Key={'type': buffered_event['type'], 'creation_date': buffered_event['creation_date']}
            )
    print('items deleted')


def validate_call_event_buffering_input(event_type, event_input_data, event_detail_type, has_event,
                                        has_kinesis, kinesis_input):
    """
    This is a helper function for call_event_buffering_process and shouldn't be called directly
    """
    try:
        if has_kinesis:
            assert kinesis_input and isinstance(kinesis_input, dict), \
                'Kinesis_input is required when has_kinesis is True and it should be dict type'
        if has_event:
            assert event_type and isinstance(event_type, str), \
                'Event type is required for putting event and it should be string'
            assert event_input_data and isinstance(event_input_data, dict), \
                'event_input_data in required for putting event in realtyfeed-event-bus and it should dict'
            assert event_detail_type and isinstance(event_detail_type, str), \
                'event_detail_type is required for putting event in realtyfeed-event-bus and it should be string'
            valid_input_keys = (
                'stats_input', 'feed_input', 'graph_input', 'index_input',
                'notifications_input', 'settings_inputs', 'locations_input', 'hashtags_input'
            )
            for key in event_input_data.keys():
                assert key in valid_input_keys, \
                    f"""{key} is not in our microservices please check
                    https://realtyna.atlassian.net/wiki/spaces/RFS/pages/514327115/Work+With+Amazon+EventBridge
                    for more information"""
    except AssertionError as e:
        raise RealtyfeedInternalException(str(e))


def call_event_buffering_process(event_type, event_input_data, event_detail_type, has_event=True,
                                 has_kinesis=False, kinesis_input=None):
    """
    This function is going to handle batch processing in our events. Kinesis input doesn't have a batch processing and
    immediately sent to feedback-end-bus. the event_input_data first going to be written in general_events_buffer and
    when the number of records of the producer (event_type) reaches the buffer_count (25) it will put events.
    inputs are according to below

    has_event: if you want to put data in realtyfeed-event-bus it should be True > Boolean type
    event_type: the producer of the event.The source key in put_event for realtyfeed-event-bus  > String type
    event_input_data: the input you want to pass to event-bus > Dictionary type
    event_detail_type: the detail key in put event for realtyfeed-event-bus > String type
    has_kinesis: if you want to send data to feedback-event-bus you should send it as True. > Boolean type
    kinesis_input: the input data you want to send to feedback-event-bus you > Dictionary type
    """

    # --------------------- Kinesis -----------------------------
    event_bridge = boto3.client('events')

    validate_call_event_buffering_input(
        event_type, event_input_data, event_detail_type, has_event, has_kinesis, kinesis_input
    )

    if has_kinesis:
        event_bridge.put_events(
            Entries=[
                {
                    "Source": "lambda-feedBack",
                    "DetailType": "analysis",
                    "Detail": json.dumps(kinesis_input, default=decimal_default),
                    "EventBusName": "feedback-event-bus"
                },
            ]
        )
    # ------------------ Realty-feed_eventbus ----------------------
    creation_date = datetime.datetime.now().replace(tzinfo=UTC).isoformat()
    new_object = {
        'type': event_type,
        'detail_type': event_detail_type,
        'inputs': event_input_data,
        'send_due': 12,
        'creation_date': creation_date
    }

    new_object = json.loads(json.dumps(new_object), parse_float=Decimal)
    if has_event:
        ddb = boto3.resource('dynamodb', region_name='us-east-1')
        ddb_table = ddb.Table(BUFFER_TABLE)
        buffered_events = ddb_table.query(
            KeyConditionExpression=Key('type').eq(event_type),
            FilterExpression=Attr('detail_type').eq(event_detail_type)
        )
        buffered_events = buffered_events['Items']
        # IMPORTANT: BUFFER_COUNT must be 10 or less. Because `put_events` don't accept more than 10 entries
        if len(buffered_events) == (BUFFER_COUNT - 1):
            buffered_events.append(new_object)
            put_event_items(buffered_events, event_bridge, event_type, event_detail_type)
            buffered_events.pop()
            delete_processed_items(ddb_table, buffered_events)
        elif len(buffered_events) > (BUFFER_COUNT - 1):
            buffered_events = buffered_events[:BUFFER_COUNT]
            ddb_table.put_item(Item=new_object)
            put_event_items(buffered_events, event_bridge, event_type, event_detail_type)
            delete_processed_items(ddb_table, buffered_events)

        else:
            ddb_table.put_item(Item=new_object)
