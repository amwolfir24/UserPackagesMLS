from . import error_codes


class BaseRealtyfeedException(Exception):
    def __init__(self, *args, error_message="Error", error_data="", http_status_code=400,
                 error_status_code=error_codes.BASE_ERROR, **kwargs):
        self.error_message = error_message
        self.error_data = error_data
        self.error_status_code = error_status_code
        self.http_status_code = http_status_code
        super().__init__(*args, **kwargs)

    def __str__(self):
        return self.error_message


class RealtyfeedException(BaseRealtyfeedException):
    def __init__(self, *args, error_message="Error", error_data="", http_status_code=400,
                 error_status_code=error_codes.BASE_ERROR, **kwargs):
        super().__init__(*args, error_message=error_message, error_data=error_data,
                         error_status_code=error_status_code, http_status_code=http_status_code, **kwargs)


class RealtyfeedInternalException(BaseRealtyfeedException):
    def __init__(self, error_message="Internal error.", error_data=None,
                 error_status_code=error_codes.INTERNAL_ERROR, http_status_code=500, *args, **kwargs):
        super().__init__(*args, error_message=error_message, error_data=error_data,
                         error_status_code=error_status_code, http_status_code=http_status_code, **kwargs)


class InvalidArgumentsException(RealtyfeedException):
    def __init__(self, error_message="Invalid arguments", error_data=None,
                 error_status_code=error_codes.INVALID_ARGUMENTS, *args, **kwargs):
        super().__init__(*args, error_message=error_message, error_data=error_data,
                         error_status_code=error_status_code, **kwargs)


class InvalidInputException(RealtyfeedException):
    def __init__(self, error_message="Input data is not valid", error_data=None,
                 error_status_code=error_codes.INPUT_INVALID, *args, **kwargs):
        super().__init__(*args, error_message=error_message, error_data=error_data,
                         error_status_code=error_status_code, **kwargs)


class InputInvalidTokenException(InvalidInputException):
    def __init__(self, error_message="Input token is not valid", error_data=None,
                 error_status_code=error_codes.INPUT_TOKEN_INVALID, *args, **kwargs):
        super().__init__(*args, error_message=error_message, error_data=error_data,
                         error_status_code=error_status_code, **kwargs)


class AmazonBoto3Exception(RealtyfeedException):
    def __init__(self, error_message="AWS Boto3 error.", error_data=None,
                 error_status_code=error_codes.AWS_BOTO3, *args, **kwargs):
        super().__init__(*args, error_message=error_message, error_data=error_data,
                         error_status_code=error_status_code, **kwargs)


class LambdaInvokeException(RealtyfeedException):
    def __init__(self, error_message="Lambda invoke failed.", error_data=None,
                 error_status_code=error_codes.LAMBDA_INVOKE_FAILED, *args, **kwargs):
        super().__init__(*args, error_message=error_message, error_data=error_data,
                         error_status_code=error_status_code, **kwargs)


class DataInvalidException(RealtyfeedException):
    def __init__(self, error_message="Invalid data error.", error_data=None,
                 error_status_code=error_codes.INVALID_DATA, *args, **kwargs):
        super().__init__(*args, error_message=error_message, error_data=error_data,
                         error_status_code=error_status_code, **kwargs)


class DatabaseException(RealtyfeedException):
    def __init__(self, error_message="Error occurred in database", error_data=None,
                 error_status_code=error_codes.DATABASE_ERROR, *args, **kwargs):
        super().__init__(*args, error_message=error_message, error_data=error_data,
                         error_status_code=error_status_code, **kwargs)


class DynamoDBException(RealtyfeedException):
    def __init__(self, error_message="Error occurred in DynamoDB", error_data=None,
                 error_status_code=error_codes.DYNAMO_DATABASE_ERROR, *args, **kwargs):
        super().__init__(*args, error_message=error_message, error_data=error_data,
                         error_status_code=error_status_code, **kwargs)


class InvalidTokenException(RealtyfeedException):
    def __init__(self, error_message="Token is invalid", error_data=None,
                 error_status_code=error_codes.INVALID_TOKEN, *args, **kwargs):
        super().__init__(*args, error_message=error_message, error_data=error_data,
                         error_status_code=error_status_code, **kwargs)


class NotFoundException(RealtyfeedException):
    def __init__(self, error_message="Not Found", error_data=None,
                 error_status_code=error_codes.NOT_FOUND, *args, **kwargs):
        super().__init__(*args, error_message=error_message, error_data=error_data,
                         error_status_code=error_status_code, **kwargs)


class ForbiddenException(RealtyfeedException):
    def __init__(self, error_message="Forbidden", error_data=None,
                 error_status_code=error_codes.FORBIDDEN, *args, **kwargs):
        super().__init__(*args, error_message=error_message, error_data=error_data,
                         error_status_code=error_status_code, **kwargs)
