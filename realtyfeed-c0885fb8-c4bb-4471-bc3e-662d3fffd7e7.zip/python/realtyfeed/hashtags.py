from .orm import RDSHandler
from .datasets import sample_response
from .exceptions import (
    RealtyfeedException,
    InvalidInputException,
    DatabaseException
)
from .datasets import decimal_default
from psycopg2 import sql
from itertools import groupby
import datetime
import pytz
import json
import boto3


# batch processing
def __put_event(event_bridge_input):
    event_bridge = boto3.client('events')
    event_bridge.put_events(
        Entries=[
            {
                "Source": "create-hashtag",  # Fixed
                "DetailType": "create-hashtag",  # Fixed
                "Detail": json.dumps(event_bridge_input, default=decimal_default),
                "EventBusName": "feedback-event-bus"  # Fixed
            }
        ]
    )


def __add_categories(cursor, tags):
    if len(tags) > 0:

        cd = datetime.datetime.now(pytz.UTC)
        args_str = ','.join(
            cursor.mogrify(
                "(%(hashtag_id)s, %(category_id)s, %(creation_date)s)",
                {"hashtag_id": x['id'], "category_id": y, "creation_date": cd}
            ).decode("utf-8") for x in tags for y in x['categories']
        )
        if len(args_str) > 0:
            sql_statement = sql.SQL(

                "WITH {result} AS ( "
                "   INSERT INTO {t_name} ({hashtag_id}, {category_id}, {creation_date})"
                f"  VALUES {args_str}"
                "   ON CONFLICT({hashtag_id}, {category_id}) DO NOTHING" 
                "   RETURNING {hashtag_id}, {category_id} "
                ") "
                "SELECT {result}.*, {t2_name}.{name} "
                "FROM {result} "
                "JOIN {t2_name} ON inserted.{category_id} = {t2_name}.{id}"

            ).format(
                t_name=sql.Identifier("hashtags_category_bridge"), hashtag_id=sql.Identifier("hashtag_id"),
                category_id=sql.Identifier("hashtags_category_id"), creation_date=sql.Identifier("creation_date"),
                t2_name=sql.Identifier("hashtags_category"), result=sql.Identifier("inserted"),
                id=sql.Identifier('id'), name=sql.Identifier('name')
            )

            try:
                cursor.execute(sql_statement)
                return [dict(r) for r in cursor]
            except Exception as ex:
                raise DatabaseException(str(ex))
    return []


def __existing_tags(cursor, tags):
    if len(tags) > 0:
        tags = ', '.join(map(lambda x: f'\'{x["name"]}\'', tags))
        q = "SELECT {id}, {name} FROM {t_name} WHERE {name}"
        q += f" IN ({tags})"
        sql_statement = sql.SQL(q).format(
            id=sql.Identifier("id"), t_name=sql.Identifier("hashtags"), name=sql.Identifier("name")
        )
        try:
            cursor.execute(sql_statement)
        except Exception as ex:
            raise DatabaseException(str(ex))
        return [dict(r) for r in cursor]
    return []


def __add_tags(cursor, tags):
    if len(tags) > 0:
        for tag in tags:
            tag["assigned_count"] = 0
            tag["is_system"] = False
            tag["creation_date"] = datetime.datetime.now(pytz.UTC)

        args_str = ','.join(
            cursor.mogrify(
                "(%(name)s, %(language_id)s, %(is_system)s, %(assigned_count)s, %(creation_date)s)",
                x
            ).decode("utf-8") for x in tags
        )
        sql_statement = sql.SQL(
            "INSERT INTO {t_name} ({name}, {language_id}, {is_system}, {assigned_count}, {creation_date}) "
            f"VALUES {args_str} "
            "RETURNING {id}, {name}, {language_id}, {is_system}"
        ).format(
            name=sql.Identifier("name"), language_id=sql.Identifier("language_id"), is_system=sql.Identifier("is_system"),
            assigned_count=sql.Identifier("assigned_count"), creation_date=sql.Identifier("creation_date"),
            id=sql.Identifier("id"), t_name=sql.Identifier("hashtags")
        )
        try:
            cursor.execute(sql_statement)
        except Exception as ex:
            raise DatabaseException(str(ex))

        return [dict(r) for r in cursor]
    return []


def create_hashtags(input_hashtags):
    response = sample_response.copy()
    event_bridge_input = {
        "stats_input": {"create": [], "update": []},
        "graph_input": {"create": [], "relations": {"add": []}},
        "elastic_input": {"index_name": "hashtags", "create": [], "update": []}
    }
    fields = ('name',)
    default_fields = (("categories", []),)
    create_fields = ('language_id',)
    create_default_fields = (("parent", None),)
    try:
        rds_handler = RDSHandler(table_name="", is_cursor_dict=True)
        cursor = rds_handler.cursor
        hashtags = []
        try:
            for tag in input_hashtags:

                if not isinstance(tag, dict):
                    raise InvalidInputException("invalid type")

                for field in fields:
                    if field not in tag:
                        raise InvalidInputException(f"{field} is missed in {tag}")

                for field in default_fields:
                    tag[field[0]] = tag.get(field[0], field[1])

                if tag['name'] not in [x['name'] for x in hashtags]:
                    hashtags.append(tag)

        except KeyError as k:
            raise InvalidInputException(f"{k} must be declared in input")

        result = __existing_tags(cursor, hashtags)
        new_tags = []
        for tag in hashtags:
            if tag['name'] not in [x['name'] for x in result]:
                for field in create_fields:
                    if field not in tag:
                        raise InvalidInputException(f"{field} is missed in {tag}")

                for field in create_default_fields:
                    tag[field[0]] = tag.get(field[0], field[1])

                new_tags.append(tag)
        new_tags_result = __add_tags(cursor, new_tags)

        for tag in new_tags_result:
            event_bridge_input['stats_input']['create'].append(
                {
                    "object_type": "hashtag",
                    "object_id": tag['id']
                }
            )

            event_bridge_input['graph_input']['create'].append(
                {
                    "object_type": "Hashtag",
                    "object_id": tag['id'],
                    "name": tag['name'],
                    "language_id": tag['language_id'],
                    "is_system": tag['is_system']
                }
            )

            event_bridge_input['elastic_input']['create'].append(
                {
                    "id": tag['id'],
                    "name": tag['name'],
                    "language_id": tag['language_id'],
                    "is_system": False,
                    "assigned_count": 0,
                    "hashtag_category_types": []
                }
            )

        result.extend(new_tags_result)

        for tag in hashtags:
            for item in result:
                if tag['name'] == item['name']:
                    item['categories'] = tag['categories']
                    break

        add_categories_result = __add_categories(cursor, result)

        for hashtag_id, group in groupby(add_categories_result, lambda x: x['hashtag_id']):
            g = list(group)
            event_bridge_input['stats_input']['update'].append(
                {
                    "object_type": "hashtag",
                    "object_id": hashtag_id,
                    "source_key": "hashtag_categories",
                    "source_value": [x['hashtags_category_id'] for x in g]
                }
            )
            event_bridge_input['elastic_input']['update'].append(
                {
                    "id": hashtag_id,
                    "hashtag_category_types": [x['name'] for x in g]
                }
            )
            event_bridge_input['graph_input']['relations']['add'] += [
                {
                    "from": {
                        "object_type": "HashtagCategory",
                        "object_id": x['hashtags_category_id']
                    },
                    "to": {
                        "object_type": "Hashtag",
                        "object_id": hashtag_id
                    },
                    "name": "HasHashtag"
                }
                for x in g
            ]
        for item in result:
            item.pop('categories')

        response['result'] = result
        rds_handler.commit_changes()
        __put_event(event_bridge_input)
        response['is_success'] = True

    except RealtyfeedException as exc:
        response["error"] = exc.error_message
        response["code"] = exc.error_status_code
        response["is_success"] = False
        response["result"] = exc.error_data

    except Exception as ex:
        response["error"] = str(ex)
        response["is_success"] = False

    return response


def __put_event_assign(event_bridge, event_bridge_input):
    event_bridge.put_events(
        Entries=[
            {
                "Source": "assign-hashtag",  # Fixed
                "DetailType": "assign-hashtag",  # Fixed
                "Detail": json.dumps(event_bridge_input),
                "EventBusName": "realtyfeed-event-bus"  # Fixed
            },
        ]
    )


def assign_hashtags_to_object(data):
    response = sample_response.copy()
    event_bridge_input = {
        "graph_input": {"relations": {"add": []}},
        "elastic_input": {"index_name": "hashtags", "update": []}
    }

    rds_info = {
        "user": {"table_name": "user_hashtags", "column_name": "user_id", "graph_label": "User"},
        "group": {"table_name": "group_hashtags", "column_name": "group_id", "graph_label": "Group"},
        "listing": {"table_name": "listing_hashtags", "column_name": "listing_id", "graph_label": "Listing"},
        "btt": {"table_name": "btt_hashtags_bridge", "column_name": "btt_type_item_id", "graph_label": "BTTItem"},
        "lead": {"table_name": "lead_hashtags", "column_name": "lead_id", "graph_label": "Lead"},
    }

    try:
        try:
            object_type: str = data["object_type"]
            object_id: (str, int) = data["object_id"]
            hashtag_ids: list = data["hashtag_ids"]
        except (LookupError, AttributeError, ValueError):
            raise InvalidInputException("invalid input")

        if object_type not in rds_info.keys():
            raise InvalidInputException("invalid object type")

        if not isinstance(hashtag_ids, list):
            raise InvalidInputException("hashtag_ids must be a list")

        table_name = rds_info[object_type]['table_name']
        object_lookup_key = rds_info[object_type]['column_name']

        rds_handler = RDSHandler(table_name="", is_cursor_dict=True)
        cursor = rds_handler.cursor

        cd = datetime.datetime.now(pytz.UTC)
        args_str = ','.join(
            cursor.mogrify(
                "(%(hashtag_id)s, %(object_id)s, %(creation_date)s)",
                {"hashtag_id": tag_id, "object_id": object_id, "creation_date": cd}
            ).decode("utf-8") for tag_id in hashtag_ids
        )

        sql_statement = sql.SQL(
            "WITH {result} AS ( "
            "   INSERT INTO {t_name} ({hashtag_id}, {object_id}, {creation_date}) "
            f"  VALUES {args_str} "
            "   ON CONFLICT({hashtag_id}, {object_id}) DO NOTHING "
            "   RETURNING {hashtag_id}, {object_id} "
            ") "
            "SELECT {result}.*, {t2_name}.{assigned_count} "
            "FROM {result} "
            "JOIN {t2_name} ON inserted.{hashtag_id} = {t2_name}.{id}"
        ).format(
            result=sql.Identifier('inserted'), t_name=sql.Identifier(table_name),
            hashtag_id=sql.Identifier('hashtag_id'), object_id=sql.Identifier(object_lookup_key),
            creation_date=sql.Identifier('creation_date'), t2_name=sql.Identifier('hashtags'),
            assigned_count=sql.Identifier('assigned_count'), id=sql.Identifier('id')
        )
        try:
            cursor.execute(sql_statement)
            result = [dict(r) for r in cursor]
        except Exception as ex:
            raise DatabaseException(str(ex))

        for item in result:
            sql_statement = sql.SQL(
                "UPDATE {t_name} SET {assigned_count}=%(assigned_count)s WHERE {id}=%(id)s"
            ).format(
                t_name=sql.Identifier('hashtags'), assigned_count=sql.Identifier('assigned_count'),
                id=sql.Identifier('id')
            )
            try:
                cursor.execute(
                    sql_statement, {"assigned_count": item['assigned_count'] + 1, "id": item['hashtag_id']}
                )
            except Exception as ex:
                raise DatabaseException(str(ex))

            event_bridge_input['graph_input']['relations']['add'].append(
                {
                    "from": {
                        "object_type": rds_info[object_type]["graph_label"],
                        "object_id": object_id
                    },
                    "to": {
                        "object_type": "Hashtag",
                        "object_id": item['hashtag_id']
                    },
                    "name": "IsRelated"
                }
            )
            event_bridge_input['elastic_input']['update'].append(
                {
                    "id": item['hashtag_id'],
                    "assigned_count": item['assigned_count'] + 1
                }
            )

        rds_handler.commit_changes()
        event_bridge = boto3.client('events')
        __put_event_assign(event_bridge, event_bridge_input)
        response['is_success'] = True
    except RealtyfeedException as exc:
        response["error"] = exc.error_message
        response["code"] = exc.error_status_code
        response["is_success"] = False
        response["result"] = exc.error_data

    except Exception as ex:
        response["error"] = str(ex)
        response["is_success"] = False

    return response


def delete_assign_hashtags_to_object(data):
    event_bridge_input = {
        "graph_input": {"relations": {"remove": []}},
    }

    rds_info = {
        "user": {"table_name": "user_hashtags", "column_name": "user_id", "graph_label": "User"},
        "group": {"table_name": "group_hashtags", "column_name": "group_id", "graph_label": "Group"},
        "listing": {"table_name": "listing_hashtags", "column_name": "listing_id", "graph_label": "Listing"},
        "btt": {"table_name": "btt_hashtags_bridge", "column_name": "btt_type_item_id", "graph_label": "BTTItem"},
        "lead": {"table_name": "lead_hashtags", "column_name": "lead_id", "graph_label": "Lead"},
    }

    try:
        object_type: str = data["object_type"]
        object_id: (str, int) = data["object_id"]
        hashtag_ids: list = data["hashtag_ids"]
    except (LookupError, AttributeError, ValueError):
        raise InvalidInputException("invalid input")

    if object_type not in rds_info.keys():
        raise InvalidInputException("invalid object type")

    if not isinstance(hashtag_ids, list):
        raise InvalidInputException("hashtag_ids must be a list")

    table_name = rds_info[object_type]['table_name']
    object_lookup_key = rds_info[object_type]['column_name']

    rds_handler = RDSHandler(table_name="", is_cursor_dict=True)
    cursor = rds_handler.cursor

    query = "DELETE FROM {table_name} WHERE {object_id}=%(object_id)s AND "
    if len(hashtag_ids) == 0:
        raise Exception("hashtag_ids must not be empty!")
    elif len(hashtag_ids) == 1:
        query += "{hashtag_id}=%(hashtag_id)s "
        value = hashtag_ids[0]
    else:
        query += "{hashtag_id} IN (hashtag_id)s "
        value = tuple(hashtag_ids)

    query += "RETURNING {hashtag_id}"

    sql_statement = sql.SQL(query).format(
        table_name=sql.Identifier(table_name), object_id=sql.Identifier(object_lookup_key),
        hashtag_id=sql.Identifier('hashtag_id')
    )
    try:
        cursor.execute(sql_statement, {"object_id": object_id, "hashtag_id": value})
        result = [dict(r)["hashtag_id"] for r in cursor]
    except Exception as ex:
        raise DatabaseException(str(ex))

    event_bridge_input['graph_input']['relations']['remove'].extend(
        [
            {
                "from": {
                    "object_type": rds_info[object_type]["graph_label"],
                    "object_id": object_id
                },
                "to": {
                    "object_type": "Hashtag",
                    "object_id": hashtag_id
                },
                "name": "IsRelated"
            } for hashtag_id in result
        ]
    )
    rds_handler.commit_changes()
    event_bridge = boto3.client('events')
    __put_event_assign(event_bridge, event_bridge_input)