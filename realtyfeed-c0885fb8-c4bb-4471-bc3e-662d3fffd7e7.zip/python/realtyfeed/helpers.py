import datetime
import re

import boto3

from .exceptions import RealtyfeedException
from .lambdas import call_lambda_function


def get_cloudfront_url(user_id, path, file_type):
    s3_resource = boto3.client("s3", region_name="us-east-1")
    path = path.replace('s3://realtyfeed/', '')
    file_name = path.split("/")[-1]
    if file_type == 'picture':
        new_path = f'users/{user_id}/medias/photos/{file_name}'
    elif file_type == 'logo':
        new_path = f'users/{user_id}/medias/photos/logo/{file_name}'
    else:
        file_type = 'document' if file_type == 'document' else 'certificates'
        new_path = f'users/{user_id}/docs/{file_type}/{file_name}'

    object_metadata = s3_resource.list_objects_v2(Bucket="realtyfeed", Prefix=path)
    new_object_metadata = s3_resource.list_objects_v2(Bucket="realtyfeed", Prefix=new_path)
    if object_metadata.get("Contents") and new_object_metadata.get("Contents") is None:
        copy_source = {"Bucket": "realtyfeed", "Key": path}
        s3_resource.copy(copy_source, "realtyfeed", new_path)
        s3_resource.delete_object(Bucket="realtyfeed", Key=path)

    return f'https://dx41nk9nsacii.cloudfront.net/{new_path}'


def update_object_location(location_obj, object_type, object_id):
    input_data = {
        'type': 1,
        'object_type': object_type,
        'object_id': object_id,
        'location': location_obj
    }
    lambda_response = call_lambda_function(function_name="location_giveObjectLocation_RDS", payload=input_data)

    if not lambda_response.get('is_success', False):
        raise RealtyfeedException(
            error_message="Error in calling `location_giveObjectLocation_RDS` lambda function.",
            error_data={'error': lambda_response.get('error', '')}
        )


def read_s3_downloaded_file(downloaded_file):
    pass


def parse_duration(value):
    """
        Parse a duration string and return a datetime.timedelta.

        The preferred format for durations in Django is '%d %H:%M:%S.%f'.

        Also supports ISO 8601 representation and PostgreSQL's day-time interval
        format.
    """

    standard_duration_re = re.compile(
        r'^'
        r'(?:(?P<days>-?\d+) (days?, )?)?'
        r'(?P<sign>-?)'
        r'((?:(?P<hours>\d+):)(?=\d+:\d+))?'
        r'(?:(?P<minutes>\d+):)?'
        r'(?P<seconds>\d+)'
        r'(?:[\.,](?P<microseconds>\d{1,6})\d{0,6})?'
        r'$'
    )
    iso8601_duration_re = re.compile(
        r'^(?P<sign>[-+]?)'
        r'P'
        r'(?:(?P<days>\d+(.\d+)?)D)?'
        r'(?:T'
        r'(?:(?P<hours>\d+(.\d+)?)H)?'
        r'(?:(?P<minutes>\d+(.\d+)?)M)?'
        r'(?:(?P<seconds>\d+(.\d+)?)S)?'
        r')?'
        r'$'
    )
    postgres_interval_re = re.compile(
        r'^'
        r'(?:(?P<days>-?\d+) (days? ?))?'
        r'(?:(?P<sign>[-+])?'
        r'(?P<hours>\d+):'
        r'(?P<minutes>\d\d):'
        r'(?P<seconds>\d\d)'
        r'(?:\.(?P<microseconds>\d{1,6}))?'
        r')?$'
    )

    match = (
        standard_duration_re.match(value) or
        iso8601_duration_re.match(value) or
        postgres_interval_re.match(value)
    )
    if match:
        kw = match.groupdict()
        sign = -1 if kw.pop('sign', '+') == '-' else 1
        if kw.get('microseconds'):
            kw['microseconds'] = kw['microseconds'].ljust(6, '0')
        if kw.get('seconds') and kw.get('microseconds') and kw['seconds'].startswith('-'):
            kw['microseconds'] = '-' + kw['microseconds']
        kw = {k: float(v.replace(',', '.')) for k, v in kw.items() if v is not None}
        days = datetime.timedelta(kw.pop('days', .0) or .0)
        if match.re == iso8601_duration_re:
            days *= sign
        return days + sign * datetime.timedelta(**kw)

