from psycopg2 import sql
from .error_codes import DATABASE_ERROR
from .exceptions import RealtyfeedException


def get_invoice_item_object_details(cursor, invoice_id: int, object_type: str) -> list:
    """
    get invoice item information based on object_type
    @param cursor:
    @param invoice_id:
    @param object_type: btt or package
    @return: [
    {
        "id": int, "period_start": datetime, "period_end": datetime,
         "quantity": int, "promotion_id": int, "discount_id": int, "payment_method_id": int,
         "btt_type_items_id / package_id": int, ""
    }
    ]
    """
    keys = {
        'btt': {'table_name': 'invoice_item_btt_type_item', 'object_fk': 'selected_btt_type_items_id'},
        'package': {'table_name': 'invoice_item_package', 'object_fk': 'selected_package_id'}
    }
    table_name = keys[object_type]['table_name']
    object_fk = keys[object_type]['object_fk']
    if object_type == 'btt':

        sql_statement = sql.SQL(
            "SELECT {invoice_item_table}.{pkey}, {invoice_item_table}.{period_start}, "
            "{invoice_item_table}.{period_end}, {invoice_item_table}.{quantity}, {invoice_item_table}.{promotion_fk}, "
            "{invoice_item_table}.{discount_fk}, {invoice_item_table}.{object_fk}, "
            "{invoice_item_table}.{payment_method_fk} FROM {invoice_table}"
            "JOIN {invoice_item_table} ON {invoice_item_table}.{invoice_pkey} = {invoice_table}.{pkey} "
            "WHERE {invoice_table}.{pkey} = %(invoice_id)s"
        ).format(
            invoice_item_table=sql.Identifier(table_name), pkey=sql.Identifier('id'),
            period_start=sql.Identifier('period_start'), period_end=sql.Identifier('period_end'),
            quantity=sql.Identifier('quantity'), invoice_table=sql.Identifier('invoices'),
            invoice_pkey=sql.Identifier('invoice_id'), promotion_fk=sql.Identifier('promotion_id'),
            discount_fk=sql.Identifier('discount_id'), payment_method_fk=sql.Identifier('selected_payment_method_id'),
            object_fk=sql.Identifier(object_fk)
        )
    else:
        sql_statement = sql.SQL(
            "SELECT {invoice_item_table}.{pkey}, {invoice_item_table}.{period_start}, "
            "{invoice_item_table}.{period_end}, {invoice_item_table}.{quantity}, {invoice_item_table}.{promotion_fk}, "
            "{invoice_item_table}.{discount_fk}, {invoice_item_table}.{object_fk}, "
            "{invoice_item_table}.{payment_method_fk}, {invoice_item_table}.{trial} "
            "FROM {invoice_table} JOIN {invoice_item_table} "
            "ON {invoice_item_table}.{invoice_pkey} = {invoice_table}.{pkey} "
            "WHERE {invoice_table}.{pkey} = %(invoice_id)s"
        ).format(
            invoice_item_table=sql.Identifier(table_name), pkey=sql.Identifier('id'),
            period_start=sql.Identifier('period_start'), period_end=sql.Identifier('period_end'),
            quantity=sql.Identifier('quantity'), invoice_table=sql.Identifier('invoices'),
            invoice_pkey=sql.Identifier('invoice_id'), promotion_fk=sql.Identifier('promotion_id'),
            discount_fk=sql.Identifier('discount_id'), payment_method_fk=sql.Identifier('selected_payment_method_id'),
            object_fk=sql.Identifier(object_fk), trial=sql.Identifier('trial_used')
        )

    sql_kwargs = {"invoice_id": invoice_id}
    try:
        cursor.execute(sql_statement, sql_kwargs)
    except Exception as e:
        raise RealtyfeedException(error_message=f'Error In Get {object_type} Info From Invoice',
                                  error_status_code=DATABASE_ERROR,
                                  error_data=e.args)

    invoice_items = []
    for item in cursor:
        item = dict(item)
        if item['period_start']:
            item['period_start'] = item['period_start'].isoformat()
        if item['period_end']:
            item['period_end'] = item['period_end'].isoformat()
        invoice_items.append(item)
    return invoice_items


def get_promotion_detail_from_rds(cursor, promotion_id: int) -> dict or None:
    """
    get promotion details based on promotion id from rds
    @param cursor:
    @param promotion_id:
    @return: {"id": int, "name": str, "amount_off": float, "percent_off": decimal , "currency": str}
    """
    sql_statement = sql.SQL(
        "SELECT {pkey}, {name}, {amount_off}, {percent_off}, {currency} "
        "FROM {promotion_table} WHERE {pkey} = %(promotion_id)s"
    ).format(
        pkey=sql.Identifier('id'), name=sql.Identifier('name'), amount_off=sql.Identifier('amount_off'),
        currency=sql.Identifier('currency'), promotion_table=sql.Identifier('promotions'),
        percent_off=sql.Identifier('percent_off')
    )
    sql_kwargs = {'promotion_id': promotion_id}

    try:
        cursor.execute(sql_statement, sql_kwargs)

    except Exception as e:
        raise RealtyfeedException(error_message='Error In Get Promotion Detail From Database',
                                  error_status_code=DATABASE_ERROR,
                                  error_data=e.args)
    promotion_info = [dict(info) for info in cursor]
    if len(promotion_info) > 0:
        return promotion_info[0]
    else:
        return None


def get_packages_types_from_invoice_on_rds(cursor, invoice_id: int) -> list or None:
    """
    @param cursor:
    @param invoice_id:
    @return: {"type": int, "id": int}

    """
    sql_statement = sql.SQL(
        "SELECT {package_table}.{type}, {package_table}.{pkey} FROM {invoice_table} "
        "JOIN {invoice_item_package_table} ON {invoice_item_package_table}.{package_item_fk} = {invoice_table}.{pkey} "
        "JOIN {package_table} ON {package_table}.{pkey} = {invoice_item_package_table}.{package_fk}"
        "WHERE {invoice_table}.{pkey} = %(invoice_id)s"
    ).format(
        package_table=sql.Identifier('packages'), type=sql.Identifier('type'),
        package_fk=sql.Identifier('selected_package_id'),
        invoice_item_package_table=sql.Identifier('invoice_item_package'), pkey=sql.Identifier('id'),
        invoice_table=sql.Identifier('invoices'), package_item_fk=sql.Identifier('invoice_id')
    )
    sql_kwargs = {"invoice_id": invoice_id}
    package_types = {
        1: "Premium",
        2: "Privileged",
        3: "MLS",
        4: "Sponsored Listings",
        5: "Additional Services"
    }
    try:
        cursor.execute(sql_statement, sql_kwargs)

    except Exception as e:
        raise RealtyfeedException(error_message='Error In Get Package From Database',
                                  error_status_code=DATABASE_ERROR,
                                  error_data=e.args)
    packages_type_info = [dict(info) for info in cursor]
    if packages_type_info:
        for package_info in packages_type_info:
            package_info['type'] = package_types[package_info['type']]

        return packages_type_info
    else:
        return None


def get_btt_advantages_based_on_btt_item_id_from_rds(cursor, btt_type_item_id: int) -> list:
    """
    @param cursor:
    @param btt_type_item_id:
    @return:

    """
    sql_statement = sql.SQL(
        "SELECT {advantage_table}.{advantage_pkey} AS advantage_id FROM {btt_table} "
        "JOIN {advantage_table} ON {advantage_table}.{btt_fk} = {btt_table}.{pkey} "
        "WHERE {btt_table}.{pkey} = %(btt_type_item_id)s"
    ).format(
        advantage_table=sql.Identifier('btt_type_items_advantages_bridge'),
        advantage_pkey=sql.Identifier('btt_type_items_advantage_id'),
        btt_table=sql.Identifier('btt_type_items'), pkey=sql.Identifier('id'),
        btt_fk=sql.Identifier('btt_type_items_id')
    )
    sql_kwargs = {'btt_type_item_id': btt_type_item_id}
    try:
        advantage_info = []
        cursor.execute(sql_statement, sql_kwargs)
    except Exception as e:
        raise RealtyfeedException(
            error_message='Error In Get btt_advantages_id From Database',
            error_status_code=DATABASE_ERROR,
            error_data=e.args
        )

    btt_advantages_id = [dict(info) for info in cursor]
    if btt_advantages_id:
        advantage_detail = get_btt_type_item_details_from_rds(
            cursor=cursor,
            btt_type_item_id=btt_advantages_id[0]['advantage_id']
        )
        advantage_info.append(advantage_detail)
    return advantage_info


def get_btt_type_item_details_from_rds(cursor, btt_type_item_id: int) -> dict or None:
    """
    Get btt_type_item Details From RDS
    @param cursor:
    @param btt_type_item_id:
    @return: {
                "id": int,
                "name": str,
                "main_icon": str,
                "btt_types": {
                    "id": int,
                    "name": str,
                    "type": int
                    },
                'btt_advantages':
                 [
                    {
                        "id": int,
                        "name": str,
                        "main_icon": str,
                        "btt_types": {
                            "id": int,
                            "name": str,
                            "type": int},
                            }
                    }
                ]
            }
    }
    """
    sql_statement = sql.SQL(
        "SELECT {btt_table}.{pkey} AS btt_id, {btt_table}.{name} AS btt_name, {btt_table}.{main_icon}, "
        "{types_table}.{pkey} AS type_id, {types_table}.{name} AS type_name, {types_table}.{type} AS type_type "
        "FROM {btt_table} JOIN {types_table} ON {btt_table}.{types_fk} = {types_table}.{pkey} "
        "WHERE {btt_table}.{pkey} = %(btt_type_item_id)s"
    ).format(
        btt_table=sql.Identifier('btt_type_items'), pkey=sql.Identifier('id'), name=sql.Identifier('name'),
        main_icon=sql.Identifier('main_icon'), type=sql.Identifier('type'),
        types_table=sql.Identifier('btt_types'), types_fk=sql.Identifier('btt_types_id'),

    )
    sql_kwargs = {'btt_type_item_id': btt_type_item_id}
    btt_type_types = {
        "1": "Zipcode",
        "2": "Discount",
        "3": "Normal"
    }
    try:
        cursor.execute(sql_statement, sql_kwargs)

    except Exception as e:
        raise RealtyfeedException(error_message='Error In Get Btt Types Item Details From Database',
                                  error_status_code=DATABASE_ERROR,
                                  error_data=e.args)

    btt_details = [dict(info) for info in cursor]
    if len(btt_details) > 0:
        btt_detail = btt_details[0]
        advantage_info = get_btt_advantages_based_on_btt_item_id_from_rds(
            cursor=cursor, btt_type_item_id=btt_type_item_id)
        data = {
            "id": btt_detail['btt_id'],
            "name": btt_detail['btt_name'],
            "main_icon": btt_detail['main_icon'],
            "btt_types": {"id": btt_detail['type_id'],
                          "name": btt_detail['type_name'],
                          "type": btt_type_types[btt_detail['type_type']]},
            'btt_advantages': advantage_info
        }

        return data
    else:
        return None


def get_discount_from_rds(cursor, discount_id: int) -> dict or None:
    """
    Get Discount Detail Based On Discount Id From RDS
    @param cursor:
    @param discount_id:
    @return: {"id": int, "name": str, "amount_off": float, "percent_off": decimal , "currency": str}
    """
    sql_statement = sql.SQL(
        "SELECT {pkey}, {name}, {amount_off}, {percent_off}, {currency} "
        "FROM {discounts_table} WHERE {pkey} = %(discount_id)s"
    ).format(
        pkey=sql.Identifier('id'), name=sql.Identifier('name'), amount_off=sql.Identifier('amount_off'),
        currency=sql.Identifier('currency'), discounts_table=sql.Identifier('discounts'),
        percent_off=sql.Identifier('percent_off')
    )
    sql_kwargs = {'discount_id': discount_id}

    try:
        cursor.execute(sql_statement, sql_kwargs)
    except Exception as e:
        raise RealtyfeedException(
            error_message='Error In Get Discount Info From Database',
            error_status_code=DATABASE_ERROR,
            error_data=e.args[0]
        )
    discount_details = [dict(info) for info in cursor]
    if discount_details:
        return discount_details[0]
    else:
        return None


def get_price_detail_from_rds(cursor, payment_method_id: int) -> dict or None:
    """
    get price info for btt or package from payment_method
    @param cursor:
    @param payment_method_id:
    @return: {"id": int, "billing_schema": str, "unit_amount": int, "currency": str,
     "recurring_interval": str, "trial_period_days": int, "type": str }
    """
    sql_statement = sql.SQL(
        "SELECT {pkey}, {billing_schema}, "
        "COALESCE({price}, {decimal_price}) AS {price}"
        "{currency}, {type}, {recurring_interval}, {trial_period_days} "
        "FROM {payment_table} WHERE {pkey} = %(payment_method_id)s"
    ).format(pkey=sql.Identifier('id'), billing_schema=sql.Identifier('billing_schema'),
             price=sql.Identifier('unit_amount'), currency=sql.Identifier('currency'),
             type=sql.Identifier('type'), recurring_interval=sql.Identifier('recurring_interval'),
             trial_period_days=sql.Identifier('trial_period_days'), payment_table=sql.Identifier('payment_method'),
             decimal_price=sql.Identifier('unit_amount_decimal')
             )
    sql_kwargs = {"payment_method_id": payment_method_id}

    payment_method_types = {
        1: "one_time",
        2: "recurring"
    }

    try:
        cursor.execute(sql_statement, sql_kwargs)
    except Exception as e:
        raise RealtyfeedException(error_message='Error In Get Payment Method From Database',
                                  error_status_code=DATABASE_ERROR,
                                  error_data=e.args)
    payment_details = [dict(info) for info in cursor]
    if payment_details:
        payment_details[0]['type'] = payment_method_types[payment_details[0]['type']]
        return payment_details[0]
    else:
        return None


def get_package_description(cursor, package_id):
    sql_statement = sql.SQL(
        "SELECT {short_description}, {description}, {notice_description}, {condition}, {language} "
        "FROM {description_table} "
        "WHERE {package_fk} = %(package_id)s"
    ).format(
        language=sql.Identifier('language_id'),
        short_description=sql.Identifier('short_description'), description=sql.Identifier('description'),
        notice_description=sql.Identifier('notice_description'), condition=sql.Identifier('condition_description'),
        description_table=sql.Identifier('package_descriptions'), package_fk=sql.Identifier('package_id'),
    )
    sql_kwargs = {"package_id": package_id}
    try:
        cursor.execute(sql_statement, sql_kwargs)
    except Exception as e:
        raise RealtyfeedException(error_message='Error In Get Package Details From Database',
                                  error_status_code=DATABASE_ERROR,
                                  error_data=e.args)
    descriptions = [dict(info) for info in cursor]
    return descriptions


def get_package_info_from_rds(cursor, package_id: int) -> dict or None:
    """
    Get Package Detail From RDS
    @param cursor:
    @param package_id:
    @return:{
        "id": int, "type": int, "name": str, "multiple": bool, "descriptions": []

    """
    sql_statement = sql.SQL(
        "SELECT {package_table}.{pkey}, {package_table}.{type}, {package_table}.{multiple} "
        "FROM {package_table} "
        "WHERE {package_table}.{pkey} = %(package_id)s"
    ).format(
        package_table=sql.Identifier('packages'), pkey=sql.Identifier('id'), type=sql.Identifier('type'),
        name=sql.Identifier('name'), multiple=sql.Identifier('multiple')
    )

    sql_kwargs = {"package_id": package_id}
    package_types = {
        1: "Premium",
        2: "Privileged",
        3: "MLS",
        4: "Sponsored Listings",
        5: "Additional Services"
    }
    try:
        cursor.execute(sql_statement, sql_kwargs)
    except Exception as e:
        raise RealtyfeedException(error_message='Error In Get Package Details From Database',
                                  error_status_code=DATABASE_ERROR,
                                  error_data=e.args)

    package_info = [dict(info) for info in cursor]

    if package_info:
        package_info[0]['type'] = package_types[package_info[0]['type']]
        package_info[0]['descriptions'] = get_package_description(cursor=cursor, package_id=package_id)
        return package_info[0]
    else:
        return None


def get_zipcodes(cursor, btt_item_id: int) -> dict or None:
    """
    Get btt_types If Type is Zipcode
    @param cursor:
    @param btt_item_id:
    @return:
    """
    sql_statement = sql.SQL(
        "SELECT {btt_item_table}.{name}, {btt_item_table}.{pkey}, {btt_type_table}.{type} "
        "FROM {btt_item_table} JOIN {btt_type_table} ON {btt_item_table}.{btt_type_fk} = {btt_type_table}.{pkey} "
        "WHERE {btt_item_table}.{pkey} = %(btt_item_id)s"
    ).format(
        btt_item_table=sql.Identifier('btt_type_items'), name=sql.Identifier('name'), pkey=sql.Identifier('id'),
        btt_type_table=sql.Identifier('btt_types'), btt_type_fk=sql.Identifier('btt_types_id'),
        type=sql.Identifier('type')
    )
    sql_kwargs = {
        "btt_item_id": btt_item_id
    }
    try:
        cursor.execute(sql_statement, sql_kwargs)
    except Exception as e:
        raise RealtyfeedException(
            error_message='Error In Get Zipcodes From Database',
            error_status_code=DATABASE_ERROR,
            error_data=e.args
        )

    zipcode = [dict(info) for info in cursor]
    if not zipcode:
        return None
    if zipcode[0]['type'] == 1:
        return {
            "id": zipcode[0]['id'],
            'name': zipcode[0]['name']
        }
    else:
        return None


def get_btt_items_info_for_invoice_output(cursor, invoice_id: int) -> list:
    btt_items = get_invoice_item_object_details(
        cursor=cursor, invoice_id=invoice_id, object_type='btt'
    )
    btt_items_data = []
    if not btt_items:
        return btt_items_data

    for btt in btt_items:
        btt_applied_promotion = get_promotion_detail_from_rds(cursor=cursor, promotion_id=btt['promotion_id'])
        btt_applied_discount = get_discount_from_rds(cursor=cursor, discount_id=btt['discount_id'])
        btt_applied_price = get_price_detail_from_rds(
            cursor=cursor, payment_method_id=btt['selected_payment_method_id'])
        zipcode = get_zipcodes(cursor=cursor, btt_item_id=btt['id'])
        btt_type_items = get_btt_type_item_details_from_rds(
            cursor=cursor,
            btt_type_item_id=btt['selected_btt_type_items_id'])

        btt_object_data = {
            "id": btt['id'], "period_start": btt['period_start'], "period_end": btt['period_end'],
            'quantity': btt['quantity'],
            "applied_promotion": btt_applied_promotion if btt_applied_promotion else None,
            "applied_discount": btt_applied_discount if btt_applied_discount else None,
            "applied_price": btt_applied_price if btt_applied_price else None,
            "zipcode": zipcode if zipcode else None,
            "btt_type_items": btt_type_items if btt_type_items else None
        }
        btt_items_data.append(btt_object_data)
    return btt_items_data


def get_package_info_for_invoice_output(cursor, invoice_id: int) -> dict:
    packages_items = get_invoice_item_object_details(
        cursor=cursor, invoice_id=invoice_id, object_type='package'
    )
    packages_types = get_packages_types_from_invoice_on_rds(cursor=cursor, invoice_id=invoice_id)
    packages_info_detail = {}
    if not packages_types:
        return packages_info_detail

    for package_type in packages_types:
        packages_info_detail = {
            package_type['type']: []
        }

    for package in packages_items:
        package_applied_promotion = get_promotion_detail_from_rds(cursor=cursor, promotion_id=package['promotion_id'])
        package_applied_discount = get_discount_from_rds(cursor=cursor, discount_id=package['discount_id'])
        package_applied_price = get_price_detail_from_rds(cursor=cursor,
                                                          payment_method_id=package['selected_payment_method_id'])
        package_info = get_package_info_from_rds(cursor=cursor, package_id=package['selected_package_id'])
        data = {
            "id": package['id'], "period_start": package['period_start'], "period_end": package['period_end'],
            "quantity": package['quantity'], "trial_used": package['trial_used'],
            "applied_promotion": package_applied_promotion if package_applied_promotion else None,
            "applied_discount": package_applied_discount if package_applied_discount else None,
            "applied_price": package_applied_price if package_applied_price else None,
            'package_info': {
                "id": package_info['id'], "name": package_info['name'],
                "multiple": package_info['multiple'],
                "descriptions": package_info['descriptions']
            }
        }
        if package_info['type'] in packages_info_detail.keys():
            packages_info_detail[package_info['type']].append(data)
        else:
            packages_info_detail[package_info['type']] = [data]
    return packages_info_detail


def create_invoice_details(cursor, invoice_object: dict) -> dict:
    """
    @param cursor:

    @param invoice_object: {"id": int, "amount_due": int, "amount_paid": int, "amount_remaining": int,
     "application_fee_amount": int, "currency": str, "creation_date": datetime, "status": str }

    @return:

    """
    btt_items_data = get_btt_items_info_for_invoice_output(cursor=cursor, invoice_id=invoice_object['id'])
    packages_info_detail = get_package_info_for_invoice_output(cursor=cursor, invoice_id=invoice_object['id'])
    final_info = {
        "id": invoice_object['id'], 'status': invoice_object['status'], 'creation_date': invoice_object['creation_date']
        , "amount": {
            "without_discount": {
                "amount_due": invoice_object['amount_due'], "amount_paid": invoice_object['amount_paid'],
                "amount_remaining": invoice_object['amount_remaining'], "currency": invoice_object['currency'],
                "application_fee_amount": invoice_object['application_fee_amount']
            },
            "with_discount": {},
        },
        'btt_items': btt_items_data,
        'package_items': packages_info_detail
    }
    return final_info
