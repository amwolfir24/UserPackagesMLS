import json

import boto3
from botocore.exceptions import ClientError

from .exceptions import AmazonBoto3Exception, LambdaInvokeException, RealtyfeedException
from .datasets import streaming_body_to_dict


def call_lambda_function(function_name, payload=None, is_async=False, check_success=False):
    try:
        client = boto3.client('lambda', region_name='us-east-1')
    except:
        raise AmazonBoto3Exception(error_message="Cannot access AWS resource")

    invocation_type = 'Event' if is_async else 'RequestResponse'
    try:
        if payload:
            lambda_response = client.invoke(
                FunctionName=f'arn:aws:lambda:us-east-1:480279031583:function:{function_name}',
                InvocationType=invocation_type,
                Payload=json.dumps(payload)
            )
        else:
            lambda_response = client.invoke(
                FunctionName=f'arn:aws:lambda:us-east-1:480279031583:function:{function_name}',
                InvocationType=invocation_type,
            )
        if lambda_response['StatusCode'] not in (200, 202, 204):
            raise LambdaInvokeException(error_message=f"Calling `{function_name}` lambda function failed.")
    except ClientError as e:
        raise LambdaInvokeException(error_message=f"Calling `{function_name}` lambda function failed. {str(e)}")

    if not is_async:
        response_payload = lambda_response['Payload']
        response_payload = streaming_body_to_dict(response_payload)

        if check_success:
            if not response_payload.get('is_success', False):
                raise RealtyfeedException(
                    error_message=F"Error in calling `{function_name}` lambda function.",
                    error_data={'error': response_payload.get('error', response_payload.get('message', ''))}
                )

        return response_payload
