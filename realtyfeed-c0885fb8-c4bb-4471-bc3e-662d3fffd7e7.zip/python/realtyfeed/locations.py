import json
import datetime
import pytz
import boto3
import traceback
from typing import Tuple, Union
from psycopg2 import sql
from .orm import RDSHandler  # FIXME (add realtyfeed when testing as a lambda function)
from .exceptions import RealtyfeedException # FIXME (add realtyfeed when testing as a lambda function)
from .datasets import decimal_default, json_to_dict, \
    sample_response  # FIXME (add realtyfeed when testing as a lambda function)

class GraphSchema:
    def __init__(self, source_type: str, target_type: str, relation_name: str, source_id: int, target_id: int):
        self.source_type = source_type
        self.target_type = target_type
        self.relation_name = relation_name
        self.source_id = source_id
        self.target_id = target_id
        self.dct = {}

    def create_schema(self):
        self.dct = {
            "from": {
                "object_type": self.source_type,
                "object_id": int(self.source_id)
            },
            "to": {
                "object_type": self.target_type,
                "object_id": int(self.target_id)
            },
            "name": self.relation_name
        }
        return self.dct


def check_object_existence(cursor, object_id: int, object_type: str) -> None:
    """Checks whether an object exists in RDS DB or not"""
    table_name = f"{object_type}s"
    if object_type == "announcement":
        table_name = "announcement_and_shares"
    elif object_type == "btt":
        table_name = "btt_type_items"
    elif object_type == "inquiry":
        table_name = "lead_inquiries"

    get_object_statement = sql.SQL(
        "SELECT {pk} FROM {table_name} WHERE {pk}=%(id_value)s;"
    ).format(
        pk=sql.Identifier("id"),
        table_name=sql.Identifier(table_name),
    )
    get_object_kwargs = {'id_value': object_id}
    try:
        cursor.execute(get_object_statement, get_object_kwargs)
        object_record = cursor.fetchone()
    except Exception as e:
        raise RealtyfeedException(error_message=f"Error in 'check_object_existence' function: {str(e)}",
                                error_status_code=1006)
    if object_record is None:
        raise RealtyfeedException(error_message=f"{object_type} not found", error_status_code=1006,
                                error_data="'check_object_existence' function ")


def get_location_id(cursor, parent_location: int, location_name: str) -> dict:
    """Fetches id of a location from locations table (RDS)"""
    sql_statement = "SELECT id FROM {table_name} WHERE {name_column}=%(name)s;"
    if parent_location:
        sql_statement = "SELECT id FROM {table_name} WHERE {name_column}=%(name)s AND {parent_id}=%(" \
                        "parent_location_id)s; "

    get_location_statement = sql.SQL(
        sql_statement
    ).format(
        table_name=sql.Identifier("locations"),
        name_column=sql.Identifier("name"),
        parent_id=sql.Identifier("parent_id")
    )
    get_location_kwargs = {
        'name': location_name,
        'parent_location_id': parent_location
    } if parent_location else {'name': location_name}
    try:
        cursor.execute(get_location_statement, get_location_kwargs)
        location_record = cursor.fetchone()
    except Exception as e:
        raise RealtyfeedException(
            error_message=f"Error in 'get_location_id' function: {str(e)}", error_status_code=1006
        )
    return location_record


def insert_location(cursor, parent_location: int, location_name: str, current_level: int, abbr: str, rf_label: str):
    """Inserts a new location to locations table (RDS)"""
    sql_statement = "INSERT INTO {table_name} ({parent}, {name_key}, {abbr_key}, {level_key}, {label_key}) " \
                    "VALUES (%(parent_value)s, %(name_value)s, %(abbr_value)s, %(level_value)s, %(label_value)s) " \
                    "RETURNING id"
    insert_location_statement = sql.SQL(sql_statement).format(
        table_name=sql.Identifier("locations"),
        parent=sql.Identifier("parent_id"),
        name_key=sql.Identifier("name"),
        abbr_key=sql.Identifier("abbr"),
        level_key=sql.Identifier("level"),
        label_key=sql.Identifier("label")
    )
    insert_location_kwargs = {'parent_value': parent_location, 'name_value': location_name, 'abbr_value': abbr,
                              "level_value": current_level, "label_value": rf_label}

    try:
        cursor.execute(insert_location_statement, insert_location_kwargs)
        location_record = cursor.fetchone()
    except Exception as e:
        raise RealtyfeedException(
            error_message=f"Error in 'insert_location' function: {str(e)}", error_status_code=1006
        )
    return location_record


def insert_zipcode(cursor, zipcode: str, zipcode_label: str, creation_date: datetime) -> int:
    """
    Inserts a zipcode to zipcodes table and returns id
    """
    sql_statement = "INSERT INTO {table_name} ({name_key}, {label_key}, {date_key} ) " \
                    "VALUES (%(name_value)s, %(label_value)s, %(creation_date_value)s ) " \
                    "RETURNING id"
    zip_code_insert = sql.SQL(
        sql_statement
    ).format(
        table_name=sql.Identifier("zipcodes"),
        name_key=sql.Identifier("name"),
        label_key=sql.Identifier("label"),
        date_key=sql.Identifier("creation_date")
    )
    zip_code_insert_kwarg = {
        "name_value": zipcode,
        "label_value": zipcode_label,
        "creation_date_value": creation_date
    }
    try:
        cursor.execute(zip_code_insert, zip_code_insert_kwarg)
        zipcode_id = cursor.fetchone()['id']
    except Exception as e:
        raise RealtyfeedException(
            error_message=f"Error in 'insert_zipcode' function: {str(e)}", error_status_code=1006
        )
    return zipcode_id


def insert_zipcode_bridge(cursor, location_id: int, zipcode_id: int, creation_date: datetime) -> None:
    """Inserts zipcode_id and location_id to zipcodes_bridge table"""
    zb_sql_statement = "INSERT INTO {table_name} ({location_id_column}, {zipcode_id_column}, " \
                       "{date_column}) " \
                       "VALUES (%(location_id_value)s, %(zipcode_id_value)s, %(creation_date_value)s)"
    zipcodes_bridge_insert = sql.SQL(
        zb_sql_statement
    ).format(
        table_name=sql.Identifier("zipcodes_bridge"),
        location_id_column=sql.Identifier("location_id"),
        zipcode_id_column=sql.Identifier("zipcode_id"),
        date_column=sql.Identifier("creation_date")

    )
    zb_insert_kwargs = {
        "location_id_value": location_id,
        "zipcode_id_value": zipcode_id,
        "creation_date_value": creation_date
    }
    try:
        cursor.execute(zipcodes_bridge_insert, zb_insert_kwargs)
    except Exception as e:
        raise RealtyfeedException(
            error_message=f"Error in 'insert_zipcode_bridge' function: {str(e)}",
            error_status_code=1006)


def get_zipcode_id(cursor, zipcode_label: str) -> int:
    """Fetches id of a zipcode from zipcodes table (RDS)"""
    zipcode_sql_statement = "SELECT id FROM {table_name} WHERE {label_column}=%(label_value)s"
    zipcode_select = sql.SQL(
        zipcode_sql_statement
    ).format(
        table_name=sql.Identifier("zipcodes"),
        label_column=sql.Identifier("label")
    )
    zipcode_select_kwargs = {
        "label_value": zipcode_label
    }
    try:
        cursor.execute(zipcode_select, zipcode_select_kwargs)
        zip_code_id = cursor.fetchone()
    except Exception as e:
        raise RealtyfeedException(
            error_message=f"Error in 'get_zipcode_id' function: {str(e)}", error_status_code=1006
        )
    return zip_code_id['id'] if zip_code_id else None


def create_input_for_elasticsearch(es_payload: dict, location_dct: dict, rf_label: str, level: int,
                                   parent_location: int) -> None:
    try:
        es_payload['create'].append(
            {
                "Country": location_dct['country'],
                "Geometry": location_dct['geometry'],
                "Label": rf_label,
                "Municipality": location_dct['city'],
                "PostalCode": location_dct['zipcode'],
                "Region": location_dct['region'],
                "SubRegion": location_dct['subregion'],
                "Street": location_dct['street'],
                "AddressNumber": location_dct['address_number'],
                "level": level,
                "location_id": parent_location,
                "zipcode_id": location_dct.get('zipcode_id'),
                "neighborhood_id": location_dct.get('neighborhood_id')
            }
        )
    except Exception as e:
        raise RealtyfeedException(error_message=f"Error in 'create_input_for_elasticsearch' function: {str(e)}",
                                  error_status_code=1000)


def create_zipcode_for_graph_input(graph_create: list, zipcode_id: int, zipcode: str):
    try:
        graph_create.append(
            {
                "object_type": "ZipCode",
                "object_id": zipcode_id,
                "name": zipcode,
            }
        )
    except Exception as e:
        raise RealtyfeedException(error_message=f"Error in 'create_zipcode_for_graph_input' function: {str(e)}",
                                  error_status_code=1000)


def insert_into_user_location(cursor, object_location_input: dict, is_zipcode: bool, creation_date: datetime) -> int:
    """Inserts a row into user_locations table"""
    insert_specific_location_statement = sql.SQL(
        "INSERT INTO {table} "
        "({location_id}, {object_id_column}, {type_column}, {zipcode_fk}, {coordinates_column}, {creation_date}, "
        "{modification_date}) "
        "VALUES (%(location_id_value)s, %(object_id)s, %(object_type)s, %(zipcode_id_value)s, %(coordinates)s,  "
        "%(creation_date_value)s, %(modification_date_value)s) "
        "RETURNING id"
    ).format(
        table=sql.Identifier(object_location_input['table']),
        location_id=sql.Identifier("location_id"),
        object_id_column=sql.Identifier(object_location_input['object_id_column']),
        type_column=sql.Identifier("type"),
        zipcode_fk=sql.Identifier("zipcode_id"),
        coordinates_column=sql.Identifier("coordinates"),
        creation_date=sql.Identifier("creation_date"),
        modification_date=sql.Identifier("modification_date")
    )
    insert_specific_location_kwargs = {
        'location_id_value': object_location_input['parent_location'],
        'object_id': object_location_input['object_id'],
        'object_type': object_location_input['type'],
        'zipcode_id_value': object_location_input['zipcode_id'] if is_zipcode else None,
        'coordinates': object_location_input['coordinates'],
        'creation_date_value': creation_date,
        'modification_date_value': creation_date
    }
    try:
        cursor.execute(insert_specific_location_statement, insert_specific_location_kwargs)
        specific_location_insert = cursor.fetchone()['id']
    except Exception as e:
        raise RealtyfeedException(
            error_message=f"Error in 'insert_into_user_location' function: {str(e)}",
            error_status_code=1006
        )
    return specific_location_insert


def insert_into_group_location(cursor, object_location_input: dict, creation_date: datetime) -> int:
    """Inserts a row into group_locations table"""
    insert_statement = "INSERT INTO {table_name} ({location_id}, {object_id_column}, {type_column}, " \
                       "{coordinates_column}, {creation_date}, {modification_date}, {zipcode_id}) " \
                       "VALUES (%(location_id_value)s, %(object_id)s, %(type_value)s, %(coordinates_value)s, " \
                       "%(creation_date_value)s, %(modification_date_value)s, %(zipcode_id_value)s) RETURNING id "
    insert_specific_location_statement = sql.SQL(insert_statement).format(
        table_name=sql.Identifier(object_location_input['table']),
        location_id=sql.Identifier("location_id"),
        object_id_column=sql.Identifier(object_location_input['object_id_column']),
        type_column=sql.Identifier("type"),
        coordinates_column=sql.Identifier("coordinates"),
        creation_date=sql.Identifier("creation_date"),
        modification_date=sql.Identifier("modification_date"),
        zipcode_id=sql.Identifier("zipcode_id")
    )
    insert_specific_location_kwargs = {
        'object_id': object_location_input['object_id'], 'type_value': object_location_input['type'],
        'location_id_value': object_location_input['parent_location'],
        "coordinates_value": object_location_input['coordinates'], 'creation_date_value': creation_date,
        'modification_date_value': creation_date, "zipcode_id_value": object_location_input['zipcode_id']
    }
    try:
        cursor.execute(insert_specific_location_statement, insert_specific_location_kwargs)
        specific_location_insert = cursor.fetchone()['id']
    except Exception as e:
        raise RealtyfeedException(
            error_message=f"Error in 'insert_into_group_location' function: {str(e)}", 
            error_status_code=1006
        )
    return specific_location_insert


def insert_into_inquiry_location(cursor, object_location_input: dict, inquiry_value: str,
                                 creation_date: datetime) -> None:
    """Inserts a row into inquiry_location table"""
    raw_insert_statement = "INSERT INTO {table_name} ({location_id_column}, {inquiry_id_column}, " \
                           "{value_column}, {creation_date_column}) " \
                           "VALUES (%(location_id_value)s, %(object_id_value)s, %(value_value)s, " \
                           "%(creation_date_value)s) RETURNING id"
    insert_specific_location_statement = sql.SQL(raw_insert_statement).format(
        table_name=sql.Identifier(object_location_input['table']),
        location_id_column=sql.Identifier("location_id"),
        inquiry_id_column=sql.Identifier(object_location_input['object_id_column']),
        value_column=sql.Identifier('value'),
        creation_date_column=sql.Identifier('creation_date')
    )
    insert_specific_location_kwargs = {
        "location_id_value": object_location_input['parent_location'],
        "object_id_value": object_location_input['object_id'],
        "value_value": inquiry_value,
        "creation_date_value": creation_date
    }
    try:
        cursor.execute(insert_specific_location_statement, insert_specific_location_kwargs)
    except Exception as e:
        raise RealtyfeedException(
            error_message=f"Error in 'insert_into_inquiry_location' function: {str(e)}",
            error_status_code=1006
        )


def insert_into_btt_location(cursor, object_location_input: dict, creation_date: datetime) -> None:
    sql_statement = "INSERT INTO {table_name} ({location_id_column}, {btt_id_column}, {creation_date_column}) " \
                    "VALUES (%(location_id_value)s, %(object_id_value)s, %(creation_date_value)s) RETURNING id"
    sql_command = sql.SQL(sql_statement).format(
        table_name=sql.Identifier(object_location_input['table']), location_id_column=sql.Identifier("location_id"),
        btt_id_column=sql.Identifier(object_location_input['object_id_column']),
        creation_date_column=sql.Identifier('creation_date')
    )
    sql_kwargs = {
        "location_id_value": object_location_input['parent_location'],
        "object_id_value": object_location_input['object_id'], "creation_date_value": creation_date
    }
    try:
        cursor.execute(sql_command, sql_kwargs)
    except Exception as e:
        raise RealtyfeedException(
            error_message=f"Error in 'insert_into_btt_location' function: {str(e)}",
            error_status_code=1006
        )


def insert_into_package_location(cursor, object_location_input: dict, creation_date: datetime) -> None:
    sql_statement = "INSERT INTO {table_name} ({object_id_column}, {location_id_column}, {creation_date_column}) " \
                    "VALUES (%(object_id_value)s, %(location_id_value)s, " \
                    "%(creation_date_value)s) RETURNING {pk}"
    sql_command = sql.SQL(sql_statement).format(
        table_name=sql.Identifier(object_location_input['table']),
        object_id_column=sql.Identifier(object_location_input['object_id_column']),
        location_id_column=sql.Identifier("location_id"),
        creation_date_column=sql.Identifier('creation_date'),
        pk=sql.Identifier("id")
    )
    sql_kwargs = {
        "object_id_value": object_location_input['object_id'],
        "location_id_value": object_location_input['parent_location'],
        "creation_date_value": creation_date
    }
    try:
        cursor.execute(sql_command, sql_kwargs)
    except Exception as e:
        raise RealtyfeedException(
            error_message=f"Error in 'insert_into_package_location' function: {str(e)}",
            error_status_code=1006
        )


def update_location_id_in_announcement(cursor, object_id: int, location_id: int, operation=None) -> bool:
    """Updates location_id in announcement_and_shares table if location_id is Null"""
    sql_statement = "UPDATE {table_name} " \
                    "SET {location_fk} = %(location_id_value)s " \
                    "WHERE {pk} = %(object_id_value)s AND {location_fk} IS NULL RETURNING {pk}"
    if operation == "update":
        sql_statement = "UPDATE {table_name} " \
                        "SET {location_fk} = %(location_id_value)s " \
                        "WHERE {pk} = %(object_id_value)s AND {location_fk} IS NOT NULL RETURNING {pk}"
    sql_command = sql.SQL(sql_statement).format(
        table_name=sql.Identifier("announcement_and_shares"),
        location_fk=sql.Identifier("location_id"),
        pk=sql.Identifier("id")
    )
    sql_kwargs = {"location_id_value": location_id, "object_id_value": object_id, }
    try:
        cursor.execute(sql_command, sql_kwargs)
        updated = cursor.fetchone()
    except Exception as e:
        raise RealtyfeedException(
            error_message=f"Error in 'update_location_id_in_announcement' function: {str(e)}",
            error_status_code=1006
        )
    return True if updated else False


def create_stats(stats_create: list, object_type, object_id):
    try:
        stats_create.append(
            {
                "object_type": object_type,
                "object_id": object_id
            }
        )
    except Exception as e:
        raise RealtyfeedException(error_message=f"Error in 'create_stats' function: {str(e)}",
                                  error_status_code=1000)


def does_object_have_location_already(cursor, object_location_input: dict) -> bool:
    """To check if the object have any location with types that can have only one row like user_location
    (address, country)"""
    raw_sql_statement = "SELECT {pk} FROM {table_name} WHERE {object_id_key}=%(object_id_value)s AND " \
                        "{type_key}=%(location_type)s"
    sql_command = sql.SQL(raw_sql_statement).format(
        pk=sql.Identifier("id"), table_name=sql.Identifier(object_location_input['table']),
        object_id_key=sql.Identifier(object_location_input['object_id_column']), type_key=sql.Identifier("type")
    )
    sql_kwargs = {"object_id_value": object_location_input['object_id'],
                  "location_type": object_location_input['type']}
    try:
        cursor.execute(sql_command, sql_kwargs)
        exists = cursor.fetchone()
    except Exception as e:
        raise RealtyfeedException(
            error_message=f"Error in 'does_object_have_location_already' function: {str(e)}",
            error_status_code=1006
        )
    return True if exists else False


def does_object_location_exist_already(cursor, object_location_input: dict) -> bool:
    if object_location_input['object_type'] in ["user", "group"]:
        raw_sql_statement = "SELECT {id_column} FROM {table_name} " \
                            "WHERE {object_id_column}=%(object_id)s AND {location_id_column}=%(location_id_value)s " \
                            "AND {type_column}=%(type_value)s"
        sql_statement = sql.SQL(raw_sql_statement).format(
            id_column=sql.Identifier('id'), table_name=sql.Identifier(object_location_input['table']),
            object_id_column=sql.Identifier(object_location_input['object_id_column']),
            type_column=sql.Identifier('type'),
            location_id_column=sql.Identifier('location_id')
        )
        sql_kwargs = {'object_id': object_location_input['object_id'],
                      'location_id_value': object_location_input['parent_location'],
                      'type_value': object_location_input['type']}
    else:
        # ------------- check inquiry_locations, package_locations and btt_locations tables ----------
        raw_sql_statement = "SELECT {id_column} FROM {table_name} " \
                            "WHERE {object_id_column}=%(object_id_value)s AND " \
                            "{location_id_column}=%(location_id_value)s"
        sql_statement = sql.SQL(raw_sql_statement).format(
            id_column=sql.Identifier('id'), table_name=sql.Identifier(object_location_input['table']),
            object_id_column=sql.Identifier(object_location_input['object_id_column']),
            location_id_column=sql.Identifier('location_id')
        )
        sql_kwargs = {"object_id_value": object_location_input['object_id'],
                      "location_id_value": object_location_input['parent_location']}
    try:
        cursor.execute(sql_statement, sql_kwargs)
        detail = cursor.fetchall()
    except Exception as e:
        raise RealtyfeedException(
            error_message=f"Error in 'check_existence_of_object_location' function: {str(e)}",
            error_status_code=1006
        )
    if detail:
        return True
    return False


def update_user_location(cursor, object_location_input: dict, creation_date: datetime) -> bool:
    raw_sql_statement = "UPDATE {table_name} " \
                        "SET {location_fkey}=%(location_id_value)s, {coordinates_key}=%(coordinates_value)s, " \
                        "{modification_date_key}=%(creation_date_value)s " \
                        "WHERE {pk}=%(pk_value)s AND {user_fk}=%(object_id_value)s AND {type_key}=%(type_value)s;"
    sql_command = sql.SQL(raw_sql_statement).format(
        table_name=sql.Identifier(object_location_input['table']), location_fkey=sql.Identifier("location_id"),
        user_fk=sql.Identifier("user_id"), type_key=sql.Identifier("type"),
        coordinates_key=sql.Identifier("coordinates"), modification_date_key=sql.Identifier("modification_date"),
        pk=sql.Identifier("id")
    )
    sql_kwargs = {
        'location_id_value': object_location_input['parent_location'],
        'object_id_value': object_location_input['object_id'],
        'type_value': object_location_input['type'],
        'coordinates_value': object_location_input['coordinates'],
        'creation_date_value': creation_date,
        "pk_value": object_location_input["object_location_id"]
    }
    try:
        cursor.execute(sql_command, sql_kwargs)
        rowcount = cursor.rowcount
    except Exception as e:
        raise RealtyfeedException(
            error_message=f"Error in 'update_user_location' function: {str(e)}",
            error_status_code=1006
        )
    return True if rowcount > 0 else False


def update_listing(cursor, object_location_input: dict, operation=None) -> bool:
    """Update listing location information"""
    sql_statement = "UPDATE {table_name} " \
                    "SET {location_fk}=%(location_id_value)s, {zipcode_fk} = %(zipcode_id_value)s, " \
                    "{neighborhood_fk} = %(neighborhood_id_value)s " \
                    "WHERE {pk} = %(object_id_value)s "

    if operation != "update":
        sql_statement += "AND {location_fk} IS NULL RETURNING {pk}"
    else:
        sql_statement += "AND {location_fk} IS NOT NULL RETURNING {pk}"

    sql_command = sql.SQL(sql_statement).format(
        table_name=sql.Identifier("listings"),
        location_fk=sql.Identifier("location_id"),
        zipcode_fk=sql.Identifier("zipcode_id"),
        neighborhood_fk=sql.Identifier("neighborhood_id"),
        pk=sql.Identifier("id"),
    )
    sql_kwargs = {
        "location_id_value": object_location_input['parent_location'],
        "zipcode_id_value": object_location_input['zipcode_id'],
        "neighborhood_id_value": object_location_input['neighborhood_id'],
        "object_id_value": object_location_input['object_id'],
    }
    try:
        cursor.execute(sql_command, sql_kwargs)
        updated = cursor.rowcount
    except Exception as e:
        raise RealtyfeedException(
            error_message="Error in 'update_listing' function", error_data=str(e), error_status_code=1006
        )
    return True if updated > 0 else False


def update_group_location(cursor, object_location_input: dict, creation_date: datetime) -> bool:
    raw_sql_statement = "UPDATE {table_name} " \
                        "SET {location_fkey}=%(location_id_value)s, {coordinates_key}=%(coordinates_value)s, " \
                        "{zipcode_fk}=%(zipcode_id_value)s, {modification_date_key}=%(creation_date_value)s " \
                        "WHERE {pk}=%(object_location_id_value)s AND {group_fk}=%(object_id_value)s AND " \
                        "{type_key}=%(type_value)s"
    sql_command = sql.SQL(raw_sql_statement).format(
        table_name=sql.Identifier(object_location_input['table']),
        location_fkey=sql.Identifier("location_id"),
        type_key=sql.Identifier("type"),
        coordinates_key=sql.Identifier("coordinates"),
        zipcode_fk=sql.Identifier("zipcode_id"),
        modification_date_key=sql.Identifier("modification_date"),
        pk=sql.Identifier("id"),
        group_fk=sql.Identifier("group_id")
    )
    sql_kwargs = {
        "location_id_value": object_location_input['parent_location'],
        "type_value": object_location_input['type'],
        "coordinates_value": object_location_input['coordinates'],
        "zipcode_id_value": object_location_input['zipcode_id'],
        "creation_date_value": creation_date,
        "object_location_id_value": object_location_input["object_location_id"],
        "object_id_value": object_location_input['object_id']
    }
    try:
        cursor.execute(sql_command, sql_kwargs)
        updated = cursor.rowcount
    except Exception as e:
        raise RealtyfeedException(
            error_message=f"Error in 'update_group_location' function: {str(e)}",
            error_status_code=1006
        )
    return True if updated > 0 else False


def update_inquiry_location(cursor, object_location_input: dict, inquiry_value: str) -> None:
    """Updates inquiry_location table by checking both pk and object_id to prevent mistakes"""
    raw_sql_statement = "UPDATE {table_name} " \
                        "SET {location_fkey}=%(location_id_value)s, {value_key}=%(value_value)s" \
                        "WHERE {pk}=%(pk_value)s AND {inquiry_fkey}=%(object_id_value)s "
    sql_command = sql.SQL(raw_sql_statement).format(
        table_name=sql.Identifier(object_location_input['table']),
        location_fkey=sql.Identifier("location_id"),
        value_key=sql.Identifier("value"),
        pk=sql.Identifier("id"),
        inquiry_fkey=sql.Identifier(object_location_input['object_id_column'])
    )
    sql_kwargs = {
        "location_id_value": object_location_input['parent_location'],
        "value_value": inquiry_value,
        "pk_value": object_location_input["object_location_id"],
        "object_id_value": object_location_input['object_id']
    }
    try:
        cursor.execute(sql_command, sql_kwargs)
    except Exception as e:
        raise RealtyfeedException(
            error_message=f"Error in 'update_inquiry_location' function: {str(e)}",
            error_status_code=1006
        )


def update_btt_location(cursor, object_location_input: dict, creation_date: datetime) -> None:
    """Updates BTT_location table by checking both pk and object_id to prevent mistakes"""
    raw_sql_statement = "UPDATE {table_name} " \
                        "SET {location_fkey}=%(location_id_value)s,  " \
                        "{creation_date_key}=%(creation_date_value)s " \
                        "WHERE {pk}=%(pk_value)s AND {btt_fkey}=%(object_id_value)s"
    sql_command = sql.SQL(raw_sql_statement).format(
        table_name=sql.Identifier(object_location_input['table']),
        location_fkey=sql.Identifier("location_id"),
        creation_date_key=sql.Identifier("creation_date"),
        pk=sql.Identifier("id"),
        btt_fkey=sql.Identifier(object_location_input['object_id_column'])
    )
    sql_kwargs = {
        "location_id_value": object_location_input['parent_location'],
        "creation_date_value": creation_date,
        "pk_value": object_location_input['object_location_id'],
        "object_id_value": object_location_input['object_id']
    }
    try:
        cursor.execute(sql_command, sql_kwargs)
    except Exception as e:
        raise RealtyfeedException(
            error_message=f"Error in 'update_btt_location' function: {str(e)}",
            error_status_code=1006
        )


def update_package_location(cursor, object_location_input: dict, creation_date: datetime) -> None:
    raw_sql_statement = "UPDATE {table_name} " \
                        "SET {location_fkey}=%(location_id_value)s, {creation_date_key}=%(creation_date_value)s " \
                        "WHERE {pk}=%(pk_value)s AND {package_fkey}=%(object_id_value)s;"
    sql_command = sql.SQL(raw_sql_statement).format(
        table_name=sql.Identifier(object_location_input['table']),
        location_fkey=sql.Identifier("location_id"),
        creation_date_key=sql.Identifier("creation_date"),
        pk=sql.Identifier("id"),
        package_fkey=sql.Identifier(object_location_input['object_id_column']),
    )
    sql_kwargs = {
        "location_id_value": object_location_input['parent_location'],
        "creation_date_value": creation_date,
        "pk_value": object_location_input['object_location_id'],
        "object_id_value": object_location_input['object_id']
    }
    try:
        cursor.execute(sql_command, sql_kwargs)
    except Exception as e:
        raise RealtyfeedException(
            error_message=f"Error in 'update_package_location' function: {str(e)}",
            error_status_code=1006
        )


def get_old_location_id(cursor, object_location_input: dict) -> dict:  # TODO: Fix this function
    """Get previous location id of desired location object"""
    if object_location_input['object_type'] == "user":
        sql_statement = "SELECT {location_fk}, {zipcode_fk} FROM {table_name} " \
                        "WHERE {pk} = %(object_id_value)s"
        sql_command = sql.SQL(sql_statement).format(
            location_fk=sql.Identifier("location_id"),
            zipcode_fk=sql.Identifier("zipcode_id"),
            table_name=sql.Identifier("user_locations"),
            pk=sql.Identifier("id")
        )
        sql_kwargs = {"object_id_value": object_location_input['object_location_id']}
    elif object_location_input['object_type'] == "listing":
        sql_statement = "SELECT {location_fk}, {zipcode_fk}, {neighborhood_fk} FROM {table_name} " \
                        "WHERE {pk} = %(object_id_value)s"
        sql_command = sql.SQL(sql_statement).format(
            location_fk=sql.Identifier("location_id"),
            zipcode_fk=sql.Identifier("zipcode_id"),
            neighborhood_fk=sql.Identifier("neighborhood_id"),
            table_name=sql.Identifier("listings"),
            pk=sql.Identifier("id")
        )
        sql_kwargs = {"object_id_value": object_location_input['object_id']}
    elif object_location_input['object_type'] == "announcement":
        sql_statement = "SELECT {location_fk} FROM {table_name} " \
                        "WHERE {pk} = %(object_id_value)s"
        sql_command = sql.SQL(sql_statement).format(
            location_fk=sql.Identifier("location_id"),
            table_name=sql.Identifier("announcement_and_shares"),
            pk=sql.Identifier("id")
        )
        sql_kwargs = {"object_id_value": object_location_input['object_id']}
    else:
        raw_sql_statement = "SELECT {location_fkey} FROM {table_name} " \
                            "WHERE {pk}=%(pk_value)s"
        sql_command = sql.SQL(raw_sql_statement).format(
            location_fkey=sql.Identifier("location_id"),
            table_name=sql.Identifier(object_location_input['table']),
            pk=sql.Identifier("id")
        )
        sql_kwargs = {"pk_value": object_location_input['object_location_id']}
    try:
        cursor.execute(sql_command, sql_kwargs)
        result = cursor.fetchone()
    except Exception as e:
        raise RealtyfeedException(
            error_message=f"Error in 'get_old_location_id' function: {str(e)}",
            error_status_code=1006
        )
    if not result:
        raise RealtyfeedException(error_message="Invalid relation id", error_status_code=1001)
    return result


def delete_object_location(cursor, table: str, object_location_id: int, type_item: int) -> dict:
    sql_statement = "DELETE FROM {table_name} WHERE {pk}=%(pk_value)s"
    sql_kwargs = {"pk_value": object_location_id}

    if table in ["user_locations", "group_locations"]:
        if type_item:
            sql_statement += " and type=%(type_value)s RETURNING {location_fkey}, {zipcode_fk}"
            sql_kwargs["type_value"] = type_item
        else:
            sql_statement += " RETURNING {location_fkey}, {zipcode_fk}"
    else:
        sql_statement += " RETURNING {location_fkey}"

    sql_command = sql.SQL(sql_statement).format(
        table_name=sql.Identifier(table),
        pk=sql.Identifier("id"),
        location_fkey=sql.Identifier("location_id"),
        zipcode_fk=sql.Identifier("zipcode_id")
    )

    try:
        cursor.execute(sql_command, sql_kwargs)
        result = cursor.fetchone()
        result = {"old_location_id": result["location_id"], "old_zipcode_id": result.get("zipcode_id")}
    except TypeError as e:
        raise RealtyfeedException(error_message="Invalid 'object_location_id'", error_status_code=1001)
    except Exception as e:
        raise RealtyfeedException(error_message=f"Error in 'delete_object_location' function: {str(e)}",
                                error_status_code=1006)
    return result


def location_processor(cursor, location_processor_input: dict) -> dict:
    """Gets location_id from RDS if exists otherwise inserts the new location and create node and its relation"""
    parent_location = None
    is_new_location = False
    current_level = None
    location_name = ""
    rf_label = ""

    for loc in location_processor_input['location_names_and_levels']:
        location_name = loc[0]
        current_level = loc[1]
        if current_level == 1:
            rf_label = location_name  # country
        else:
            rf_label = str(location_name + ", " + rf_label)
        location_record = get_location_id(cursor, parent_location, location_name)
        if not location_record:
            is_new_location = True
            # --------- Insert to location table -----------------------------------
            location_record = insert_location(cursor, parent_location, location_name, current_level,
                                              location_processor_input['abbr'], rf_label)
            # --------- graph_input node creation and relationship ------------------
            location_processor_input['graph_create'].append(
                {
                    "object_type": "Location",
                    "object_id": int(location_record['id']),
                    "name": location_name,
                    "level": loc[1],
                    "creation_date": location_processor_input['creation_date']
                }
            )
            if parent_location:
                parent_relation = GraphSchema(source_type="Location", target_type="Location", relation_name="Parent",
                                              source_id=int(location_record['id']), target_id=int(parent_location))
                location_processor_input['graph_relations_add'].append(parent_relation.create_schema())

        parent_location = location_record['id']

    location_processor_response = {
        "parent_location": parent_location,
        "rf_label": rf_label,
        "current_level": current_level,
        "is_new_location": is_new_location,
        "current_location_name": location_name
    }
    return location_processor_response


def get_neighborhood_id(cursor, neighborhood_label: str) -> int:
    """Gets id of the neighborhood from RDS"""
    sql_statement = "SELECT {pk} FROM {table_name} WHERE {label_column}=%(label_value)s"
    sql_command = sql.SQL(
        sql_statement
    ).format(
        pk=sql.Identifier("id"),
        table_name=sql.Identifier("neighborhoods"),
        label_column=sql.Identifier("label")
    )
    sql_kwargs = {
        "label_value": neighborhood_label
    }
    try:
        cursor.execute(sql_command, sql_kwargs)
        neighborhood_id = cursor.fetchone()
    except Exception as e:
        raise RealtyfeedException(
            error_message=f"Error in 'get_neighborhood_id' function: {str(e)}",
            error_status_code=1006
        )
    return neighborhood_id['id'] if neighborhood_id else None


def insert_neighborhood(cursor, neighborhood_name: str, neighborhoods_label: str, creation_date: datetime) -> int:
    """
        Inserts a neighborhood to neighborhoods table and returns its id
    """
    sql_statement = "INSERT INTO {table_name} ({name_column}, {label_key}, {date_column}) " \
                    "VALUES (%(name_value)s, %(neighborhoods_label_value)s, %(creation_date_value)s ) " \
                    "RETURNING id"
    sql_command = sql.SQL(
        sql_statement
    ).format(
        table_name=sql.Identifier("neighborhoods"),
        name_column=sql.Identifier("name"),
        label_key=sql.Identifier("label"),
        date_column=sql.Identifier("creation_date")
    )
    sql_kwarg = {
        "name_value": neighborhood_name,
        "neighborhoods_label_value": neighborhoods_label,
        "creation_date_value": creation_date
    }
    try:
        cursor.execute(sql_command, sql_kwarg)
        neighborhood_id = cursor.fetchone()['id']
    except Exception as e:
        raise RealtyfeedException(
            error_message=f"Error in 'insert_neighborhood' function", error_data=str(e), error_status_code=1006
        )
    return neighborhood_id


def create_neighborhood_for_graph_input(graph_create: list, neighborhood_id: int, neighborhood: str) -> None:
    """appends neighborhood to graph_input as a Node"""
    try:
        graph_create.append(
            {
                "object_type": "Neighborhood",
                "object_id": neighborhood_id,
                "name": neighborhood,
            }
        )
    except Exception as e:
        raise RealtyfeedException(error_message=f"Error in 'create_neighborhood_for_graph_input' function: {str(e)}",
                                  error_status_code=1000)


def insert_neighborhood_bridge(cursor, location_id: int, neighborhood_id: int, creation_date: datetime) -> None:
    """Inserts neighborhood_id, location_id and creation_date to neighborhoods_bridge table"""
    sql_statement = "INSERT INTO {table_name} ({location_id_column}, {neighborhood_id_column}, " \
                    "{date_column}) " \
                    "VALUES (%(location_id_value)s, %(neighborhood_id_value)s, %(creation_date_value)s)"
    sql_command = sql.SQL(
        sql_statement
    ).format(
        table_name=sql.Identifier("neighborhoods_bridge"),
        location_id_column=sql.Identifier("location_id"),
        neighborhood_id_column=sql.Identifier("neighborhood_id"),
        date_column=sql.Identifier("creation_date")
    )
    sql_kwargs = {
        "location_id_value": location_id,
        "neighborhood_id_value": neighborhood_id,
        "creation_date_value": creation_date
    }
    try:
        cursor.execute(sql_command, sql_kwargs)
    except Exception as e:
        raise RealtyfeedException(
            error_message=f"Error in 'insert_neighborhood_bridge' function: {str(e)}",
            error_status_code=1006
        )


def update_address_in_groups(cursor, object_id: int, label: str, location_extra_data: dict,
                             operation: str = None) -> bool:
    """Updates address field of groups table if address field is null. if key_flag=update address must NOT be Null"""
    sql_statement = "UPDATE {table_name} " \
                    "SET {full_address_key}=%(full_address_value)s, " \
                    "{location_extra_data_key} = %(location_extra_data_value)s " \
                    "WHERE {pk}=%(object_id_value)s "
    if operation != "update":
        sql_statement += "AND {full_address_key} IS NULL RETURNING {pk}"
    else:
        sql_statement += "AND {full_address_key} IS NOT NULL RETURNING {pk}"

    sql_command = sql.SQL(sql_statement).format(
        table_name=sql.Identifier("groups"), full_address_key=sql.Identifier("full_address"),
        pk=sql.Identifier("id"), location_extra_data_key=sql.Identifier("location_extra_data")
    )
    sql_kwargs = {
        "full_address_value": label,
        "object_id_value": object_id,
        "location_extra_data_value": json.dumps(location_extra_data)
    }
    try:
        cursor.execute(sql_command, sql_kwargs)
        updated = cursor.fetchone()
    except Exception as e:
        raise RealtyfeedException(
            error_message=f"Error in 'update_address_in_groups' function: {str(e)}",
            error_status_code=1006
        )
    return True if updated else False


def set_group_address_to_null(cursor, object_id: int) -> None:
    """Set group address null when its location is deleted"""
    sql_statement = "UPDATE {table_name} " \
                    "SET {address_key} = NULL, {location_extra_data_key} = NULL " \
                    "WHERE {pk} = %(object_id_value)s"
    sql_command = sql.SQL(sql_statement).format(
        table_name=sql.Identifier("groups"),
        address_key=sql.Identifier("full_address"),
        location_extra_data_key=sql.Identifier("location_extra_data"),
        pk=sql.Identifier("id")
    )
    sql_kwargs = {"object_id_value": object_id}
    try:
        cursor.execute(sql_command, sql_kwargs)
    except Exception as e:
        raise RealtyfeedException(
            error_message="Error in 'set_group_address_to_null' function",
            error_status_code=1006, error_data=e.args
        )


def set_announcement_location_id_to_null(cursor, object_id: int) -> int:
    """Set announcement location foreign key null when its location is deleted"""
    sql_statement = "UPDATE {table_name} a " \
                    "SET {location_fk} = NULL " \
                    "FROM (SELECT {pk}, {location_fk} FROM {table_name} WHERE {pk} = %(object_id_value)s " \
                    "FOR UPDATE) b " \
                    "WHERE a.{pk} = b.{pk} " \
                    "RETURNING b.{location_fk}"
    sql_command = sql.SQL(sql_statement).format(
        table_name=sql.Identifier("announcement_and_shares"),
        location_fk=sql.Identifier("location_id"),
        pk=sql.Identifier("id")
    )
    sql_kwargs = {"object_id_value": object_id}
    try:
        cursor.execute(sql_command, sql_kwargs)
        old_location_id = cursor.fetchone()['location_id']
    except Exception as e:
        raise RealtyfeedException(
            error_message=f"Error in 'set_announcement_location_id_to_null' function: {str(e)}",
            error_status_code=1006, error_data=e.args
        )
    return old_location_id


def update_users_address_fields(cursor, object_id: int, rf_label: Union[str, None], label: Union[str, None],
                                location_extra_data: Union[dict, None]) -> bool:
    """Updates address field in users table"""
    sql_statement = "UPDATE {table_name} " \
                    "SET {short_address_key} = %(short_address_value)s, {full_address_key} = %(full_address_value)s, " \
                    "{location_extra_data_key} = %(location_extra_data_value)s " \
                    "WHERE {pk} = %(object_id_value)s RETURNING {pk}"
    sql_command = sql.SQL(sql_statement).format(
        table_name=sql.Identifier("users"),
        short_address_key=sql.Identifier("short_address"),
        full_address_key=sql.Identifier("full_address"),
        pk=sql.Identifier("id"),
        location_extra_data_key=sql.Identifier("location_extra_data")
    )
    sql_kwargs = {
        "short_address_value": rf_label,
        "full_address_value": label,
        "object_id_value": object_id,
        "location_extra_data_value": json.dumps(location_extra_data)
    }
    try:
        cursor.execute(sql_command, sql_kwargs)
        updated = cursor.fetchone()
    except Exception as e:
        raise RealtyfeedException(
            error_message=f"Error in 'update_users_address_fields' function: {str(e)}", error_status_code=1006
        )
    return True if updated else False


def insert_into_promotion_on_locations(cursor, object_location_input: dict, creation_date: datetime) -> None:
    """Inserts a row to the promotion_on_locations table"""
    sql_statement = "INSERT INTO {table_name} ({promotion_fk}, {location_fk}, {creation_date_key}) " \
                    "VALUES (%(promotion_id_value)s, %(location_id_value)s, %(creation_date_value)s)"
    sql_command = sql.SQL(sql_statement).format(
        table_name=sql.Identifier("promotion_on_locations"),
        promotion_fk=sql.Identifier("promotion_id"),
        location_fk=sql.Identifier("location_id"),
        creation_date_key=sql.Identifier("creation_date")
    )
    sql_kwargs = {
        "promotion_id_value": object_location_input["object_id"],
        "location_id_value": object_location_input['parent_location'],
        "creation_date_value": creation_date
    }
    try:
        cursor.execute(sql_command, sql_kwargs)
    except Exception as e:
        raise RealtyfeedException(
            error_message=f"Error in 'insert_into_promotion_on_locations' function: {str(e)}",
            error_status_code=1006)


def update_promotion_on_location(cursor, object_location_input: dict, creation_date: datetime) -> None:
    """Updates promotion_on_locations table"""
    raw_sql_statement = "UPDATE {table_name} " \
                        "SET {location_fkey}=%(location_id_value)s, {creation_date_key}=%(creation_date_value)s " \
                        "WHERE {pk}=%(pk_value)s AND {promotion_fkey}=%(object_id_value)s "
    sql_command = sql.SQL(raw_sql_statement).format(
        table_name=sql.Identifier("promotion_on_locations"),
        location_fkey=sql.Identifier("location_id"),
        creation_date_key=sql.Identifier("creation_date"),
        pk=sql.Identifier("id"),
        promotion_fkey=sql.Identifier(object_location_input['object_id_column']),
    )
    sql_kwargs = {
        "location_id_value": object_location_input['parent_location'],
        "creation_date_value": creation_date,
        "pk_value": object_location_input['object_location_id'],
        "object_id_value": object_location_input['object_id']
    }
    try:
        cursor.execute(sql_command, sql_kwargs)
    except Exception as e:
        raise RealtyfeedException(
            error_message=f"Error in 'update_promotion_on_location' function: {str(e)}",
            error_status_code=1006
        )


def delete_user_location(cursor, object_location_input: dict) -> int:
    sql_statement = "DELETE FROM {table_name} " \
                    "WHERE {user_fk} = %(user_id_value)s AND {type_key} = %(type_value)s " \
                    "RETURNING {location_fk}"
    sql_command = sql.SQL(sql_statement).format(
        table_name=sql.Identifier(object_location_input["table"]),
        user_fk=sql.Identifier("user_id"),
        type_key=sql.Identifier("type"),
        location_fk=sql.Identifier("location_id")
    )
    sql_kwargs = {"user_id_value": object_location_input["object_id"], "type_value": object_location_input["type"]}
    try:
        cursor.execute(sql_command, sql_kwargs)
        removed_location_id = cursor.fetchone()['location_id']
    except Exception as e:
        raise RealtyfeedException(
            error_message=f"Error in 'delete_user_location' function", error_status_code=1006
        )
    return removed_location_id


def get_removing_zipcode_ids(cursor, removed_location_id: int) -> list:
    """
    Fetches previous zipcode_id(s) of the user
    """
    sql_statement = """
            SELECT {zipcode_fk} FROM {table_name} 
            WHERE {location_fk} = %(location_id_value)s
            """
    sql_command = sql.SQL(sql_statement).format(
        zipcode_fk=sql.Identifier("zipcode_id"),
        table_name=sql.Identifier("zipcodes_bridge"),
        location_fk=sql.Identifier("location_id")
    )
    sql_kwargs = {"location_id_value": removed_location_id}
    try:
        cursor.execute(sql_command, sql_kwargs)
        removing_zipcode_ids = cursor.fetchall()
    except Exception as e:
        raise RealtyfeedException(
            error_message=f"Error in 'get_removing_zipcode_ids' function: {str(e)}", error_status_code=1006
        )
    return removing_zipcode_ids


def put_events_on_event_bridge(event_bridge_input: dict) -> None:
    try:
        event_bridge = boto3.client('events')
        entries_list = [
            {
                "Source": "give_object_location",
                "DetailType": "give_object_location",
                "Detail": json.dumps(event_bridge_input, default=decimal_default),
                "EventBusName": "realtyfeed-event-bus"
            }
        ]
        event_bridge.put_events(Entries=entries_list)
    except Exception as ex:
        raise RealtyfeedException(
            error_message=f"Error in event_bridge process: {str(ex)}", error_status_code=1006
        )


def create_and_update_input_validator(item, operation):
    """Validate input structure and allowed keys and values"""
    # check required keys in all scenarios ----------------------------------
    for key in ["object_type", "object_id", "location"]:
        if key not in item.keys():
            raise RealtyfeedException(error_message=f"Key {key} is required in update or create operation",
                                        error_status_code=1001)
    # check object_type allowed values --------------------------------------
    allowed_object_types = ["listing", "group", "user", "announcement", "inquiry", "btt", "package", "promotion"]
    if item["object_type"] not in allowed_object_types:
        raise RealtyfeedException(
            error_message=f"object of type {item['object_type']} is invalid for create or update operation",
            error_status_code=1001
        )
    # check type value of user and group objects -----------------------------
    if item["object_type"] in ["user", "group"]:
        if "type" not in item.keys():
            raise RealtyfeedException(
                error_message="'type' is required key when 'object_type' is user or group",
                error_status_code=1001
            )
        else:
            if item["object_type"] == "user" and item["type"] not in [1, 2, 3, "1", "2", "3"]:
                raise RealtyfeedException(
                    error_message="Value of 'type' for 'object_type' user must be one of '1, 2, 3'",
                    error_status_code=1001
                )
            elif item["object_type"] == "group" and item["type"] not in [1, 2, "1", "2"]:
                raise RealtyfeedException(
                    error_message="Value of 'type' for 'object_type' group must be one of 1 or 2",
                    error_status_code=1001
                )
        if operation in ["update", "create"]:
            for loc in ["location_extra_data", "Label"]:
                if not item["location"].get(loc):
                    raise RealtyfeedException(
                        error_message=f"'{loc}' is required key for assign or update object location",
                        error_status_code=1001
                    )
    else:
        item["type"] = "default"
    # check object_location_id value -------------------------------------------
    if operation == "update" and item["object_type"] not in ["listing", "announcement"] and \
            "object_location_id" not in item.keys():
        raise RealtyfeedException(
            error_message="'object_location_id' is required key in update operation when 'object_type'" \
                          " not listing or announcement", error_status_code=1001)
    elif (operation == "update" and item["object_type"] in ["listing", "announcement"]) or operation != "update":
        item["object_location_id"] = None
    # Assign user location type (user address or user interests) ---------------
    if operation == "create" and item["object_type"] == "user" and 'is_zipcode' in item.keys() and \
            item["is_zipcode"] in [True, "true", "True"]:
        if item["type"] == 3:
            item["is_zipcode"] = True
        else:
            raise RealtyfeedException(error_message="Invalid type for assign zipcode interest",
                                        error_status_code=1001)
    else:
        item["is_zipcode"] = False
    # location validation requirements ----------------------------------------
    if (item["location"].get("PostalCode") or item["location"].get("Neighborhood")) and not item["location"].get(
            "Municipality"):
        raise RealtyfeedException(
            error_message="'Municipality' is required when 'PostalCode' or 'Neighborhood' are present",
            error_status_code=1001
        )
    if not item["location"].get("Country"):  # Country is required key for all objects
        raise RealtyfeedException(
            error_message=f"'Country' is required key for assign or update object location",
            error_status_code=1001
        )
    return item


def create_and_update_input_serializer(item: dict, operation: str) -> Tuple[dict, dict]:
    """Serialize create and update objects keys and values"""
    item = create_and_update_input_validator(item, operation)

    location_key_list = ["Country", "Region", "SubRegion", "Municipality", "Street", "AddressNumber",
                         "PostalCode", "Label", "Neighborhood", "Abbreviation", "location_extra_data", "Geometry"]
    country, region, subregion, city, street, address_number, zipcode, label, neighborhood, \
    abbr, location_extra_data, geometry = (item['location'].get(key) for key in location_key_list)

    # --------- Assign values for location objects -------------------
    try:
        if country == "USA" and zipcode and " " in zipcode:
            zipcode = zipcode[:5]
        zipcode_label = str(zipcode + "_" + region) if zipcode and region else None
        coordinates = {}
        if geometry and geometry.get("Point", None):
            if not isinstance(geometry["Point"], list):
                raise RealtyfeedException(
                    error_message="point should be a list of latitude and longitude",
                    error_status_code=1001
                )
            longitude = geometry["Point"][0]
            latitude = geometry["Point"][1]
            coordinates = {
                "longitude": longitude,
                "latitude": latitude
            }
            coordinates = json.dumps(coordinates)
        inquiry_value = None
        if item["object_type"] == "inquiry":
            inquiry_value = f"{city}-{region}-{zipcode}"
    except (LookupError, ValueError, KeyError) as e:
        raise RealtyfeedException(
            error_message=f"Invalid input value for '{str(e)}'", error_status_code=1001
        )

    # --------- Map input data for the required model used in the rest of the process
    location_data = {
        "country": country,
        "region": region,
        "subregion": subregion,
        "city": city,
        "street": street,
        "address_number": address_number,
        "zipcode": zipcode,
        "label": label,
        "neighborhood": neighborhood,
        "abbr": abbr,
        "coordinates": coordinates,
        "zipcode_label": zipcode_label,
        "inquiry_value": inquiry_value,
        "geometry": geometry,
        "location_extra_data": location_extra_data
    }
    object_data = {
        "object_type": item["object_type"],
        "type": item["type"],
        "object_id": item["object_id"],
        "object_location_id": item["object_location_id"],
        "is_zipcode": item["is_zipcode"],
        "operation": item["operation"]
    }

    return object_data, location_data


def validate_delete_input_data(item: dict) -> dict:
    """Validate and serialize delete objects"""
    # check object_type allowed values ---------------------------------------
    allowed_object_types_for_delete = ["group", "user", "announcement", "inquiry", "btt", "package", "promotion"]
    if item["object_type"] not in allowed_object_types_for_delete:
        raise RealtyfeedException(
            error_message=f"object of type {item['object_type']} is invalid for delete operation",
            error_status_code=1001)
    # check type value --------------------------------------------------------
    if item["object_type"] in ["user", "group"]:
        if "type" not in item.keys():
            raise RealtyfeedException(error_message="'type' is required key when 'object_type' is user or group",
                                        error_status_code=1001)
        else:
            if item["object_type"] == "user" and item["type"] not in [1, 2, 3, "1", "2", "3"]:
                raise RealtyfeedException(
                    error_message="Value of 'type' for 'object_type' user must be one of '1, 2, 3'",
                    error_status_code=1001)
            elif item["object_type"] == "group" and item["type"] not in [1, 2, "1", "2"]:
                raise RealtyfeedException(
                    error_message="Value of 'type' for 'object_type' group must be one of 1 or 2",
                    error_status_code=1001)
    else:
        item["type"] = "default"
    # check object_location_id value -------------------------------------------
    if item["object_type"] != "announcement":
        if "object_location_id" not in item.keys():
            raise RealtyfeedException(
                error_message="'object_location_id' is required key in update operation when 'object_type'" \
                              " not listing or announcement", error_status_code=1001)
    else:
        item["object_location_id"] = None

    return {
        "object_type": item["object_type"],
        "object_id": item["object_id"],
        "object_location_id": item["object_location_id"],
        "type": item["type"]
    }


def serialize_input_data(input_data: dict) -> dict:
    """
    Validate and serialize input data and check for valid keys and types
    """
    # -------- Validate input structure ------------------------------
    if not isinstance(input_data, dict):
        raise RealtyfeedException(error_message="'location_input' must be of 'dictionary' type ",
                                    error_status_code=1001)
    for key, value in input_data.items():
        if key not in ["create", "update", "delete"] or not isinstance(value, list):
            raise RealtyfeedException(
                error_message="Input keys must be in 'create, update, delete' and value must be a list",
                error_status_code=1001)
        # assign operation name in each object in create and update key
        if key in ["create", "update"]:
            for item in value:
                item["operation"] = key

    # Allowed type choices for objects of relation -------------------
    type_choices = {
        "user": {1: "user_country", 2: "user_address", 3: "area_of_interest"},
        "user_graph": {1: "HasCountry", 2: "IsLocated", 3: "InterestedIn"},
        "group": {1: "Office Address", 2: "Area of Activity"},
        "group_graph": {1: "IsLocated", 2: "ActiveIn"},
        "listing_graph": {"default": "IsLocated"},
        "btt_graph": {"default": "IsRelated"},
        "package_graph": {"default": "IsRelated"},
        "announcement_graph": {"default": "HasLocation"},
        "promotion_graph": {"default": "InLocation"},
        "inquiry_graph": {"default": None}
    }

    valid_data = {"create_update_data": [], "delete_data": []}
    # Validate and serialize update and create objects ---------------
    items = input_data.get("create", []) + input_data.get("update", [])
    for item in items:
        object_dct, location_dct = create_and_update_input_serializer(item, item["operation"])
        object_dct["choice_type"] = type_choices.get(object_dct["object_type"], {}).get(object_dct["type"])
        object_dct["edge_name"] = type_choices.get(f"{object_dct['object_type']}_graph", {}).get(object_dct["type"])
        valid_data["create_update_data"].append({
            "location_data": location_dct,
            "object_data": object_dct
        })

    # Validate and serialize delete objects --------------------------
    for item in input_data.get("delete", []):
        data = validate_delete_input_data(item)
        data["edge_name"] = type_choices.get(f"{data['object_type']}_graph").get(data["type"])
        valid_data["delete_data"].append(data)

    return valid_data


def zipcode_process(cursor, zipcode: str, zipcode_label: str, new_location: bool, creation_date: datetime,
                    location_id: int, graph_create: list, graph_relations_add: list) -> Tuple[int, bool]:
    zipcode_id = get_zipcode_id(cursor, zipcode_label)
    if not zipcode_id:
        new_location = True
        zipcode_id = insert_zipcode(cursor, zipcode, zipcode_label, creation_date)
        create_zipcode_for_graph_input(graph_create, zipcode_id, zipcode)

    elif not zipcode_id or (zipcode_id and new_location is True):
        insert_zipcode_bridge(cursor, location_id, zipcode_id, creation_date)
        zipcode_relation = GraphSchema(source_type="Location", target_type="ZipCode", relation_name="Has",
                                       source_id=location_id, target_id=zipcode_id)
        graph_relations_add.append(zipcode_relation.create_schema())

    return zipcode_id, new_location


def neighborhood_process(cursor, neighborhood: str, new_location: bool, location_level_name: str, location_id: int,
                         creation_date: datetime, graph_create: list, graph_relations_add: list) -> Tuple[int, bool]:
    neighborhood_label = str(location_level_name + "_" + neighborhood)
    neighborhood_id = get_neighborhood_id(cursor, neighborhood_label)
    if not neighborhood_id:
        new_location = True
        neighborhood_id = insert_neighborhood(cursor, neighborhood, neighborhood_label, creation_date)
        create_neighborhood_for_graph_input(graph_create, neighborhood_id, neighborhood)
        insert_neighborhood_bridge(cursor, location_id, neighborhood_id, creation_date)
        # --------------- Handling graph relation for Neighborhood ------------------
        neighborhood_relation = GraphSchema(source_type="Location", target_type="Neighborhood",
                                            relation_name="Has", source_id=location_id, target_id=neighborhood_id)
        graph_relations_add.append(neighborhood_relation.create_schema())
    return neighborhood_id, new_location


def create_process(cursor, object_location_input: dict, object_dct: dict, inquiry_value: str, object_type: str,
                   creation_date: datetime, graph_relations_remove: list) -> None:
    """Assign location for allowed objects based on received types"""
    if object_type == 'user':
        # if user_location type is address or country & it has a row in RDS
        if object_dct["type"] in [1, 2, "1", "2"] and does_object_have_location_already(cursor, object_location_input):
            removed_location_id = delete_user_location(cursor, object_location_input)
            # Removing the Edge between user and the old Location
            user_relation = GraphSchema(source_type="User", target_type="Location",
                                        relation_name=object_dct["edge_name"],
                                        source_id=object_dct["object_id"], target_id=removed_location_id)
            graph_relations_remove.append(user_relation.create_schema())
            removing_zipcode_ids = get_removing_zipcode_ids(cursor, removed_location_id)
            # Removing the Edge between user and the old Zipcode
            for zipcode_item in removing_zipcode_ids:
                zipcode_relation = GraphSchema(source_type="User", target_type="ZipCode",
                                               relation_name=object_dct["edge_name"],
                                               source_id=object_dct["object_id"],
                                               target_id=zipcode_item['zipcode_id'])
                graph_relations_remove.append(zipcode_relation.create_schema())
        elif object_dct["type"] in [3, "3"]:
            pass  # TODO: Check limitation count of user location with type 3
        insert_into_user_location(cursor, object_location_input, object_dct["is_zipcode"], creation_date)
    elif object_type == "group":
        insert_into_group_location(cursor, object_location_input, creation_date)
    elif object_type == "inquiry":
        insert_into_inquiry_location(cursor, object_location_input, inquiry_value, creation_date)
    elif object_type == "btt":
        insert_into_btt_location(cursor, object_location_input, creation_date)
    elif object_type == "package":
        insert_into_package_location(cursor, object_location_input, creation_date)
    elif object_type == "promotion":
        insert_into_promotion_on_locations(cursor, object_location_input, creation_date)
    elif object_type == "announcement":
        updated = update_location_id_in_announcement(cursor, object_dct["object_id"],
                                                     object_location_input["parent_location"])
        if not updated:
            raise RealtyfeedException(
                error_message="The location for the desired announcement has already been registered",
                error_status_code=1006)


def update_process(cursor, object_location_input: dict, object_dct: dict, location_dct: dict, object_type: str,
                   creation_date: datetime, graph_relations_remove: list) -> None:
    # Getting old location ids
    result = get_old_location_id(cursor, object_location_input)
    old_location_id = result.get("location_id")
    old_zipcode_id = result.get("zipcode_id")
    old_neighborhood_id = result.get("neighborhood_id")

    # update location objects
    if object_type == "group":
        if not update_group_location(cursor, object_location_input, creation_date):
            raise RealtyfeedException(error_message=f"Invalid group information", error_status_code=1006)
    elif object_type == "user":
        if not update_user_location(cursor, object_location_input, creation_date):
            raise RealtyfeedException(error_message=f"Invalid user information", error_status_code=1006)
    elif object_type == "inquiry":
        update_inquiry_location(cursor, object_location_input, location_dct["inquiry_value"])
    elif object_type == "btt":
        update_btt_location(cursor, object_location_input, creation_date)
    elif object_type == "package":
        update_package_location(cursor, object_location_input, creation_date)
    elif object_type == "promotion":
        update_promotion_on_location(cursor, object_location_input, creation_date)
    elif object_type == "announcement":
        updated = update_location_id_in_announcement(cursor, object_dct["object_id"],
                                                     object_location_input["parent_location"], operation="update")
        if not updated:
            raise RealtyfeedException(error_message="announcement_and_shares.location_id should NOT be null for "
                                                  "'update' operation", error_status_code=1006)

    # Graph processing for remove old locations
    if object_type != "inquiry":
        graph_location_rem = GraphSchema(source_type=object_dct["node_name"], target_type="Location",
                                         relation_name=object_dct["edge_name"],
                                         source_id=object_dct["object_id"], target_id=old_location_id)
        graph_relations_remove.append(graph_location_rem.create_schema())
    if object_type in ["user", "group", "listing"] and old_zipcode_id:
        graph_zipcode_rem = GraphSchema(source_type=object_dct["node_name"], target_type="ZipCode",
                                        relation_name=object_dct["edge_name"],
                                        source_id=object_dct["object_id"], target_id=old_zipcode_id)
        graph_relations_remove.append(graph_zipcode_rem.create_schema())
    if object_type == "listing" and old_neighborhood_id:
        graph_neighborhood_rem = GraphSchema(source_type="Listing", target_type="Neighborhood",
                                             relation_name="IsLocated", source_id=object_dct["object_id"],
                                             target_id=old_neighborhood_id)
        graph_relations_remove.append(graph_neighborhood_rem.create_schema())


def create_graph_process_locations(object_type: str, parent_location: int, object_dct: dict, location_dct: dict,
                                   graph_relations_add: list) -> None:
    """
    Create graph input for both update and create operations for location relations
    """
    if object_type != "inquiry":
        graph_location = GraphSchema(source_type=object_dct["node_name"], target_type="Location",
                                     relation_name=object_dct["edge_name"],
                                     source_id=object_dct["object_id"], target_id=parent_location)
        graph_relations_add.append(graph_location.create_schema())
    if object_type in ["user", "group", "listing"] and location_dct["zipcode_id"]:
        graph_zipcode = GraphSchema(source_type=object_dct["node_name"], target_type="ZipCode",
                                    relation_name=object_dct["edge_name"],
                                    source_id=object_dct["object_id"], target_id=location_dct["zipcode_id"])
        graph_relations_add.append(graph_zipcode.create_schema())
    if object_type == "listing" and location_dct["neighborhood_id"]:
        graph_neighborhood = GraphSchema(source_type=object_dct["node_name"], target_type="Neighborhood",
                                         relation_name=object_dct["edge_name"],
                                         source_id=object_dct["object_id"],
                                         target_id=location_dct["neighborhood_id"])
        graph_relations_add.append(graph_neighborhood.create_schema())


def create_and_update_same_operations(cursor, object_dct: dict, parent_location: int, object_type: str,
                                      location_dct: dict, rf_label: str, operation: str) -> Tuple[dict, dict]:
    table = f'{object_type}_locations'
    object_id_column = f'{object_type}_id'
    if object_type == "btt":
        table = "btt_type_items_locations"
        object_id_column = "btt_type_item_id"
    elif object_type == "inquiry":
        table = "inquiry_location"
    elif object_type == "promotion":
        table = "promotion_on_locations"

    object_location_input = {
        "table": table,
        "object_id_column": object_id_column,
        "object_id": object_dct["object_id"],
        "parent_location": parent_location,
        "object_type": object_type,
        "type": object_dct["type"],
        "coordinates": location_dct["coordinates"],
        "zipcode_id": location_dct["zipcode_id"],
        "label": location_dct["label"],
        "rf_label": rf_label,
        "neighborhood_id": location_dct["neighborhood_id"],
        "object_location_id": object_dct["object_location_id"]
    }
    # TODO: No need to Checking existence of the same location for the object
    # if object_type not in ["listing", "announcement"]:
    #     obj_loc_exists = does_object_location_exist_already(cursor, object_location_input)
    #     if obj_loc_exists:
    #         error_message = f"{object_type} {object_dct['object_id']} has location {parent_location} with /
    #           type {object_dct['choice_type']}"
    #         raise InvalidInputException(error_message=error_message, error_status_code=1001)

    # Update user address in users table when type location is user_address
    if object_type == 'user' and object_dct["type"] in [2, "2"]:
        updated = update_users_address_fields(cursor, object_dct["object_id"], rf_label, location_dct["label"],
                                              location_dct["location_extra_data"])
        if not updated:
            raise RealtyfeedException(error_message=f"Error in updating user address fields.",
                                        error_status_code=1006)
    elif object_type == "listing":
        updated = update_listing(cursor, object_location_input, operation=operation)
        if not updated:
            raise RealtyfeedException(
                error_message=f"The location for the desired listing has already been registered",
                error_status_code=1006)
    elif object_type == "group":
        if object_dct["type"] in [1, "1"]:
            updated = update_address_in_groups(cursor, object_dct["object_id"], location_dct["label"],
                                               location_dct["location_extra_data"], operation=operation)
            if not updated:
                raise RealtyfeedException(
                    error_message="The location for the desired group with type 1 has already been registered",
                    error_status_code=1006
                )
    output_data = {
        "location_id": parent_location,
        "zipcode_id": object_location_input["zipcode_id"],
        "neighborhood_id": object_location_input["neighborhood_id"],
        'label': location_dct["label"] if object_type != "inquiry" else location_dct["inquiry_value"],
    }
    return object_location_input, output_data


def delete_operation(cursor, object_type: str, delete_item: dict, graph_relations_remove: list) -> int:
    """delete a location object with relations"""

    table = f'{object_type}_locations'
    if object_type == "btt":
        table = "btt_type_items_locations"
    if object_type == "inquiry":
        table = "inquiry_location"
    if object_type == "promotion":
        table = "promotion_on_locations"

    old_ids = {"old_zipcode_id": None, "old_location_id": None}
    if object_type != "announcement":
        item_type = None
        if object_type == "group" and delete_item["type"] in [1, "1"]:
            set_group_address_to_null(cursor, delete_item["object_id"])
            item_type = 1
        elif object_type == "user" and delete_item["type"] in [2, "2"]:
            item_type = 2
            update_users_address_fields(cursor, delete_item["object_id"], None, None, None)
        old_ids = delete_object_location(cursor, table, delete_item["object_location_id"], item_type)
    else:
        old_ids["old_location_id"] = set_announcement_location_id_to_null(cursor, delete_item["object_id"])

    # Create graph input for remove relations of desired location
    node_name = "BTTItem" if object_type == "btt" else object_type.title()
    if object_type != "inquiry":
        graph_location_rem = GraphSchema(source_type=node_name, target_type="Location",
                                         relation_name=delete_item["edge_name"], source_id=delete_item["object_id"],
                                         target_id=old_ids["old_location_id"])
        graph_relations_remove.append(graph_location_rem.create_schema())
    if object_type in ["user", "group"] and old_ids["old_zipcode_id"]:
        graph_zipcode_rem = GraphSchema(source_type=object_type.title(), target_type="ZipCode",
                                        relation_name=delete_item["edge_name"], source_id=delete_item["object_id"],
                                        target_id=old_ids["old_zipcode_id"])
        graph_relations_remove.append(graph_zipcode_rem.create_schema())

    return old_ids["old_location_id"]


def give_object_location(location_input: dict) -> dict:
    """
    Assigns a location to an object, updates and deletes the location of an object.
    This function can accept multiple pair of objects/locations. It will generate the related nodes and relationships
    on graph db and will update elasticsearch db.
    :params location_input (dict): The input for give_object_location function. It should be a dictionary containing these
        keys: create | update | delete with a list of dictionaries as value. Please reade the document for more detail
    """
    output = {"create": [], "update": [], "delete": []}
    rds_handler = None
    try:
        valid_input_data = serialize_input_data(input_data=location_input)

        # ---------- Dynamic event_bridge input for graph -------------------
        event_bridge_input = {
            "graph_input": {
                "create": [],
                "relations": {}
            },
            "index_input": {
                "index_name": "locations",
                'create': []
            },
            "stats_input": {
                "create": [],
                "update": []
            }
        }
        graph_relations_add = event_bridge_input["graph_input"]["relations"]["add"] = []
        graph_relations_remove = event_bridge_input["graph_input"]["relations"]["remove"] = []
        graph_create = event_bridge_input['graph_input']['create']
        elasticsearch_index_input = event_bridge_input["index_input"]

        # ---------- RDS Connection -----------------------------------------
        try:
            rds_handler = RDSHandler(table_name="", is_cursor_dict=True)
            cursor = rds_handler.cursor
        except Exception as e:
            raise RealtyfeedException(
                error_message=f"Error in RDS db connection or cursor: {str(e)}",
                error_status_code=1006
            )

        creation_date = datetime.datetime.now().replace(tzinfo=pytz.UTC).strftime('%Y-%m-%dT%H:%M:%S')
        
        # ----------- Process update and create ------------------------------
        for item in valid_input_data["create_update_data"]:
            location_dct = item["location_data"]
            object_dct = item["object_data"]
            operation = object_dct["operation"]
            object_type = object_dct["object_type"]
            object_dct["node_name"] = object_type.title() if object_type != "btt" else "BTTItem"

            # --------- Assigning level to locations ------------------------
            location_names_and_levels = [
                (location_dct.get(key), idx) for (idx, key) in
                enumerate(['country', 'region', 'subregion', 'city'], start=1) if location_dct.get(key) is not None
            ]

            # --------- Processing locations --------------------------------
            location_processor_input = {
                "abbr": item["location_data"]["abbr"],
                "location_names_and_levels": location_names_and_levels,
                "graph_create": graph_create,
                "graph_relations_add": graph_relations_add,
                "elasticsearch_index_input": elasticsearch_index_input,
                "creation_date": creation_date
            }
            location_processor_response = location_processor(cursor, location_processor_input)
            res_keys = ["parent_location", "current_level", "current_location_name", "is_new_location", "rf_label"]
            parent_location, current_level, current_location_name, is_new_location, rf_label = (
                location_processor_response[key] for key in res_keys
            )

            # --------- Processing zipcode ----------------------------------
            location_dct["zipcode_id"], is_new_location = (
                zipcode_process(
                    cursor, location_dct["zipcode"], location_dct["zipcode_label"], is_new_location,
                    creation_date, parent_location, graph_create, graph_relations_add
                )
                if location_dct["zipcode"]
                else (None, is_new_location)
            )

            # --------- Processing Neighborhood -----------------------------
            location_dct["neighborhood_id"], is_new_location = (
                neighborhood_process(
                    cursor, location_dct["neighborhood"], is_new_location, current_location_name,
                    parent_location, creation_date, graph_create, graph_relations_add
                )
                if location_dct["neighborhood"]
                else (None, is_new_location)
            )

            # ------- Create elasticsearch instance when location is new ----
            # TODO: Currently, it is not possible to send information to Elastic
            # if is_new_location:
            #     create_input_for_elasticsearch(elasticsearch_index_input, location_dct, rf_label, current_level,
            #                                    parent_location)

            # -------- Create and update same operations --------------------
            object_location_input, output_data = create_and_update_same_operations(cursor, object_dct, parent_location,
                                                                                object_type, location_dct, rf_label,
                                                                                operation)
            create_graph_process_locations(object_type, parent_location, object_dct, location_dct, graph_relations_add)

            # ----------------- Create process ------------------------------
            if operation == "create":
                create_process(cursor, object_location_input, object_dct, location_dct["inquiry_value"], object_type,
                            creation_date, graph_relations_remove)
                output['create'].append(output_data)

            # ----------------- Update process --------------------------------
            elif operation == "update":
                update_process(cursor, object_location_input, object_dct, location_dct, object_type, creation_date,
                            graph_relations_remove)
                output['update'].append(output_data)

        # ----------- Process delete location ---------------------------------
        for item in valid_input_data["delete_data"]:
            check_object_existence(cursor, item["object_id"], item["object_type"])
            old_location_id = delete_operation(cursor, item["object_type"], item, graph_relations_remove)
            output["delete"].append({"removed_location_id": old_location_id})

        # ----------- Put events on event bridge ------------------------------
        put_events_on_event_bridge(event_bridge_input=event_bridge_input)

        try:
            rds_handler.commit_changes()
        except Exception as e:
            raise RealtyfeedException(
                error_message=f"Error in RDS db commit: {str(e)}", error_status_code=1006
            )
        
    finally:
        if rds_handler and hasattr(rds_handler, "close_connection"):
            rds_handler.close_connection()

    return output

# def lambda_handler(event, context):  # FIXME (uncomment handler when testing as a lambda function)
#     response = sample_response.copy()
#     try:
#         event = json_to_dict(event)
#         event_body = event.get("body", event)
#         response['result'] = give_object_location(event_body)
#         response['is_success'] = True
#     except RealtyfeedException as e:
#         response["error"] = e.error_message
#         response["message_code"] = e.error_status_code
#         response["result"] = e.error_data
#     except Exception as e:
#         response["result"] = traceback.format_exc()
#     return response
