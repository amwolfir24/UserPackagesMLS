from gremlin_python.process.anonymous_traversal import traversal
from gremlin_python.process.graph_traversal import __
from gremlin_python.driver.driver_remote_connection import DriverRemoteConnection
from .configs import NEPTUNE_NEW_ENDPOINT, NEPTUNE_PORT
from .exceptions import RealtyfeedException


def get_relation_between_users(source_user_id, target_user_id, g=None):
    """
    gets relations FROM source_user TO target_user as a dictionary.
    e.g. {'is_connected': False, 'is_follower': False, 'is_following': False, 'blocked': False, 'is_blocked': True}
    :param source_user_id: id of source user
    :type source_user_id: int | str
    :param target_user_id: id of target user
    :type target_user_id: int | str
    :param g: TraversalSource
    :type g:gremlin_python.process.graph_traversal.GraphTraversalSource
    """
    if not g:
        try:
            conn = DriverRemoteConnection(
                f'wss://{NEPTUNE_NEW_ENDPOINT}:{NEPTUNE_PORT}/gremlin', 'g')
            g = traversal().withRemote(conn)
        except Exception as e:
            return f"Error occurred in CONNECTION of 'get_relation_between_users' function: {str(e)}"

    try:
        source_user_id = int(source_user_id)
        target_user_id = int(target_user_id)
        users_relation = g.V().has("User", "id", source_user_id). \
            project("is_connected", "is_follower", "is_following", "blocked", "is_blocked"). \
            by(
            __.choose(__.both("Connected").has("User", "id", target_user_id), __.constant(True), __.constant(False))). \
            by(
            __.choose(__.out("Following").has("User", "id", target_user_id), __.constant(True), __.constant(False))). \
            by(
            __.choose(__.in_("Following").has("User", "id", target_user_id), __.constant(True), __.constant(False))). \
            by(
            __.choose(__.out("Blocked").has("User", "id", target_user_id), __.constant(True), __.constant(False))). \
            by(
            __.choose(__.in_("Blocked").has("User", "id", target_user_id), __.constant(True), __.constant(False))
        ).toList()

        return users_relation[0]
    except Exception as e:
        raise RealtyfeedException(error_message=f"Error occurred in 'get_relation_between_users' function: {str(e)}")
