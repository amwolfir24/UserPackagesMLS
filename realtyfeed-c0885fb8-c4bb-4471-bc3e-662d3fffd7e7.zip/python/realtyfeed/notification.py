import boto3
from collections import defaultdict
from boto3.dynamodb.conditions import Key


def get_notification_template_list(category=None, sub_category=None):
    try:
        dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
        table = dynamodb.Table('notification_interval_template')
        result = defaultdict(list)
        items = []

        if not category and not sub_category:
            items = table.scan()['Items']
        else:
            if category:
                query = Key("category").eq(category)
                if sub_category:
                    query &= Key("sub_category").eq(sub_category)
                items = table.query(KeyConditionExpression=query)

        for item in items:
            result[item['category']].append(item)
            item.pop('category')

    except Exception as ex:
        raise ex
    return result


def create_notification_whitelist(template_list):
    return {
        f'{x}.{y["sub_category"]}.{z}': y[z]["available_intervals"]
        for x in template_list.keys()
        for y in template_list[x]
        for z in ('in_app', 'sms', 'push', 'email')
        if y[z]['read_only'] is False and y[z]['enable'] is True
    }
