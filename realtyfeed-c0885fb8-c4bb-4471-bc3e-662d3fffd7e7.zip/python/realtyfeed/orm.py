import json
import pytz
import traceback
from psycopg2 import InternalError, connect as psycopg2_connect, sql
import psycopg2
from psycopg2.extras import RealDictCursor, execute_values
from realtyfeed.configs import get_rds_credentials
from realtyfeed.exceptions import DatabaseException, DataInvalidException
from realtyfeed.validators import validate_string_iterable
from datetime import date, datetime


# TODO: For Next version: Add table name befor field name with "table_name"."field_name" structure if there is not table name in select fields and returning


class DeleteRecordException(InternalError):
    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)


class UpdateRecordException(InternalError):
    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)


class GetRecordException(InternalError):
    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)


class CreateRecordException(InternalError):
    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)


class CreateRecordsException(InternalError):
    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)


def print_function(func):
    """
    The function is a decorator
    The function print at the starting at the ending of functions in console.
    """

    def inner1(*args, **kwargs):
        print(f"================== START | orm.{func.__name__} ==================")
        result = func(*args, **kwargs)
        print(f"================== END   | orm.{func.__name__} ==================")
        return result

    return inner1


class RDSHandler(object):
    BASE_ERROR_MSG = "ERROR-RDSHandler-object |"

    def __init__(self, table_name, is_cursor_dict=False):
        self.conn = None
        self.cursor = None
        self.table_name = table_name
        self.is_cursor_dict = is_cursor_dict

        self.__open_connection()
        self.__generate_cursor()

    def __open_connection(self):
        rds_creds = get_rds_credentials()
        try:
            self.conn = psycopg2_connect(
                host=rds_creds[3],
                port=rds_creds[4],
                database=rds_creds[0],
                user=rds_creds[2],
                password=rds_creds[1]
            )
        except Exception:
            raise DatabaseException("Error in opening RDS database connection.")

    def __generate_cursor(self):
        if not self.conn:
            raise DatabaseException("Connection is closed.")
        try:
            if self.is_cursor_dict:
                self.cursor = self.conn.cursor(cursor_factory=RealDictCursor)
            else:
                self.cursor = self.conn.cursor()
        except Exception:
            raise DatabaseException("Error in generating RDS database cursor.")

    def close_connection(self):
        try:
            if self.cursor and hasattr(self.conn, "close"):
                self.cursor.close()
        except Exception:
            raise DatabaseException("Error in closing RDS database cursor.")
        try:
            if self.conn and hasattr(self.conn, "close"):
                self.conn.close()
        except Exception:
            raise DatabaseException("Error in closing RDS database connection.")

    def commit_changes(self):
        if not self.conn:
            raise DatabaseException("Connection is closed.")
        self.conn.commit()

    def __validate_conditions(self, conditions):
        sample_input = [
            {"field": "one", "operator": "in", "value": 1},
            "and",
            {"field": "two", "operator": "eq", "value": 1},
        ]

        if not isinstance(conditions, list):
            raise DataInvalidException(
                error_message="Conditions must be a list instance to keep order of conditions and operators",
                error_data={"sample_input": sample_input},
            )

        if (len(conditions) % 2) == 0:
            raise DataInvalidException(
                error_message="Conditions must be odd as there is one operator between two operands.",
                error_data={"sample_input": sample_input},
            )

    def __validate_condition(self, condition):
        sample_input = {"field": "one", "operator": "in", "value": 1}

        if not isinstance(condition, dict):
            raise DataInvalidException(
                error_message="Condition must be a dict containing field name, operator and expected value(s)",
                error_data={"sample_input": sample_input},
            )

    def __get_operator_string(self, operator):
        operators = {
            "gte": ">=",
            "lte": "<=",
            "gt": ">",
            "lt": "<",
            "eq": "=",
            "neq": "!=",
            "in": "IN",
        }
        return operators[operator]

    def __get_condition_operator_string(self, operator):
        operators = {"and": "AND", "or": "OR"}
        return operators[operator]

    def _generate_conditions_string(self, conditions):
        conditions_string = []
        for i in range(len(conditions)):
            condition = conditions[i]
            if (i % 2) == 0:
                self.__validate_condition(condition)
                if condition["operator"] not in (
                        "gte",
                        "lte",
                        "gt",
                        "lt",
                        "eq",
                        "neq",
                        "in",
                ):
                    raise DataInvalidException(
                        error_message="Operator is not valid for one of the conditions",
                        error_data={
                            "valid_operators": [
                                "gte",
                                "lte",
                                "gt",
                                "lt",
                                "eq",
                                "neq",
                                "in",
                            ],
                            "wrong_element_index": i,
                            "wrong_element": condition,
                        },
                    )
                operator = self.__get_operator_string(condition["operator"])
                conditions_string.append(
                    f"{condition['field']} {operator} {str(condition['value'])}"
                )
            else:
                operator = self.__get_condition_operator_string(condition["operator"])
                conditions_string.append(f"{operator}")
        conditions_string = " ".join(conditions_string)
        return conditions_string

    @print_function
    def generate_sql_condition_by_filter(
            self,
            table: str = None,
            conditions: list = "",
            forbidden_fields: list = None,
            acceptable_fields: list = ["*"],
            filter_fields_mapper: dict = None,
            place_holders_prefix: str = "p",
    ):
        """
        The method receive a list of conditions and generate the where SQL statement and its place holders.

        args:
            table: The name of the related table.
                type: string
                default: None, If you don't enter any table name, the method uses the 'table_name' that you have entered in the RDSHandler construction operation.

            conditions: A list of conditions and logical operators that will be converted to the SQL condition.
                type: list
                default: ""
                input samle :
                    [
                        {"field": "name", "operator": "like", "value": "ali"},
                        "and",
                        {"field": "username", "operator": "not in", "value": ["al", "li"]},
                    ]

            forbidden_fields: Defines which fields are forbidden for use as a 'field' in the 'conditions' argument.
                type: list of strings
                default: None

            acceptable_fields: Defines which fields are acceptable for use as a 'field' in the 'conditions' argument.
                type: list of strings
                default: None

            filter_fields_mapper: The arguments get a dictionary as fields mapper that we want to use instead of the 'field's item of condition object inside the 'conditions' argument.
                type: dict
                default: None

            place_holders_prefix: The prefix for placeholders that the method returns in result. It helps to avoid conflict of placeholders when you use this method several times in the code and use the results is one SQL query as placeholder.
                type: String
                default: 'p'

        returns: The function returns a dictionary with two fields, the 'sql_where'(It is sql.Composed object) that is used as SQL condition in your SQL query, and the 'placeholders' dictionary that is used as placeholders value to execute your SQL query by self.cursor.execute() method.
            type: dict
            NOTE: If you pass the empty 'conditions' to the method, it returns a dictionary with empty 'sql_where' and 'placeholders'.
            sample:
                {
                    "sql_where":sql.SQL("appropriate where cluse),
                    "placeholders":dict
                }

        raises:
            DataInvalidException
            Exception
        """
        print(
            f"LOG orm.generate_sql_condition_by_filter( self={self}, conditions={conditions}, forbidden_fields={forbidden_fields}, acceptable_fields={acceptable_fields}, table={table} ))"
        )
        if not conditions:
            return {"sql_where": None, "plceholders": {}}

        table = self.table_name if table is None else table

        ERROR_SOURCE = "ERROR-Filter invalid data"
        VALID_LOGICAL_OPERATORS = ("AND", "OR", "AND NOT", "OR NOT")
        VALID_CONDITIONAL_OPERATORS = (
            "=",
            "<>",
            ">",
            "<",
            ">=",
            "<=",
            "in",
            "not in",
            "like",
        )
        conditions_string = []
        placeholders = {}
        for i in range(len(conditions)):
            condition = conditions[i]
            if (i % 2) == 0:
                self.__validate_condition(condition)
                operator = condition["operator"]
                if operator.lower() not in VALID_CONDITIONAL_OPERATORS:
                    raise DataInvalidException(
                        f"{ERROR_SOURCE}/Wrong-condition-operator: Operator must be one of {VALID_CONDITIONAL_OPERATORS}."
                    )
                if forbidden_fields and condition["field"] in forbidden_fields:
                    raise DataInvalidException(
                        f"{ERROR_SOURCE}/Forbiden input fields: The '{condition['field']} field is forbiden."
                    )
                elif (
                        acceptable_fields != ["*"]
                        and condition["field"] not in acceptable_fields
                ):
                    raise DataInvalidException(
                        f"{ERROR_SOURCE}/Forbiden input fields: The '{condition['field']} field is not valid. The filter fields must be one of {acceptable_fields}."
                    )

                # TODO: Generate is None conditions

                # Generate field for using in SQL condition::
                if filter_fields_mapper:
                    # get the field from mapper
                    field = filter_fields_mapper[condition["field"]]
                    if isinstance(field, str):
                        field = [sql.SQL(field)]
                    else:
                        field = [field]
                else:
                    splited_field = condition["field"].split(".")
                    # Geting the field name
                    field_name = splited_field[-1]
                    # Geting the rds_handler table as the field_table, if there is not any table name
                    # in the original field else set the original field table name as the table_name.
                    field_table = table if len(splited_field) == 1 else splited_field[0]
                    # Generating table_name.field_name list for using in sql.Composed().
                    field = [
                        sql.Identifier(field_table),
                        sql.SQL("."),
                        sql.Identifier(field_name),
                    ]
                # Generating SQL condition
                if condition["value"] == None:
                    if operator.upper() in ["IN", "=", "LIKE"]:
                        operator = sql.SQL(f" IS ")
                    elif operator.upper() in ["NOT IN", "<>"]:
                        operator = sql.SQL(f" IS NOT ")

                    conditions_string.append(
                        sql.Composed(
                            field
                            + [
                                operator,
                                sql.SQL(f"NULL"),
                            ]
                        )
                    )
                elif operator.upper() in ["IN", "NOT IN"]:
                    conditions_string.append(
                        sql.Composed(
                            field
                            + [
                                sql.SQL(f" {operator} "),
                                sql.SQL("("),
                                sql.SQL(", ").join(
                                    sql.Placeholder(
                                        f"filter_placeholder_{place_holders_prefix}_{i}_{indx}"
                                    )
                                    for indx in range(len(condition["value"]))
                                ),
                                sql.SQL(")"),
                            ]
                        )
                    )
                    for indx in range(len(condition["value"])):
                        placeholders[
                            f"filter_placeholder_{place_holders_prefix}_{i}_{indx}"
                        ] = condition["value"][indx]

                elif operator.lower() == "like":
                    conditions_string.append(
                        sql.Composed(
                            [sql.SQL(f" LOWER(")]
                            + field
                            + [sql.SQL(f") ")]
                            + [
                                sql.SQL(f" {operator} LOWER("),
                                sql.Placeholder(
                                    f"filter_placeholder_{place_holders_prefix}_{i}"
                                ),
                                sql.SQL(f") "),
                            ]
                        )
                    )
                    placeholders[
                        f"filter_placeholder_{place_holders_prefix}_{i}"
                    ] = f"%{condition['value']}%"
                else:
                    conditions_string.append(
                        sql.Composed(
                            field
                            + [
                                sql.SQL(f" {operator} "),
                                sql.Placeholder(
                                    f"filter_placeholder_{place_holders_prefix}_{i}"
                                ),
                            ]
                        )
                    )
                    placeholders[f"filter_placeholder_{place_holders_prefix}_{i}"] = (
                        f"%{condition['value']}%"
                        if operator.lower() == "like"
                        else condition["value"]
                    )

            else:
                operator = condition
                if operator.upper() not in VALID_LOGICAL_OPERATORS:
                    raise DataInvalidException(
                        f"{ERROR_SOURCE}/Wrong-logical-operator: The logical operators must be one of {VALID_LOGICAL_OPERATORS}"
                    )
                conditions_string.append(sql.SQL(operator))
        sql_filter = sql.SQL(" ").join(conditions_string)
        print("mogrify(sql_where): ====")
        print(self.cursor.mogrify(sql_filter))
        return {"sql_where": sql_filter, "plceholders": placeholders}

    def filter(self, conditions, select_fields=None, page=0, count=10, order_by=None):

        if not select_fields:
            select_fields = "*"
        else:
            validate_string_iterable(select_fields)
            select_fields = ", ".join(select_fields)

        self.__validate_conditions(conditions)
        conditions = self._generate_conditions_string(conditions)

        if order_by and (order_by in select_fields):
            order_string = order_by
        else:
            order_string = select_fields[0]

        if (not isinstance(count, int)) or (not isinstance(page, int)):
            raise DataInvalidException(
                error_message="`count` and `page` arguments, both must be integers."
            )

        sql_statement = sql.SQL(
            f"SELECT {select_fields} FROM {self.table_name} "
            f"WHERE {conditions} "
            f"ORDER BY {order_string} "
            f"LIMIT {count} OFFSET {page};"
        )
        self.cursor.execute(sql_statement)

        if self.is_cursor_dict:
            return [dict(result) for result in self.cursor]
        else:
            return self.cursor.fetchall()

    def __dt_to_str(self, input_data, *args, **kwargs):
        """
        The method convert all datetimes field in a json object to the string recursivly.
        """
        # ------------------ CHANGE DATETIME FORMAT ---------------------------
        iterable_input = False

        try:
            iter_inputdate = iter(input_data)
            if not isinstance(input_data, dict) and not isinstance(input_data, str):
                iterable_input = True
        except Exception as e:
            pass

        # TODO: check it that the date can be convetr to datetime to send to the user.
        if isinstance(input_data, date):
            input_data = datetime(input_data.year, input_data.month, input_data.day)
        if isinstance(input_data, datetime):
            return input_data.replace(tzinfo=pytz.UTC).strftime("%Y-%m-%dT%H:%M:%S.%f")

        elif iterable_input:
            li = []
            for item in input_data:
                li.append(self.__dt_to_str(item))
            return li
        elif isinstance(input_data, dict):
            di = {}
            for k in input_data.keys():
                di[k] = self.__dt_to_str(input_data[k])
            return di
        else:
            return input_data

    def __convert_json_fields_to_str_and_empties_to_none(self, obj):
        """
        The method convert all json fields of obj to json string.
        It is used when you want update or insert record that have json fields.
        """
        for k in obj.keys():
            if not isinstance(obj.get(k), bool) and not obj.get(k):
                obj[k] = None
            elif isinstance(obj[k], dict):
                obj[k] = json.dumps(obj[k])
        return obj

    @print_function
    def delete_record(
            self,
            table: str = None,
            id="",
            where="",
            returning: str = "",
            placeholders_values_object: dict = {},
    ):
        """
        The method gets a table name and an id and deletes the corresponding record from the table.

        args:
            table: The name of related table.
                type: String
                default: None, If you don't enter any table name, the method uses the 'table_name' that you have entered in the RDSHandler construction operation.

            id: If enter the record id the method delete the corresponding record.
                type: Int
                default: ""
                NOTE: If you use 'id' and 'where' argument at same time the method uses 'id' to delete record

            where: The where statement that is created by psycopg2 methods.
                type: string | psycopg2.sql.Composable()
                default: ""
                NOTE: Don't use 'WHERE' word inside 'where sql statment' that you want to pass to this argument.
                NOTE: If you use 'id' and 'where' argument at same time the method uses 'id' to delete record
                value ex:
                    sql.SQL(" name like 'Ben%' and score > %(score_value)s")

            returning:
                type: String
                default: "*"
                description: This field is optional. It can be containe a string with fields of deleted record you want to return.
                            the field name must be separated using ",". The default value("*") causes to returne all fields.
                ex: "name, family, number"

            placeholders_values_object: If you use 'where' argument you may need to use this argument. This argument is an object that its fields are the same as placeholders name that were used in the 'where' argument.
                type: Dictinary
                default: {}
                ex: for the where example you can use this place holder.{"score_value":100}

        returns: The function returns deleted record as a dict depends on returning argument value.
            type: dict
            values: deleted record | None

        Raises:
            psycopg2.errors.NoDataFound: If there is not any record to delete.
            DeleteRecordException: If anyother exceptions happened
        """
        try:
            table = self.table_name if table is None else table

            if id != "":
                where = sql.SQL(
                    " WHERE {table}.{id} = %(get_record_record_id_1)s"
                ).format(table=sql.Identifier(table), id=sql.Identifier("id"))
                placeholders_values_object["get_record_record_id_1"] = id

            elif not where:
                raise Exception(
                    "There is not any conditional field. The function must have one of 'where' or 'id' field, otherwise the 'data_object' field must have 'id'."
                )
            elif isinstance(where, str):
                where = sql.SQL(" WHERE {where}").format(where=sql.SQL(where))
            else:
                where = sql.SQL(" ").join(sql.Composed([sql.SQL("WHERE "), where]))

            if returning != "":
                returning = "RETURNING " + returning

            sql_statement = sql.SQL("Delete FROM {table} {where} {returning}").format(
                table=sql.Identifier(table),
                where=where,
                returning=sql.SQL(returning),
            )
            self.cursor.execute(sql_statement, placeholders_values_object)
            if self.cursor.rowcount == 0:
                raise psycopg2.errors.NoDataFound("There is not any record.")

            result = None
            if returning != "":
                if self.cursor.rowcount > 1:
                    result = self.cursor.fetchall()
                else:
                    result = self.cursor.fetchone()

            return self.__dt_to_str(result)

        except psycopg2.errors.NoDataFound as e:
            raise e
        except Exception as e:
            raise DeleteRecordException(
                f"{self.BASE_ERROR_MSG} delete_record_from_table() | '{table}' table | condition: '{str(where)}' |  Traceback: {traceback.format_exc()}"
            )

    @print_function
    def update_record(
            self,
            data_object,
            table=None,
            id="",
            where="",
            where_placeholders_values_object={},
            returning="",
            convetr_json_columns=False,
    ):
        """
        The method gets a dictionary as 'data_object', the table name and update fields of record or records to the 'data_object' values depend on 'condition_field' , 'operation', and 'condition_value'. Then return the updated record or records depending on the 'returning' field value.

        args:
            data_object: An object that contains fields you want to update.
                type: dict
                NOTE: The object can just have the fields you want update.
                NOTE: The data_object can be haved the id value of the record you want update.
                NOTE: If you want to updatea nullable field to null you must set the field value to None.

            table: The name of related table.
                type: String
                default: None, If you don't enter any table name, the method uses the 'table_name' that you have entered in the RDSHandler construction operation.

            id: If enter the record id the method update the corresponding record.
                type: int
                default: ""
                NOTE: If there is any id field inside 'data_object' argument this argument will be bypassed.

            where: The where statement that is created by psycopg2 methods. if the 'id' argument there is not any value, the where clause can be used to update records.
                type: string | psycopg2.sql.Composable()
                default: ""
                NOTE: Don't use 'where' word inside the 'where' argument value.
                value ex:
                    sql.SQL(" {name} like %(name_ph) and {score} > %(score_value)").format(
                        name = sql.Identifier("name"),
                        score = sql.Identifier("score")
                    )

            where_placeholders_values_object: If you use 'where' argument you may need to use this argument. This argument value must be an object that its fields are the same as placeholders name that were used in the 'where' argument.
                type: Dictinary
                default: {}
                NOTE: Be careful, The 'where_placeholders_values_object' fields name must be different from the data_object field's names.
                ex: for the where example you can use this place holder:
                    {
                        "name_ph":"Ben%",
                        score_value":100
                    }

            returning: This field is optional. It can contain a string with fields of updated records you want to return. the field name must be separated with "," charachter.
                type: String
                default: ""
                ex: "name, family, number"

            convetr_json_columns:
                type: Boolean
                default: False
                description: To save dict object in JSONb columns it's needed to use json.dumbs() before saving.
                            If this argument is True function, it iterates all values and if the a value is dict convert it
                            by json.dumbs(). This process takes additional time. If you do not have any JSON in your fields
                            or you convert JSON fields by yourself, use the default value(False) of this argument, else you
                            can make it True.

        returns: The function returns deleted record as a dict object depends on 'returning' argument value.
            type: dict | array of dict objects | None
            values: updated record | an array of updated records | None

        raises:
            psycopg2.errors.NoDataFound: If there is not any record to delete.
            UpdateRecordException: If anyother exceptions happened

        """
        try:
            if convetr_json_columns:
                data_object = self.__convert_json_fields_to_str_and_empties_to_none(
                    data_object
                )

            table = self.table_name if table is None else table

            where = sql.SQL(" WHERE {table}.{id} = %(id)s").format(
                table=sql.Identifier(table), id=sql.Identifier("id")
            )
            if id != "":
                where_placeholders_values_object["id"] = id
            elif "id" in data_object.keys():
                where_placeholders_values_object["id"] = data_object.get("id")
            elif not where:
                raise Exception(
                    "There is not any conditional field. The function must have one of 'where' or 'id' field, otherwise the 'data_object' field must have 'id'."
                )
            elif isinstance(where, str):
                where = sql.SQL(" WHERE {where}").format(where=sql.SQL(where))
            else:
                where = sql.SQL(" ").join(sql.Composed([sql.SQL("WHERE "), where]))

            if returning != "":
                returning = "RETURNING " + returning
            sql_statement = sql.SQL(
                "UPDATE {table}  SET {data} {where} {returning};"
            ).format(
                table=sql.Identifier(table),
                data=sql.SQL(", ").join(
                    sql.Composed(
                        [sql.Identifier(k), sql.SQL(" = "), sql.Placeholder(k)]
                    )
                    for k in data_object.keys()
                    if k != "id"
                ),
                where=where,
                returning=sql.SQL(returning),
            )
            for key in where_placeholders_values_object.keys():
                data_object[key] = where_placeholders_values_object[key]

            self.cursor.execute(sql_statement, data_object)

            if self.cursor.rowcount == 0:
                raise psycopg2.errors.NoDataFound(f"There is not any record.")

            result = None
            if returning != "":
                if self.cursor.rowcount > 1:
                    result = self.cursor.fetchall()
                else:
                    result = self.cursor.fetchone()

            return self.__dt_to_str(result)
        except psycopg2.errors.NoDataFound as e:
            raise e
        except Exception as e:
            raise UpdateRecordException(
                f"{self.BASE_ERROR_MSG} update_record() | '{table}' table | condition: '{str(where)}' | Traceback: {traceback.format_exc()}"
            )

    @print_function
    def create_record(
            self, data_object, table=None, returning="*", convetr_json_columns=False
    ):
        """
        The method gets a table name and corresponding record-data-object and returns the created record depends on returning argument.

        arguments:
            -data_object:
                type: dict
                description: An object that contains fields you want to create in table.

            -table:
                type: String
                default: None, If you don't enter any table name, the method uses the 'table_name' that you have entered in the RDSHandler construction operation.
                Description: The name of the related table.

            -returning:
                type: String
                default: "*"
                description: This field is optional. It can be containe a string with fields of created record you want to return.
                            the field name must be seperated with ",". The default value("*") causes to returne all fields.
                ex: "name, family, number"

            -convetr_json_columns:
                type: Boolean
                default: False
                description: To save dict object in JSONb columns it's needed to use json.dumbs() before saving.
                            If this argument is True function, it iterates all values and if the a value is dict convert it
                            by json.dumbs(). This process takes additional time. If you do not have any JSON in your fields
                            or you convert JSON fields by yourself, use the default value(False) of this argument, else you
                            can make it True.
        returns: The function returns deleted record as a dict object depends on 'returning' argument value.
            type: dict
            values: Created record data

        raises:
            CreateRecordException: If any exceptions happened.
        """
        try:

            if convetr_json_columns:
                data_object = self.__convert_json_fields_to_str_and_empties_to_none(
                    data_object
                )

            table = self.table_name if table is None else table
            sql_statement = sql.SQL(
                "INSERT INTO {table} ({data_key}) "
                "VALUES ({values_place_holders}) "
                "RETURNING {returning_data}"
            ).format(
                table=sql.Identifier(table),
                data_key=sql.SQL(", ").join(
                    sql.Composed([sql.Identifier(k)])
                    for k in data_object.keys()
                    if k != "id"
                ),
                values_place_holders=sql.SQL(", ").join(
                    sql.Composed([sql.Placeholder(k)])
                    for k in data_object.keys()
                    if k != "id"
                ),
                returning_data=sql.SQL(returning),
            )
            print("cursor.mogrify(): ", self.cursor.mogrify(query=sql_statement))

            self.cursor.execute(sql_statement, data_object)
            return self.__dt_to_str(self.cursor.fetchone())

        except Exception as e:
            print(
                f"{self.BASE_ERROR_MSG} create_record() | '{table}' table | Traceback: {traceback.format_exc()}"
            )
            raise CreateRecordException(
                f"{self.BASE_ERROR_MSG} create_record() | '{table}' table | Traceback: {traceback.format_exc()}"
            )

    @print_function
    def create_records(
            self,
            data_list: list,
            columns: list,
            table=None,
            returning="*",
            convetr_json_columns=False,
    ):
        """
        The method get a table name and corresponding record-data-object and return the created record
        depend on returning argument.

        arguments:
            -data_list:
                type: list of tuples
                description: An list of tuples that contains fields value of each record you want to insert into database. The order of values is dependend on columns argument input order
                ex: for colums = ["name","family"]
                    data_list = [
                        ("Jack","London"),
                        ("Mark","Twain"),
                    ]

            -columns: The argument is a list of columns that you want to fill in the insert operation.
                type: list
                ex: ["name","family"]

            -table:
                type: String
                default: None, If you don't enter any table name, the method uses the 'table_name' that you have entered in the RDSHandler construction operation.
                Description: The name of related table.

            -returning:
                type: String
                default: "*"
                description: This field is optional. It can be containe a string with fields of created record you want to return.
                            the field name must be seperated with ",". The default value("*") causes to returne all fields.
                ex: "name, family, number"

            -convetr_json_columns:
                type: Boolean
                default: False
                description: To save dict object in JSONb columns it's needed to use json.dumbs() before saving.
                            If this argument is True function, it iterates all values and if the a value is dict convert it
                            by json.dumbs(). This process takes additional time. If you do not have any JSON in your fields
                            or you convert JSON fields by yourself, use the default value(False) of this argument, else you
                            can make it True.

        returns:
            type: list
            values: list of created records dictionaries

        rases:
            CreateRecordException: If any exceptions happened.
        """
        try:
            # convert empty fields value to None
            if convetr_json_columns:
                for i in range(len(data_list)):
                    item = data_list[i]
                    data_list[
                        i
                    ] = self.__convert_json_fields_to_str_and_empties_to_none(item)

            table = self.table_name if table is None else table
            if isinstance(columns, list) and isinstance(data_list, list):
                columns = sql.SQL(", ").join(
                    sql.Composed([sql.Identifier(col)])
                    for col in columns
                    if col != "id"
                )
            else:
                raise Exception(
                    " The method must get a list of tuple in data_list argument and a list of columns name in columns argument."
                )
            sql_statement = sql.SQL(
                "INSERT INTO {table} ({data_key}) "
                "VALUES %s "
                "RETURNING {returning_data}"
            ).format(
                table=sql.Identifier(table),
                data_key=columns,
                returning_data=sql.SQL(returning),
            )

            execute_values(self.cursor, sql_statement, data_list)
            return self.__dt_to_str(self.cursor.fetchall())

        except Exception as e:
            raise CreateRecordsException(
                f"{self.BASE_ERROR_MSG} create_records() | '{table}' table | Traceback: {traceback.format_exc()}"
            )

    @print_function
    def get_record(
            self,
            with_sql=None,
            table=None,
            id="",
            join="",
            where="",
            group_by="",
            placeholders_values_object={},
            select_fields="*",
            order_by="",
            limit="",
            offset="",
    ):
        """
        The method gets the table name and returns a record or an array of records depend on the 'where' or 'id' arguments value.
        NOTE: If there is not any 'id' and 'where' value in the input argument the method returns all records without any condition.

        args:
            -table: The name of related table.
                type: String
                default: None, If you don't enter any table name, the method uses the 'table_name' that you have entered in the RDSHandler construction operation.

            -id: If enter the record id the method returns the corresponding record.
                type: Int
                default: ""

            -join: If we need to use JOIN in the select query we can put the join statement into this argument.
                type: string | psycopg2.sql.Composable()
                default: ""

            -with_sql: If we have to use WITH query with our SELECT query we can put it here.
                type: string | psycopg2.sql.Composable()
                default: None

            -where: The where statement that is created by psycopg2 methods. if the 'id' argument there is not any value, the where clause can be used to select records.
                type: psycopg2.sql.Composable()
                default: ""
                NOTE: Don't use WHERE words inside where argument value.
                value ex:
                    sql.SQL(" {name} like %(name_ph) and {score} > %(score_value)").format(
                        name = sql.Identifier("name"),
                        score = sql.Identifier("score")
                    )

            -placeholders_values_object: If you use 'where' argument you may need to use this argument. This argument is an object that its fields are the same as placeholders name that were used in the 'where' argument.
                type: dict
                default: {}
                ex: for the where example you can use this place holder:
                    {
                        "name_ph":"Ben%",
                        score_value":100
                    }

            -select_fields:
                type: String
                default: "*"
                description:This field is optional. It can contain a string with fields you want to return. the field name must be separated using ",". The default value("*") causes to return all fields.
                ex: "name, family, number"

            -group_by : The argument is used when we have JOIN and we want to GROUP BY statement inside our SELECT query. t can contain a string with fields you want to use in GROUP BY statement. the field's name must be separated using ",".
                type: string
                default: ""

            -order_by: Accept SQL order by statement.
                type: String
                default: ""
                ex: "id ASC, name DESC"

            -limit: define sql query limit value.(limit and offset can be used in pagination together.)
                type: Int
                default:""

            -offset: define sql query offset value.(limit and offset can be used in pagination together.)
                type: Int
                default:""

        returns: return None, a record, or an array of records depend on 'condition_field' , 'operation', 'condition_value', and 'select_field'.
            type: dict | list
            values: A dict object of selected record | an list of selected records dicts | None

        raises:
            CreateRecordException: If any exceptions happened.

        """
        try:
            table = self.table_name if table is None else table
            if id != "":
                where = sql.SQL(
                    " WHERE {table}.{id} = %(get_record_record_id_1)s"
                ).format(table=sql.Identifier(table), id=sql.Identifier("id"))
                placeholders_values_object["get_record_record_id_1"] = id

            # ==== Generating WHERE
            elif not where:
                where = sql.SQL(" ")
            elif isinstance(where, str):
                where = sql.SQL(" WHERE {where}").format(where=sql.SQL(where))
            else:
                where = sql.SQL(" ").join(sql.Composed([sql.SQL("WHERE "), where]))
            # =====================

            # ==== Generating GROUP BY
            if not group_by:
                group_by = sql.SQL(" ")
            elif isinstance(group_by, str):
                group_by = sql.SQL(" GROUP BY {group_by}").format(
                    group_by=sql.SQL(group_by)
                )
            else:
                group_by = sql.SQL(" ").join(
                    sql.Composed([sql.SQL("GROUP BY "), group_by])
                )
            # ========================

            if order_by != "":
                order_by = f" ORDER BY {order_by}"

            if limit != "":
                limit = f" LIMIT {limit}"

            if offset != "":
                offset = f" OFFSET {offset}"

            # ===== START Generating field for using in SQL condition::
            if isinstance(select_fields, str):
                select_fields = sql.SQL(select_fields)

            elif isinstance(select_fields, list):
                field_list = []
                for field in select_fields:

                    if isinstance(field, str):
                        field = sql.SQL(field)

                    field_list.append(field)

                select_fields = sql.SQL(",").join(field_list)
            print("mogrify(select_fields): ====")
            print(self.cursor.mogrify(select_fields))
            # ====================================

            # ===== Generating with statement
            if with_sql == None:
                with_sql = sql.SQL(" ")
            if isinstance(with_sql, str):
                with_sql = sql.SQL(with_sql)

            elif not isinstance(with_sql, sql.Composable):
                raise Exception(
                    f"ERROR | The type of 'with_sql' argument of get_record() is not acceptable. type is {type(with_sql)}"
                )
            # ================================

            print("SELECT statement string: ====")
            print(
                f"SELECT {select_fields} FROM {table} {join} {where} {order_by} {limit} {offset}"
            )
            sql_statement = sql.SQL(
                "{with_sql} SELECT {fields} FROM {table} {join} {where} {group_by} {order_by} {limit} {offset};"
            ).format(
                with_sql=with_sql,
                fields=select_fields,
                table=sql.Identifier(table),
                join=sql.SQL(join),
                where=where,
                group_by=group_by,
                order_by=sql.SQL(order_by),
                limit=sql.SQL(limit),
                offset=sql.SQL(offset),
            )
            print("mogrify(sql_statement): ====")
            print(self.cursor.mogrify(query=sql_statement))

            self.cursor.execute(sql_statement, placeholders_values_object)
            if self.cursor.rowcount > 1:
                result = self.cursor.fetchall()
            else:
                result = self.cursor.fetchone()

            if not result:
                raise psycopg2.errors.NoDataFound(f"There is not any record.")

            return self.__dt_to_str(result)
        except psycopg2.errors.NoDataFound as e:
            print(
                f"{self.BASE_ERROR_MSG} get_record()  | '{table}' table | condition: '{str(where)}' |  Traceback: {traceback.format_exc()}"
            )
            raise e
        except Exception as e:
            raise GetRecordException(
                f"{self.BASE_ERROR_MSG} get_record() | '{table}' table | condition: '{str(where)}' |  Traceback: {traceback.format_exc()}"
            )

