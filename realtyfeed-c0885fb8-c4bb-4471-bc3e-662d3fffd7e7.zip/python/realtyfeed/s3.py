import json
import tempfile

import boto3


def download_archived_objects_from_s3(archive_type, object_type, object_id):
    S3_client = boto3.client('s3')

    bucket_name = "realtyfeed"
    folder_name = "archive"
    file_name = f"{folder_name}/archived-{archive_type}-{object_type}{object_id}.json"

    with tempfile.TemporaryFile(mode='w+b') as downloaded_file:
        S3_client.download_fileobj(bucket_name, file_name, downloaded_file)
        downloaded_file.seek(0)
        downloaded_data = downloaded_file.read()
    if isinstance(downloaded_data, (bytes, bytearray)):
        downloaded_data.decode('utf-8')
    if not downloaded_data:
        raise KeyError(type('hello')(downloaded_data))
    downloaded_data = json.loads(downloaded_data)
    if not isinstance(downloaded_data, list):
        raise KeyError("Data is fetched from S3 but it's not a list")
    return downloaded_data


def upload_archived_objects_to_s3(archive_type, object_type, object_id, data):
    S3_client = boto3.client('s3')

    bucket_name = "realtyfeed"
    folder_name = "archive"
    file_name = f"{folder_name}/archived-{archive_type}-{object_type}{object_id}.json"

    temp_file = tempfile.TemporaryFile()
    temp_file.write(json.dumps(data).encode())
    temp_file.seek(0)
    S3_client.upload_fileobj(temp_file, bucket_name, file_name, ExtraArgs={'ACL': 'private'})
    temp_file.close()