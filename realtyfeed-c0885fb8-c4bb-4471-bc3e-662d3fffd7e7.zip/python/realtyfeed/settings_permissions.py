from decimal import Decimal
import boto3
from botocore.exceptions import ClientError
from .exceptions import (
    InvalidInputException,
    DataInvalidException,
    NotFoundException,
    DynamoDBException,
)


def get_object_selected_permissions(object_type, object_id, keys):
    result = {}
    try:
        schema = {
            "user": {
                "table_name": "user_permissions",
                "partition_key": "user_id"
            },
            "group": {
                "table_name": "group_permissions",
                "partition_key": "group_id"
            }
        }

        if object_type not in schema.keys():
            raise Exception("invalid object type")

        if object_id < 1:
            raise Exception("invalid object id")

        if len(keys) == 0:
            return result

        table_name = schema[object_type]["table_name"]
        partition_key = schema[object_type]["partition_key"]

        dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
        table = dynamodb.Table(table_name)

        record = table.get_item(
            Key={partition_key: object_id},
            ProjectionExpression=", ".join(keys)

        )

        if 'Item' not in record:
            print(f"{object_type} ({object_id}) does not exists.")
            return result

        item = record['Item']
        for k in keys:
            result[k] = item.get(k)

    except Exception as ex:
        print(ex)

    return result


def get_object_selected_settings(object_type, object_id, keys):
    if len(keys) < 1:
        raise LookupError

    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')

    table_key, lookup_key = "table", "lookup_key"
    lookup_data = {
        "system": {table_key: "system_role_settings", lookup_key: "key"},
        "system_role": {table_key: "system_role_settings", lookup_key: "key"},
        "user": {table_key: "user_settings", lookup_key: "user_id"},
        "group_type": {table_key: "group_types_settings", lookup_key: "group_type_id"},
        "group": {table_key: "group_settings", lookup_key: "group_id"},
        "btt_type_item": {table_key: "btt_type_items_permissions_settings", lookup_key: "btt_type_item_id"},
        "btt_type": {table_key: "btt_type_items_permissions_settings", lookup_key: "btt_type_item_id"},
        "btt": {table_key: "btt_type_items_permissions_settings", lookup_key: "btt_type_item_id"},
        "announcement": {table_key: "announcement_settings", lookup_key: "announcement_id"},
        "listing": {table_key: "listing_settings", lookup_key: "listing_id"},
        "package": {table_key: "packages_settings", lookup_key: "package_id"},
    }

    try:
        table_key = lookup_data[object_type][table_key]
        lookup_key = lookup_data[object_type][lookup_key]
    except LookupError:
        raise InvalidInputException(
            f"`{object_type}` object type is invalid."
            f" Can be one of below list: {', '.join(list(lookup_data.keys()))}"
        )

    table = dynamodb.Table(table_key)
    try:
        item = table.get_item(
            Key={lookup_key: object_id}
        )["Item"]
    except ClientError:
        raise DataInvalidException(
            f"Cannot query on database. Please provide value for `{lookup_key}` by `object_id`"
        )
    except LookupError:
        raise NotFoundException(
            f"Couldn't find {object_type} record with `{lookup_key}`=`{object_id}`"
        )

    current_lookup = {key: None for key in keys}
    for requested_key in keys:
        settings_key_set = requested_key.split('.')

        if len(settings_key_set) < 1:
            raise InvalidInputException(
                f"`keys` input value must be a correct list of field name "
                "(with their sub-fields names, maybe), split with `.`"
            )

        current_lookup[requested_key] = item
        for key in settings_key_set:
            try:
                current_lookup[requested_key] = current_lookup.get(requested_key, {}).get(key)
                if isinstance(current_lookup.get(requested_key), Decimal):
                    current_lookup[requested_key] = float(current_lookup[requested_key])
            except LookupError:
                raise DynamoDBException(
                    f"[{' -> '.join(settings_key_set)}] field(s)"
                    f" of table `{table_key}` is unreachable."
                )
            if not isinstance(current_lookup[requested_key], dict):
                break

    return current_lookup
