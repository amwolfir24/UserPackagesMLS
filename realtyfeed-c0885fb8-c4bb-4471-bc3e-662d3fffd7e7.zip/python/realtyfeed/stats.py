from decimal import Decimal
from typing import Any

import boto3
from botocore.exceptions import ClientError

from .ddb import get_dynamodb_type
from .event_bridge import call_event_buffering_process
from .exceptions import DataInvalidException, InvalidInputException, RealtyfeedException


def get_selected_stats(object_type, partition_value, requested_keys, sort_value=None, date_range="all"):
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')

    if not isinstance(requested_keys, list):
        if requested_keys != "all":
            raise InvalidInputException("Invalid keys. Must be a list of desired keys or `all`.")
        requested_keys = ["all"]
    elif len(requested_keys) < 1:
        raise InvalidInputException("Invalid keys. List is empty.")

    if date_range != "all":
        if date_range not in ("total", "weekly", "monthly", "daily"):
            raise DataInvalidException(
                "`date_range` can be one of ('total', 'weekly', 'monthly', 'daily') options.")

    lookup_data = {
        "user": {
            "table_name": "user_stats",
            "partition_key": "user_id",
        },
        "group": {
            "table_name": "group_stats",
            "partition_key": "group_id",
        },
        "listing": {
            "table_name": "listing_stats",
            "partition_key": "listing_id",
        },
        "announcement": {
            "table_name": "announcement_and_shares_stats",
            "partition_key": "id",
        },
        "listing_comment": {
            "table_name": "listing_comment_stats",
            "partition_key": "comment_id",
        },
        "announcement_comment": {
            "table_name": "announcement_comment_stats",
            "partition_key": "comment_id",
        },
        "hashtag": {
            "table_name": "hashtag_stats",
            "partition_key": "hashtag_id",
        },
        "shared_object": {
            "table_name": "announcement_and_shares_stats",
            "partition_key": "id",
        },
        "user_album": {
            "table_name": "user_album_stats",
            "partition_key": "album_id",
        },
        "group_album": {
            "table_name": "group_album_stats",
            "partition_key": "album_id",
        },
        "user_image": {
            "table_name": "user_image_stats",
            "partition_key": "image_id",
        },
        "group_image": {
            "table_name": "group_image_stats",
            "partition_key": "image_id",
        },
        "location": {
            "table_name": "location_stats",
            "partition_key": "id",
        },
        "zipcodes": {
            "table_name": "zipcodes_stats",
            "partition_key": "id",
        }
    }

    try:
        table_key = lookup_data[object_type]["table_name"]
        partition_key = lookup_data[object_type]["partition_key"]
        sort_key = lookup_data[object_type].get("sort_key")
        if sort_key and (not sort_value):
            raise InvalidInputException(f"Sort value must be present for `{object_type}` type")
    except LookupError:
        raise InvalidInputException(
            f"`{object_type}` object type is invalid."
            f" Can be one of below list: {', '.join(list(lookup_data.keys()))}"
        )
    except ValueError as e:
        raise RealtyfeedException(str(e))

    table = dynamodb.Table(table_key)

    # ========== List ==========
    if isinstance(partition_value, list):
        if len(partition_value) > 100 or len(partition_value) == 0:
            raise InvalidInputException(
                error_message="Invalid List Items"
            )

        batch_get_keys = []
        for key_id in partition_value:
            batch_get_keys.append({partition_key: key_id})
        try:
            items = dynamodb.batch_get_item(
                RequestItems={
                    table_key: {
                        'Keys': batch_get_keys,
                        "ProjectionExpression": ",".join(requested_keys)
                    }
                }
            )['Responses'][table_key]
        except ClientError as e:
            raise DataInvalidException(
                e.response['Error']['Message']
            )
        except LookupError:
            error_message = f"Couldn't find {object_type} record with `{partition_key}`=`{partition_value}`"
            if sort_key and sort_value:
                error_message = error_message + f" and `{sort_key}`=`{sort_value}`"
                raise DataInvalidException(error_message)

        objects_list = []
        current_lookup = {}
        for item in items:
            for item_data_key in item:
                try:
                    if date_range != 'all':
                        current_lookup[item_data_key] = item.get(item_data_key, {}).get(date_range)
                        if current_lookup[item_data_key] and isinstance(current_lookup[item_data_key], Decimal):
                            current_lookup[item_data_key] = float(current_lookup[item_data_key])

                    else:
                        current_lookup[item_data_key] = item.get(item_data_key, {})
                        if current_lookup[item_data_key] and isinstance(current_lookup[item_data_key], dict):
                            for date_range_key in current_lookup[item_data_key].keys():
                                if isinstance(current_lookup[item_data_key][date_range_key], Decimal):
                                    current_lookup[item_data_key][date_range_key] = float(
                                        current_lookup[item_data_key][date_range_key])
                except LookupError:
                    raise DataInvalidException(
                        f"{item_data_key} field of table `{table_key}` is unreachable.")
            objects_list.append(current_lookup)

        return objects_list

    object_lookup_keys = {partition_key: partition_value}
    if sort_key and sort_value:
        object_lookup_keys[sort_key] = sort_value

    try:
        if isinstance(requested_keys, str) and requested_keys == "all":
            item = table.get_item(
                Key=object_lookup_keys,
                ConsistentRead=True
            )["Item"]
        else:
            item = table.get_item(
                Key=object_lookup_keys,
                ProjectionExpression=','.join(requested_keys),
                ConsistentRead=True
            )["Item"]
    except ClientError:
        raise DataInvalidException(
            f"Cannot query on database. Please provide value for `{partition_key}` by `object_id` key"
        )
    except LookupError:
        error_message = f"Couldn't find {object_type} record with `{partition_key}`=`{partition_value}`"
        if sort_key and sort_value:
            error_message = error_message + f" and `{sort_key}`=`{sort_value}`"
        raise DataInvalidException(error_message)

    current_lookup = {}
    for item_data_key in item:
        try:
            if date_range != 'all':
                current_lookup[item_data_key] = item.get(item_data_key, {}).get(date_range)
                if current_lookup[item_data_key] and isinstance(current_lookup[item_data_key], Decimal):
                    current_lookup[item_data_key] = float(current_lookup[item_data_key])
            else:
                current_lookup[item_data_key] = item.get(item_data_key, {})
                if current_lookup[item_data_key] and isinstance(current_lookup[item_data_key], dict):
                    for date_range_key in current_lookup[item_data_key].keys():
                        if isinstance(current_lookup[item_data_key][date_range_key], Decimal):
                            current_lookup[item_data_key][date_range_key] = float(
                                current_lookup[item_data_key][date_range_key])
        except LookupError:
            raise DataInvalidException(f"{item_data_key} field of table `{table_key}` is unreachable.")

    return current_lookup

def update_stats(inputs):
    dynamodb = boto3.client('dynamodb')

    try:
        # Getting source field input (required)
        source_object_type: str = inputs["source_object_type"].rstrip('s')
        source_object_id: Any[int, str] = inputs["source_object_id"]
        source_sort_key: str = inputs.get("source_sort_key", None)
        source_sort_value: str = inputs.get("source_sort_value", None)
        source_set_key: str = inputs["source_key"].lower()
        source_set_value = inputs.get("source_value", 1)
        source_operator = inputs.get("source_operator", "plus")
        fields = {
            "source": (
                source_object_type,
                source_object_id,
                source_sort_key,
                source_sort_value,
                source_set_key,
                source_set_value,
                source_operator
            )
        }
        # Generating empty table update data sample for source
        table_update_data = {
            "source": {
                'Key': {},
                'UpdateExpression': "",
                'TableName': "",
                'ExpressionAttributeNames': {},
                'ExpressionAttributeValues': {}
            }
        }

        try:
            target_object_type: str = inputs["target_object_type"].rstrip('s')
            target_object_id: Any[int, str] = inputs["target_object_id"]
            target_sort_key: str = inputs.get("target_sort_key", None)
            target_sort_value: str = inputs.get("target_sort_value", None)
            target_set_key: str = inputs["target_key"].lower()
            target_set_value = inputs.get("target_value", 1)
            target_operator = inputs.get("target_operator", "plus")
        except LookupError:
            pass
        else:
            # Getting target field input (optional - if any exists)
            fields["target"] = (
                target_object_type,
                target_object_id,
                target_sort_key,
                target_sort_value,
                target_set_key,
                target_set_value,
                target_operator
            )
            # Generating empty table update data sample for target
            table_update_data["target"] = {
                'Key': {},
                'UpdateExpression': "",
                'TableName': "",
                'ExpressionAttributeNames': {},
                'ExpressionAttributeValues': {}
            }
    except LookupError:
        raise InvalidInputException(f"Invalid Input data")

    for idx, input_set in enumerate(fields.items(), start=1):
        # `sort` here refers to the `sort_key` column of the table
        # `sort_key` is the name of `sort_key` column
        # `sort_value` is the desired value of `sort_key` column which we will lookup with
        input_type, (object_type, object_id, sort_key, sort_value, set_key, set_value, operator) = input_set
        # Validate `object_type` input
        validation_values = [
            (object_type, ("user", "group", "listing", "announcement", "comment", "hashtag"), 'Object type'),
            (operator, ("plus", "minus"), 'Operator'),
        ]
        for input, choices, name in validation_values:
            if input not in choices:
                raise InvalidInputException(
                    f"{name} `{input}` is invalid. Can be one of below list:"
                    f" \n {', '.join(choices)}"
                )
        op = "+" if operator == "plus" else "-"

        # Generate update data for generation of update expression
        # `ht` stands for `hashtag`
        ht_set_key = f"#{set_key}"
        lookup_keys = [['total', 'weekly', 'monthly', 'daily'], [set_key, 'activity_count']]
        ht_lookup_keys = [['#TOT', '#WE', '#MO', '#DA'], [ht_set_key, '#ACC']]

        # Generate update expression with update data
        # If field is map type (dictionary), add to each period time within the map else, append to it (as a list)
        # Fields which ends with `_btt` are list type
        # `regions` field and `user_professions` field within `user_stats` table are list type
        if (set_key.endswith("_btt")) or (object_type == "user" and set_key in ("regions", "user_professions")):
            update_expression = f"SET {ht_set_key} = list_append({ht_set_key}, :setValue)"
            if not isinstance(set_value, list):
                set_value = [set_value]
        else:
            expr_args = [
                f"{ht_set_key}.{ht_period_key} = {ht_set_key}.{ht_period_key} {op} :setValue" for ht_period_key in
                ht_lookup_keys[0]
            ]
            update_expression = f"SET {', '.join(expr_args)}"

        # Add expressions to update `activity_count` field on any table which is going to be updated
        expr_args = [f"#ACC.{ht_period_key} = #ACC.{ht_period_key} + :activityVal" for ht_period_key in
                     ht_lookup_keys[0]]
        update_expression = f"{update_expression}, {', '.join(expr_args)}"

        # Initialize data for calling `update_item` of DynamoDB and filling all placeholders within update expression
        # `partition_key` will be automatically looked up as the `{object_type}_id` format. e.g. comment_id
        object_lookup_keys = {
            f"{object_type}_id": {
                get_dynamodb_type(object_id): str(object_id) if isinstance(object_id, int) else object_id
            }
        }
        if sort_key and sort_value:
            object_lookup_keys[sort_key] = {get_dynamodb_type(sort_value): sort_value}

        # Filling `table_update_data` value to use in transactional update, after finishing loop of target and source
        table_update_data[input_type]['TableName'] = f"{object_type}_stats"
        table_update_data[input_type]['Key'] = object_lookup_keys
        table_update_data[input_type]['UpdateExpression'] = update_expression
        table_update_data[input_type]['ExpressionAttributeNames'] = {
            ht_key: key for (ht_key, key) in
            zip((ht_lookup_keys[0] + ht_lookup_keys[1]), (lookup_keys[0] + lookup_keys[1]))
        }
        table_update_data[input_type]['ExpressionAttributeValues'] = {
            ':setValue': {get_dynamodb_type(set_value): str(set_value) if isinstance(set_value, int) else set_value},
            ':activityVal': {'N': "1"}
        }

    # Update item
    try:
        # Make sure that target|source item has required attributes (like `TableName`) for updating
        # No value within `item_data` must be empty (empty dict or empty str, or None at all)
        transact_items = [
            {'Update': item_data} for item_data in table_update_data.values() if all(x for x in item_data.values())
        ]
        # Update source item (and target, if any), transactional
        dynamodb.transact_write_items(
            TransactItems=transact_items
        )
        event_input_data = {
            "kinesis": {
                'analysis-type': 'hot-cold',
                'action': 'update-stats',
                'analysis-data': {
                    'action': 'update-stats',
                    'object-type': source_object_type,
                    'object-id': source_object_id,
                    'fields-updated': fields
                },
                'Message': f'Stats for {source_object_type} {source_object_id} has been updated'
            }
        }
        call_event_buffering_process(
            event_type='Stats',
            event_input_data=event_input_data,
            has_events=False,
            has_kinesis=True
        )
    except Exception as e:
        raise RealtyfeedException(f"Error class: {e.__class__.__name__} | {str(e)}")
