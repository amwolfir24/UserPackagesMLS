import datetime
import json
import uuid

import boto3
import pytz
from boto3.dynamodb.conditions import Attr
from boto3.dynamodb.types import Binary

from .exceptions import DataInvalidException, RealtyfeedException, NotFoundException, DynamoDBException
from .helpers import parse_duration


def get_token_with_encryption(key_id, user_id):
    try:
        uuid.UUID(key_id)
    except:
        raise DataInvalidException("Invalid key ID", error_status_code=1100)

    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    table = dynamodb.Table("tokenization")

    object_lookup_keys = {"uuid": key_id, "user_id": user_id}
    try:
        item = table.get_item(
            Key=object_lookup_keys
        )["Item"]
        if not item:
            raise Exception
    except:
        raise NotFoundException(f"Couldn't find tokenized key record.", error_status_code=1103)

    try:
        expiry_date = datetime.datetime.fromisoformat(item["expiry_date"])
    except:
        expiry_date = None

    if (expiry_date) and (datetime.datetime.now().replace(tzinfo=pytz.UTC) > expiry_date.replace(tzinfo=pytz.UTC)):
        raise DataInvalidException("Key has been expired or deleted. Try to create a new key.",
                                   error_status_code=1104)

    if not item["encrypted"]:
        raise RealtyfeedException(error_message="Data is not encrypted.", error_status_code=1105)

    kms_client = boto3.client("kms")
    try:
        decrypted_data = kms_client.decrypt(
            CiphertextBlob=bytes(item["data"]),
            KeyId=item['uuid'],
            EncryptionAlgorithm='SYMMETRIC_DEFAULT'
        )
        decrypted_data = decrypted_data['Plaintext'].decode('utf-8')
        decrypted_data = json.loads(decrypted_data)
    except:
        raise DataInvalidException("Failed to decrypt data.", error_status_code=1106)

    return {
        "key_id": item["uuid"],
        "data": decrypted_data,
        "expiry_date": item["expiry_date"],
        "type": item["type"]
    }


def get_token_without_encryption(key_id, user_id):
    try:
        try:
            uuid.UUID(key_id)
        except:
            raise LookupError
    except LookupError:
        raise DataInvalidException("Invalid key ID", error_status_code=1100)

    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    table = dynamodb.Table("tokenization")

    object_lookup_keys = {"uuid": key_id, "user_id": user_id}
    try:
        item = table.get_item(
            Key=object_lookup_keys
        )["Item"]
        if not item:
            raise Exception
    except:
        raise NotFoundException(f"Couldn't find tokenized key record.", error_status_code=1103)

    try:
        expiry_date = datetime.datetime.fromisoformat(item["expiry_date"])
    except:
        expiry_date = None

    if (expiry_date) and (datetime.datetime.now().replace(tzinfo=pytz.UTC) > expiry_date.replace(tzinfo=pytz.UTC)):
        raise DataInvalidException("Key has been expired or deleted. Try to create a new key.",
                                   error_status_code=1104)

    if item["encrypted"]:
        raise RealtyfeedException(error_message="Data is encrypted.", error_status_code=1105)
    
    try:
        item_data = item["data"]
        if isinstance(item_data, Binary):
            item_data = bytes(item_data)
        if isinstance(item["data"], (bytes, bytearray)):
            item_data = item_data.decode('utf-8')
        item_data = json.loads(item_data)
    except Exception as ex:
        raise DataInvalidException(f"Failed to decrypt data", error_status_code=1106)

    return {
        "key_id": item["uuid"],
        "data": item_data,
        "expiry_date": item["expiry_date"],
        "type": item["type"]
    }


def create_token_with_encryption(token_data, token_type, user_id, token_expiry=None):
    now_date = datetime.datetime.now().replace(tzinfo=pytz.UTC)

    expiry_date = None
    if token_expiry:
        try:
            if isinstance(token_expiry, str):
                try:
                    expiry_date = datetime.datetime.fromisoformat(token_expiry).replace(tzinfo=pytz.UTC)
                except:
                    token_expiry = parse_duration(token_expiry)
                    expiry_date = (now_date + token_expiry).replace(tzinfo=pytz.UTC)
            elif isinstance(token_expiry, int):
                token_expiry = datetime.timedelta(hours=token_expiry)
                expiry_date = now_date + token_expiry
            else:
                raise DataInvalidException("Invalid token expiry format. Must be an iso-formatted date or Django duration string.")

            if expiry_date.replace(tzinfo=pytz.UTC) <= now_date:
                raise DataInvalidException("Expiry date is already expired")

            expiry_date = expiry_date.isoformat()
        except DataInvalidException as ex:
            raise ex

    if token_type not in ("privileged", "price", "user_data"):
        raise DataInvalidException('Invalid token type. Must be in ("privileged", "price", "user_data")',
                                   error_status_code=1101)

    try:
        token_data = json.dumps(token_data).encode()
    except:
        raise DataInvalidException("Invalid token data. It must be a list (array) or dictionary (object)",
                                   error_status_code=1102)

    kms_client = boto3.client("kms")
    try:
        key_id = kms_client.create_key(KeyUsage="ENCRYPT_DECRYPT")['KeyMetadata']['KeyId']
        try:
            uuid.UUID(key_id)
        except:
            raise LookupError
    except:
        raise DataInvalidException(f"Failed to create encryption key.", error_status_code=1103)

    try:
        encrypted_token_data = kms_client.encrypt(
            KeyId=key_id,
            Plaintext=token_data,
            EncryptionAlgorithm='SYMMETRIC_DEFAULT'
        )
        encrypted_token_data = encrypted_token_data['CiphertextBlob']
    except:
        raise DataInvalidException("Failed to create encryption key.", error_status_code=1104)

    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    table = dynamodb.Table("tokenization")
    try:
        table.put_item(Item={
            "uuid": key_id,
            "user_id": user_id,
            "type": token_type,
            "data": encrypted_token_data,
            "encrypted": True,
            "creation_date": now_date.isoformat(),
            "expiry_date": expiry_date
        })
    except:
        raise DynamoDBException(f"Can't create tokenized record", error_status_code=1105)

    return {
        "key_id": key_id,
        "expiry_date": expiry_date,
        "type": token_type,
        "encrypted": True
    }
    


def create_token_without_encryption(token_data, token_type, user_id, token_expiry=None):

    now_date = datetime.datetime.now().replace(tzinfo=pytz.UTC)
    expiry_date = None
    if token_expiry:
        
        try:
            if isinstance(token_expiry, str):
                try:
                    expiry_date = datetime.datetime.fromisoformat(token_expiry).replace(tzinfo=pytz.UTC)
                except:
                    token_expiry = parse_duration(token_expiry)
                    expiry_date = (now_date + token_expiry).replace(tzinfo=pytz.UTC)
            elif isinstance(token_expiry, int):
                token_expiry = datetime.timedelta(hours=token_expiry)
                expiry_date = now_date + token_expiry
            else:
                raise Exception
        
            if expiry_date.replace(tzinfo=pytz.UTC) <= now_date:
                raise DataInvalidException("Expiry date is already expired")
            
            expiry_date = expiry_date.isoformat()
        except Exception as ex:
            raise DataInvalidException(
                str(ex),
                error_status_code=1100
            )

    if token_type not in ("privileged", "price", "user_data"):
        raise DataInvalidException('Invalid token type. Must be in ("privileged", "price", "user_data")', error_status_code=1101)

    try:
        token_data = json.dumps(token_data).encode()
    except:
        raise DataInvalidException("Invalid token data. It must be a list (array) or dictionary (object)",
                                   error_status_code=1102)

    key_id = str(uuid.uuid4())

    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    table = dynamodb.Table("tokenization")
    try:
        table.put_item(Item={
            "uuid": key_id,
            "user_id": user_id,
            "type": token_type,
            "data": token_data,
            "encrypted": False,
            "creation_date": now_date.isoformat(),
            "expiry_date": expiry_date
        })
    except Exception as ex:
        raise DynamoDBException(f"Can't create tokenized record: {str(ex)}", error_status_code=1103)

    return {
        "key_id": key_id,
        "expiry_date": expiry_date,
        "type": token_type,
        "encrypted": False
    }


def delete_expired_tokens():
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    table = dynamodb.Table("tokenization")

    now_date = datetime.datetime.now().replace(tzinfo=pytz.UTC)
    try:
        items = table.scan(
            FilterExpression=Attr('expiry_date').lte(now_date.isoformat())
        )["Items"]
        if not items:
            raise NotFoundException
            
    except NotFoundException:
        raise NotFoundException
    except Exception as ex:
        raise RealtyfeedException(error_message=f"Error in getting expired list: {str(ex)}", error_status_code=1101)
    
    try:
        with table.batch_writer() as batch:
            for each in items:
                batch.delete_item(Key={'uuid':each['uuid'], 'user_id': each['user_id']})
        
    except Exception as ex:
        raise DynamoDBException(f"Error in deleting expired items: {str(ex)}", error_status_code=1102)