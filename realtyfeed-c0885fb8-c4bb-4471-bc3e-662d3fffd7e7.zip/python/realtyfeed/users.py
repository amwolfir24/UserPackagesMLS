import datetime
from functools import lru_cache
from typing import List

import jwt
import pytz
from jwt import PyJWKSet, PyJWKClientError, PyJWK
from jwt.api_jws import decode_complete
from psycopg2 import sql

from .configs import COGNITO_JWK
from .error_codes import EMAIL_NOT_VERIFIED_TOKEN, INVITATION_NOT_VALID_TOKEN, INCOMPLETE_PROFILE_TOKEN
from .exceptions import InvalidTokenException, RealtyfeedException, DataInvalidException
from .orm import RDSHandler


class PyJWKClient:
    def __init__(self, cache_keys: bool = True, max_cached_keys: int = 16):
        if cache_keys:
            # Cache signing keys
            # Ignore mypy (https://github.com/python/mypy/issues/2427)
            self.get_signing_key = lru_cache(maxsize=max_cached_keys)(self.get_signing_key)  # type: ignore

    def get_jwk_set(self) -> PyJWKSet:
        return PyJWKSet.from_dict(COGNITO_JWK)

    def get_signing_keys(self) -> List[PyJWK]:
        jwk_set = self.get_jwk_set()
        signing_keys = [
            jwk_set_key
            for jwk_set_key in jwk_set.keys
            if jwk_set_key.public_key_use in ["sig", None] and jwk_set_key.key_id
        ]

        if not signing_keys:
            raise PyJWKClientError("The JWKS endpoint did not contain any signing keys")

        return signing_keys

    def get_signing_key(self, kid: str) -> PyJWK:
        signing_keys = self.get_signing_keys()
        signing_key = None

        for key in signing_keys:
            if key.key_id == kid:
                signing_key = key
                break

        if not signing_key:
            raise PyJWKClientError(
                f'Unable to find a signing key that matches: "{kid}"'
            )

        return signing_key

    def get_signing_key_from_jwt(self, token: str) -> PyJWK:
        unverified = decode_complete(token, options={"verify_signature": False})
        header = unverified["header"]
        return self.get_signing_key(header.get("kid"))


def decode_rs256_token(token: str) -> dict:
    jwk_client = PyJWKClient()
    signing_key = jwk_client.get_signing_key_from_jwt(token)

    payload = jwt.decode(token, signing_key.key, algorithms=["RS256"], options={"verify_aud": False})
    return payload


def decode_token(token: str) -> dict:
    payload = jwt.decode(token, options={
        "verify_signature": False,
        "verify_aud": False,
        "verify_iat": False,
        "verify_exp": False,
        "verify_iss": False,
        "verify_nbf": False
    }, verify=False)
    return payload


def get_user_id(token, verify=False):
    # DEPRECATED
    return authenticate(token, verify)


def authenticate(token, verify=True):
    # TODO must be implemented
    # https://docs.aws.amazon.com/cognito/latest/developerguide/amazon-cognito-user-pools-using-tokens-verifying-a-jwt.html

    try:
        if verify:
            decoded_jwt = decode_rs256_token(token)
        else:
            decoded_jwt = decode_token(token)

        try:
            user_id = decoded_jwt["user_id"]
            email = decoded_jwt["email"]
            email_verified = decoded_jwt["email_verified"]
            invitation_validated = decoded_jwt["invitation_validated"]
            profile_setup_status = decoded_jwt["profile_setup_status"]
        except LookupError:
            raise InvalidTokenException(error_message="Incomplete token.")

        if isinstance(profile_setup_status, str):
            profile_setup_status = profile_setup_status.strip()

        if email_verified not in (True, "true"):
            raise InvalidTokenException(error_message="Email is not verified for token",
                                        error_status_code=EMAIL_NOT_VERIFIED_TOKEN)

        if invitation_validated not in (True, "true"):
            raise InvalidTokenException(error_message="Invitation is not valid for token",
                                        error_status_code=INVITATION_NOT_VALID_TOKEN)

        if profile_setup_status not in ("Done", "done"):
            raise InvalidTokenException(error_message="Profile is not completed for token",
                                        error_status_code=INCOMPLETE_PROFILE_TOKEN)
    except RealtyfeedException as e:
        raise e
    except Exception:
        raise InvalidTokenException()

    return {
        "user_id": user_id,
        "email": email
    }


def simple_auth(token, verify=True, verify_profile_setup=True,
                verify_email=True, verify_invitation=True):
    try:
        if verify:
            decoded_jwt = decode_rs256_token(token)
        else:
            decoded_jwt = decode_token(token)

        try:
            user_id = decoded_jwt["user_id"]
            email = decoded_jwt["email"]
        except LookupError:
            raise InvalidTokenException(error_message="Incomplete token.")

        if verify_profile_setup:
            profile_setup_status = decoded_jwt["profile_setup_status"]
            if isinstance(profile_setup_status, str):
                profile_setup_status = profile_setup_status.strip()
            if profile_setup_status not in ("Done", "done"):
                raise InvalidTokenException(error_message="Profile is not completed for token",
                                            error_status_code=INCOMPLETE_PROFILE_TOKEN)

        if verify_email:
            email_verified = decoded_jwt["email_verified"]
            if email_verified not in (True, "true"):
                raise InvalidTokenException(error_message="Email is not verified for token",
                                            error_status_code=EMAIL_NOT_VERIFIED_TOKEN)

        if verify_invitation:
            invitation_validated = decoded_jwt["invitation_validated"]
            if invitation_validated not in (True, "true"):
                raise InvalidTokenException(error_message="Invitation is not valid for token",
                                            error_status_code=INVITATION_NOT_VALID_TOKEN)

    except RealtyfeedException as e:
        raise e
    except Exception:
        raise InvalidTokenException()

    return {
        "user_id": int(user_id),
        "email": email
    }


def get_user_tag_type_items(cursor, user_id, tag_type="expertises"):
    tag_type = tag_type.rstrip('s')
    if tag_type == "expertise":
        tag_type = 1
    elif tag_type == "profession":
        tag_type = 2
    elif tag_type == "interest":
        tag_type = 3
    else:
        raise DataInvalidException("Tag type is invalid.")

    user_tags = []
    user_tag_types = []
    user_tag_type_items = []
    user_data = []

    user_tags_sql_statement = sql.SQL(
        "SELECT {pkey}, {user_tag_type_item_pkey} FROM {table_name} WHERE {user_pkey}=%(user_id)s"
    ).format(
        pkey=sql.Identifier("id"), user_tag_type_item_pkey=sql.Identifier("user_tag_type_items_id"),
        table_name=sql.Identifier("user_tags"), user_pkey=sql.Identifier("user_id")
    )
    cursor.execute(user_tags_sql_statement, {'user_id': user_id})
    for item in cursor:
        if item:
            if "id" in item:
                user_tags.append(item['id'])
            if "user_tag_type_items_id":
                user_tag_type_items.append(item['user_tag_type_items_id'])

    user_tag_types_sql_statement = sql.SQL(
        "SELECT {pkey} FROM {table_name} WHERE {name_key}=%(tag_type_val)s"
    ).format(
        pkey=sql.Identifier("id"), table_name=sql.Identifier("user_tag_types"), name_key=sql.Identifier("name")
    )
    cursor.execute(user_tag_types_sql_statement, {'tag_type_val': tag_type})
    for item in cursor:
        if item and 'id' in item:
            user_tag_types.append(item['id'])

    if len(user_tag_types) > 0 and len(user_tag_type_items) > 0:
        user_tag_type_items_sql_statement = sql.SQL(
            "SELECT {pkey}, {name_key} FROM {table_name} WHERE {tag_types_key} IN %(tag_types_set)s AND {pkey} IN %(items_pkey_set)s"
        ).format(
            pkey=sql.Identifier("id"), table_name=sql.Identifier("user_tag_type_items"),
            tag_types_key=sql.Identifier("user_tag_types_id"), name_key=sql.Identifier("name")
        )
        cursor.execute(user_tag_type_items_sql_statement,
                       {'tag_types_set': user_tag_types, 'items_pkey_set': user_tag_type_items})
        for item in cursor:
            if item and ('name' in item) and ('id' in item):
                user_data.append(item)

    return user_data


def get_user_expertises(cursor, user_id):
    get_user_tag_type_items(cursor, user_id, tag_type="expertises")


def get_user_professions(cursor, user_id):
    get_user_tag_type_items(cursor, user_id, tag_type="professions")


def get_user_interests(cursor, user_id):
    get_user_tag_type_items(cursor, user_id, tag_type="interests")


def get_user_locations(cursor, user_id, location_types=None, get_parents=True):
    if location_types and isinstance(location_types, list):
        if "user_country" in location_types:
            location_types.append(1)
        if "user_address" in location_types:
            location_types.append(2)
        if "area_of_interest" in location_types:
            location_types.append(3)
    else:
        location_types = [1, 2, 3]

    get_user_location_sql_statement = sql.SQL("""
        SELECT {locations_table}.{name_key} AS location_id, {user_locations_table}.{pkey} AS user_location_id, 
        {locations_table}.{name_key}, {locations_table}.{abbr_key}, {locations_table}.{boundaries_key} 
        FROM {user_locations_table} INNER JOIN {locations_table} ON {user_locations_table}.{location_pkey} = {locations_table}.{pkey}
        WHERE {user_locations_table}.{user_pkey}=%(user_id)s AND {user_locations_table}.{type_key} IN %(location_types)s
    """).format(
        locations_table=sql.Identifier("locations"), name_key=sql.Identifier("name"),
        abbr_key=sql.Identifier("abbr"), boundaries_key=sql.Identifier("boundaries"),
        user_locations_table=sql.Identifier("user_locations"), location_pkey=sql.Identifier("location_id"),
        user_pkey=sql.Identifier("user_id"), type_key=sql.Identifier("type")
    )
    get_location_sql_statement = sql.SQL(
        "SELECT {locations_table}.{name_key}, {locations_table}.{abbr_key}, {locations_table}.{boundaries_key} "
        "FROM {locations_table} WHERE {pkey}=%(parent_id)s;"
    ).format(
        locations_table=sql.Identifier("locations"), name_key=sql.Identifier("name"),
        abbr_key=sql.Identifier("abbr"), boundaries_key=sql.Identifier("boundaries"),
        user_pkey=sql.Identifier("user_id")
    )

    cursor.execute(get_user_location_sql_statement, {"user_id": user_id, "location_types": tuple(location_types)})

    user_locations = []
    for item in cursor:
        location_item = item
        if location_item:
            if 'creation_date' in location_item and isinstance(location_item['creation_date'], datetime.datetime):
                location_item['creation_date'] = location_item['creation_date'].replace(tzinfo=pytz.UTC).isoformat()
            if 'modification_date' in location_item and isinstance(location_item['modification_date'],
                                                                   datetime.datetime):
                location_item['modification_date'] = location_item['modification_date'].replace(
                    tzinfo=pytz.UTC).isoformat()
            if 'sponsored_expiry_date' in location_item and isinstance(location_item['sponsored_expiry_date'],
                                                                       datetime.datetime):
                location_item['sponsored_expiry_date'] = location_item['sponsored_expiry_date'].replace(
                    tzinfo=pytz.UTC).isoformat()

            nested_locations = []
            if get_parents:
                while True:
                    location_parent = location_item.get('parent_id', None) or location_item.get("parent", None)
                    # get all parents locations
                    if location_parent:
                        cursor.execute(get_location_sql_statement, {"id": int(location_parent)})
                        for item in cursor:
                            parent_location_item = item
                            if parent_location_item:
                                if 'creation_date' in parent_location_item:
                                    parent_location_item['creation_date'] = parent_location_item[
                                        'creation_date'].replace(tzinfo=pytz.UTC).isoformat()
                                if 'modification_date' in parent_location_item:
                                    parent_location_item['modification_date'] = parent_location_item[
                                        'modification_date'].replace(tzinfo=pytz.UTC).isoformat()

                                nested_locations.append(parent_location_item)
                    else:
                        break

            if nested_locations:
                nested_locations.reverse()
                nested_locations_output = {}
                for nested_location in nested_locations:
                    if not nested_locations_output:
                        nested_locations_output = nested_location
                    else:
                        nested_locations_output = {
                            **nested_location,
                            "parent": nested_locations_output
                        }
                location_item.update({"parent": nested_locations_output})

            user_locations.append(location_item)


def is_blocked(user_a, user_b, mutual=True):
    """
         Check whether user_a has blocked user_b or is there any mutual reverse
        :return: Boolean
    """
    try:
        # Connection to the RDS
        rds_handler = RDSHandler(table_name="", is_cursor_dict=True)
        conn = rds_handler.conn
        cursor = rds_handler.cursor
    except Exception as e:
        raise Exception("Error while connecting to RDS")

    if mutual:
        sql_statement = sql.SQL(
            """
            SELECT {pkey} FROM {table_name}
            WHERE (user_id IN (%(user_a)s, %(user_b)s) AND blocked_user_id IN (%(user_a)s, %(user_b)s))  
            ;""").format(
            table_name=sql.Identifier('user_block'),
            pkey=sql.Identifier('id')
        )
    else:
        sql_statement = sql.SQL(
            """
            SELECT {pkey} FROM {table_name}
            WHERE user_id=%(user_a)s AND blocked_user_id=%(user_b)s
            ;""").format(
            table_name=sql.Identifier('user_block'),
            pkey=sql.Identifier('id')
        )

    sql_kwargs = {
        'user_a': user_a,
        'user_b': user_b
    }

    try:
        cursor.execute(sql_statement, sql_kwargs)
        result = cursor.fetchone()
        if result:
            return True
        else:
            return False
    except Exception as ex:
        error = f"ERROR: {str(ex)}"
        return error


def get_api_key_data(key):
    # Connection to the RDS
    try:
        rds_handler = RDSHandler(table_name="", is_cursor_dict=True)
        cursor = rds_handler.cursor
    except Exception as e:
        raise e

    # Get API Key
    sql_statement = sql.SQL(
        """SELECT public_key, usage_plan_id, user_id, invoice_id FROM user_api_keys WHERE public_key=%(key)s""")
    sql_kwargs = {"key": key}
    try:
        cursor.execute(sql_statement, sql_kwargs)
        result = cursor.fetchone()
        return result
    except Exception as e:
        raise e
