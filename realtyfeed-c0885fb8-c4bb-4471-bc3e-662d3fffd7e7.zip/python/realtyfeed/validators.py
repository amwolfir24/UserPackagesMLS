from .exceptions import RealtyfeedException, DataInvalidException


def validate_dict_key_set(dict_obj: dict, key_choices: list, check_value=False,
                          value_choices: list = None, raise_exception=False, default_value=None) -> dict:
    if check_value and (not value_choices):
        raise RealtyfeedException(error_message="Internal. Cannot set `check_value=True` and send None `value_choices`.")

    for key in key_choices:
        if key not in dict_obj.keys():
            if raise_exception:
                raise DataInvalidException(error_message=f"{key} ")
        elif check_value:
            if dict_obj[key] not in value_choices:
                if raise_exception:
                    raise DataInvalidException()
                if default_value:
                    dict_obj[key] = default_value
                else:
                    dict_obj.pop(key)
    return dict_obj


def validate_s3_file_path(input_string):
    temp_url = 's3://realtyfeed/'
    if input_string.startswith(temp_url):
        return True
    raise DataInvalidException('File path is invalid. It must be inside Realtyfeed S3 Storage.')


def validate_string_iterable(inputs):
    result = bool(all(isinstance(x, str) for x in inputs))
    if not result:
        raise DataInvalidException("Not all the elements are strings")
